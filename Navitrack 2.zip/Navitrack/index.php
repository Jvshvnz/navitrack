<?php
session_start();

require_once __DIR__ . '/Sys_Database/db_connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navi Track • Campus Navigation Platform</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Space+Grotesk:wght@300..700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    
    <style>
        :root {
            --bg-organic: #f7f6f2;
            --fg-dark: #1c1c1c;
            --accent-green: #3d7068;
            --border-line: #e5e4de;
            --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
        }

        body {
            background-color: var(--bg-organic);
            color: var(--fg-dark);
            font-family: 'Space Grotesk', sans-serif;
            transition: all 700ms var(--ease-editorial);
        }

        .font-playfair { font-family: 'Playfair Display', Georgia, serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .font-grotesk { font-family: 'Space Grotesk', sans-serif; }

        .editorial-grid-bg {
            background-size: 40px 40px;
            background-image: 
                linear-gradient(to right, rgba(229, 228, 222, 0.6) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(229, 228, 222, 0.6) 1px, transparent 1px);
            mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
            -webkit-mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
        }

        @keyframes scanSlide {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        .animate-scan {
            animation: scanSlide 2s infinite cubic-bezier(0.8, 0, 0.2, 1);
        }

        .btn-editorial {
            background-color: var(--accent-green);
            color: #ffffff;
            transition: letter-spacing 400ms var(--ease-editorial), transform 200ms var(--ease-editorial);
            letter-spacing: 0.25em;
        }
        .btn-editorial:hover {
            letter-spacing: 0.4em;
        }

        .border-editorial {
            border: 1px solid var(--border-line);
            border-radius: 2px !important;
        }
    </style>
</head>
<body class="relative min-h-screen overflow-x-hidden antialiased">

    <div class="fixed inset-0 pointer-events-none z-0 flex justify-between max-w-7xl mx-auto px-6">
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
    </div>

    <div class="fixed inset-0 pointer-events-none z-0 editorial-grid-bg"></div>

    <header class="fixed top-0 left-0 right-0 z-50 transition-all duration-500 bg-[#f7f6f2]/80 backdrop-blur-md border-b border-[#e5e4de]">
        <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            
            <div class="flex items-center gap-3">
                <span class="w-6 h-[1px] bg-[#1c1c1c]"></span>
                <img src="assets/images/NaviTrack_Logo.png" alt="NaviTrack Logo" class="w-7 h-7 object-contain">
                <span class="font-playfair text-xl tracking-tight uppercase font-light text-[#1c1c1c]">Navi Track</span>
                <span class="w-8 h-[1px] bg-[#1c1c1c]"></span>
            </div>

            <nav class="flex items-center gap-6 font-mono-tech text-[10px] uppercase tracking-[0.3em]">
                <a href="LOGIN/login.php" class="px-4 py-2 border-editorial bg-[#3d7068] text-white hover:bg-[#1c1c1c] transition-colors font-bold">
                    [ Portal Login ]
                </a>
            </nav>
        </div>
    </header>

    <main class="relative z-10 max-w-7xl mx-auto px-6 pt-32 pb-24 space-y-24">

        <section class="text-center py-12 border-b border-[#e5e4de] space-y-6">

            <div class="inline-flex items-center gap-3 px-4 py-1.5 border-editorial bg-[#f7f6f2]">
                <span class="w-2 h-2 rounded-full bg-[#3d7068] animate-pulse"></span>
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">
                    CAST Building Navigation Platform
                </span>
            </div>

            <h1 class="font-playfair text-[8.5vw] leading-[0.95] font-light uppercase tracking-tighter text-[#1c1c1c]">
                Campus <span class="italic text-[#B4B4B4] font-normal">Navigation</span> Platform
            </h1>

            <p class="font-grotesk max-w-xl mx-auto text-sm text-[#1c1c1c]/70 leading-relaxed">
                Precision spatial orientation, real-time schedule allocation, and laboratory status tracking designed for college operations.
            </p>

            <div class="pt-4 flex justify-center gap-4">
                <a href="LOGIN/login.php" class="inline-block px-8 py-4 btn-editorial font-mono-tech text-[10px] uppercase border-editorial shadow-sm">
                    Enter Portal Login
                </a>
            </div>
        </section>

        <section class="grid grid-cols-1 md:grid-cols-3 border-editorial bg-[#f7f6f2]">
            <div class="p-10 border-b md:border-b-0 md:border-r border-[#e5e4de] hover:bg-white transition-colors duration-500 space-y-4">
                <div class="w-12 h-12 border-editorial flex items-center justify-center text-[#3d7068]">
                    <i class="fa-solid fa-layer-group"></i>
                </div>
                <div class="font-playfair text-4xl text-[#1c1c1c]">02</div>
                <div class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#3d7068]">Active Floor Levels</div>
            </div>

            <div class="p-10 border-b md:border-b-0 md:border-r border-[#e5e4de] hover:bg-white transition-colors duration-500 space-y-4">
                <div class="w-12 h-12 border-editorial flex items-center justify-center text-[#3d7068]">
                    <i class="fa-solid fa-microchip"></i>
                </div>
                <div class="font-playfair text-4xl text-[#1c1c1c]">3</div>
                <div class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#3d7068]">Computer Laboratories</div>
            </div>

            <div class="p-10 hover:bg-white transition-colors duration-500 space-y-4">
                <div class="w-12 h-12 border-editorial flex items-center justify-center text-[#3d7068]">
                    <i class="fa-solid fa-clock"></i>
                </div>
                <div class="font-playfair text-4xl text-[#1c1c1c]">100%</div>
                <div class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#3d7068]">Schedule Accuracy</div>
            </div>
        </section>

        <section class="py-12 border-y border-[#e5e4de] text-center" id="revealSection">
            <p class="font-playfair text-2xl md:text-5xl leading-tight max-w-4xl mx-auto" id="revealParagraph">
                <span>Navi Track</span> <span>delivers</span> <span>seamless</span> <span>spatial</span> <span>intelligence</span> <span>connecting</span> <span>students</span> <span>and</span> <span>faculty</span> <span>to</span> <span>their</span> <span>academic</span> <span>destinations.</span>
            </p>
        </section>

        <section class="max-w-3xl mx-auto space-y-8">
            <div class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068] border-b border-[#e5e4de] pb-3 text-center">
                [ System Workflow ]
            </div>

            <div class="space-y-6">
                <div onclick="selectWorkflow(1)" id="step-1" class="cursor-pointer transition-opacity duration-300 space-y-2 border-editorial p-6 bg-white">
                    <div class="font-mono-tech text-xs text-[#3d7068]">01 / SCAN</div>
                    <h3 class="font-playfair text-xl text-[#1c1c1c]">QR Laboratory Verification</h3>
                    <p class="font-grotesk text-xs text-[#1c1c1c]/70">Instantly check laboratory status and instructor schedules by scanning room QR identifiers.</p>
                </div>

                <div onclick="selectWorkflow(2)" id="step-2" class="cursor-pointer opacity-40 transition-opacity duration-300 space-y-2 border-editorial p-6 bg-[#f7f6f2]">
                    <div class="font-mono-tech text-xs text-[#3d7068]">02 / LOCATE</div>
                    <h3 class="font-playfair text-xl text-[#1c1c1c]">Interactive Floorplan Navigation</h3>
                    <p class="font-grotesk text-xs text-[#1c1c1c]/70">Explore the CAST building layout with precise room markers and destination highlights.</p>
                </div>

                <div onclick="selectWorkflow(3)" id="step-3" class="cursor-pointer opacity-40 transition-opacity duration-300 space-y-2 border-editorial p-6 bg-[#f7f6f2]">
                    <div class="font-mono-tech text-xs text-[#3d7068]">03 / TIMETABLE</div>
                    <h3 class="font-playfair text-xl text-[#1c1c1c]">Dynamic Schedule Synchronization</h3>
                    <p class="font-grotesk text-xs text-[#1c1c1c]/70">Access personal course timelines and block schedules updated by department chairs.</p>
                </div>
            </div>
        </section>

        <section class="border-editorial p-10 bg-[#f7f6f2] relative overflow-hidden space-y-12">
            <div class="absolute right-[-40px] bottom-[-40px] opacity-[0.05] pointer-events-none">
                <i class="fa-solid fa-compass text-[240px] text-[#1c1c1c]"></i>
            </div>

            <div class="text-center space-y-4 max-w-xl mx-auto relative z-10">
                <div class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068]">
                    [ Institutional Services ]
                </div>
                <h2 class="font-playfair text-3xl md:text-4xl text-[#1c1c1c]">Integrated Academic Workflows</h2>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10 pt-6 border-t border-[#e5e4de]">
                <div class="space-y-2">
                    <span class="font-mono-tech text-xs text-[#3d7068]">01. STUDENT</span>
                    <h4 class="font-playfair text-lg text-[#1c1c1c]">Timetable View</h4>
                    <p class="font-grotesk text-xs text-[#1c1c1c]/70">Track room assignments and instructor schedules in real time.</p>
                </div>
                <div class="space-y-2">
                    <span class="font-mono-tech text-xs text-[#3d7068]">02. FACULTY</span>
                    <h4 class="font-playfair text-lg text-[#1c1c1c]">Laboratory Control</h4>
                    <p class="font-grotesk text-xs text-[#1c1c1c]/70">Manage subject allocations and laboratory occupancy availability.</p>
                </div>
                <div class="space-y-2">
                    <span class="font-mono-tech text-xs text-[#3d7068]">03. ADMINISTRATION</span>
                    <h4 class="font-playfair text-lg text-[#1c1c1c]">Central Management</h4>
                    <p class="font-grotesk text-xs text-[#1c1c1c]/70">Maintain user access roles, building structures, and course blocks.</p>
                </div>
            </div>
        </section>

        <!-- Access Request Contact Form -->
        <section class="grid grid-cols-1 lg:grid-cols-2 gap-12 border-editorial p-10 bg-white">
            <div class="space-y-4">
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068]">[ Inquiries ]</span>
                <h2 class="font-playfair text-4xl text-[#1c1c1c]">Request System Access</h2>
                <p class="font-grotesk text-xs text-[#1c1c1c]/70 max-w-md">
                    Require updated permissions or technical assistance with campus navigation credentials? Submit a formal request to administration.
                </p>
            </div>

            <form action="#" method="POST" class="space-y-6">
                <div>
                    <input type="text" placeholder="FULL NAME" required
                           class="w-full pb-3 bg-transparent border-b border-[#e5e4de] font-mono-tech text-xs text-[#1c1c1c] placeholder-[#1c1c1c]/40 focus:outline-none focus:border-[#3d7068] transition-colors">
                </div>
                <div>
                    <input type="email" placeholder="INSTITUTIONAL EMAIL" required
                           class="w-full pb-3 bg-transparent border-b border-[#e5e4de] font-mono-tech text-xs text-[#1c1c1c] placeholder-[#1c1c1c]/40 focus:outline-none focus:border-[#3d7068] transition-colors">
                </div>
                <div>
                    <input type="text" placeholder="DEPARTMENT / SECTION" required
                           class="w-full pb-3 bg-transparent border-b border-[#e5e4de] font-mono-tech text-xs text-[#1c1c1c] placeholder-[#1c1c1c]/40 focus:outline-none focus:border-[#3d7068] transition-colors">
                </div>
                
                <button type="submit" 
                        class="w-full py-4 btn-editorial font-mono-tech text-[10px] uppercase border-editorial shadow-sm">
                    Submit Access Request
                </button>
            </form>
        </section>

    </main>

    <footer class="border-t border-[#e5e4de] bg-[#f7f6f2] relative z-10 py-8">
        <div class="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center gap-4 font-mono-tech text-[10px] text-[#1c1c1c]/60 uppercase tracking-widest">
            <div>© 2026 Navi Track • College of Arts & Sciences • BSIT WMT 3-1</div>
            <div>Pangasinan State University</div>
        </div>
    </footer>

    <script>
        function selectWorkflow(stepNum) {
            for (let i = 1; i <= 3; i++) {
                const el = document.getElementById('step-' + i);
                if (i === stepNum) {
                    el.className = 'cursor-pointer transition-opacity duration-300 space-y-2 border-editorial p-6 bg-white opacity-100';
                } else {
                    el.className = 'cursor-pointer opacity-40 transition-opacity duration-300 space-y-2 border-editorial p-6 bg-[#f7f6f2]';
                }
            }
        }

        window.addEventListener('scroll', function() {
            const section = document.getElementById('revealSection');
            const spans = document.querySelectorAll('#revealParagraph span');
            if (!section) return;

            const rect = section.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            if (rect.top < windowHeight && rect.bottom > 0) {
                const progress = Math.min(Math.max((windowHeight - rect.top) / (windowHeight + rect.height), 0), 1);
                const activeIndex = Math.floor(progress * spans.length * 1.5);

                spans.forEach((span, idx) => {
                    if (idx <= activeIndex) {
                        span.style.opacity = '1.0';
                        span.style.color = '#1c1c1c';
                    } else {
                        span.style.opacity = '0.15';
                    }
                });
            }
        });
    </script>
</body>
</html>