<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$dbserver = getenv('CAMPUSNAV_DB_HOST') ?: '127.0.0.1';
$dbport   = (int)(getenv('CAMPUSNAV_DB_PORT') ?: 3306);
$dbuser   = getenv('CAMPUSNAV_DB_USER') ?: 'root';
$dbpass   = getenv('CAMPUSNAV_DB_PASS') ?: '';
$dbname   = getenv('CAMPUSNAV_DB_NAME') ?: 'campusnav';

try {
    $conn = new mysqli($dbserver, $dbuser, $dbpass, $dbname, $dbport);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    error_log('CampusNav database connection failed: ' . $e->getMessage());
    http_response_code(500);
    exit('DEBUG ERROR: ' . $e->getMessage());
}
?>