<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../Sys_Database/db_connection.php';

global $conn;
try {
    $data = [];
    $data['buildings'] = $conn->query('SELECT building_id, building_name FROM buildings ORDER BY building_name')->fetch_all(MYSQLI_ASSOC);
    $data['instructors'] = $conn->query("SELECT prof_id, prof_name AS teacher_name FROM teachers ORDER BY prof_name")->fetch_all(MYSQLI_ASSOC);
    $data['subjects'] = $conn->query('SELECT sub_id, subject_name FROM subjects ORDER BY subject_name')->fetch_all(MYSQLI_ASSOC);
    $data['blocks'] = $conn->query("SELECT block_id, block_id AS block_name, blocks FROM blocks ORDER BY block_id")->fetch_all(MYSQLI_ASSOC);
    $data['departments'] = $conn->query("SELECT course_id, full_course AS department, course_name FROM course_list ORDER BY course_name")->fetch_all(MYSQLI_ASSOC);
    $data['semesters'] = $conn->query('SELECT sem_id, semester FROM semester ORDER BY sem_id')->fetch_all(MYSQLI_ASSOC);
    $data['school_years'] = $conn->query('SELECT year_id, school_year FROM school_year ORDER BY year_id DESC')->fetch_all(MYSQLI_ASSOC);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('CHAIRPERSON/get_modal_data.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Unable to load form data.']);
}
?>
