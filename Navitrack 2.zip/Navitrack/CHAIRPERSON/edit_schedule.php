<?php
session_start();
require_once __DIR__ . '/../Sys_Database/db_connection.php';

if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 1) {
    header("Location: ../LOGIN/login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sched_id    = (int)($_POST['sched_id'] ?? 0);
    $prof_id     = (int)($_POST['prof_id'] ?? 0);
    $sub_id      = (int)($_POST['sub_id'] ?? 0);
    $room_id     = (int)($_POST['room_id'] ?? 0);
    $day_of_week = trim($_POST['day_of_week'] ?? '');
    $start_time  = $_POST['start_time'] ?? '';
    $end_time    = $_POST['end_time'] ?? '';

    if ($sched_id > 0 && $prof_id > 0 && $sub_id > 0 && $room_id > 0) {
        $stmt = $conn->prepare("UPDATE teacher_schedule 
                                SET prof_id = ?, sub_id = ?, room_id = ?, day_of_week = ?, start_time = ?, end_time = ? 
                                WHERE sched_id = ?");
        $stmt->bind_param("iiisssi", $prof_id, $sub_id, $room_id, $day_of_week, $start_time, $end_time, $sched_id);
        $stmt->execute();
        $stmt->close();
    }
}

header("Location: chair.php");
exit;