<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../Sys_Database/db_connection.php';

global $conn;
try {
    $sql = <<<'SQL'
        SELECT
            t.prof_id AS teacher_id,
            t.prof_name AS teacher_name,
            'Instructor' AS role,
            u.email,
            CASE WHEN u.is_active = 1 THEN 'Active' ELSE 'Inactive' END AS status
        FROM teachers AS t
        INNER JOIN users AS u ON t.user_id = u.user_id
        ORDER BY t.prof_name
    SQL;
    $result = $conn->query($sql);
    echo json_encode($result->fetch_all(MYSQLI_ASSOC), JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('CHAIRPERSON/get_teachers.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Unable to load teachers.']);
}
?>
