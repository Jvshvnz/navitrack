<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

$db_file = __DIR__ . '/../Sys_Database/db_connection.php';
if (!file_exists($db_file)) {
    die("Fatal Error: Cannot locate db_connection.php at " . htmlspecialchars($db_file));
}
require_once $db_file;
global $conn;

// Session validation for Chairperson (role_id = 1)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 1) {
    header("Location: ../LOGIN/login.php");
    exit;
}

$user_id  = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'Chairperson';

date_default_timezone_set('Asia/Manila');
$today       = strtoupper(date("l"));
$currentTime = date("H:i:s");

// ==========================================
// 1. DASHBOARD OVERVIEW METRICS
// ==========================================

// Faculty Count
$totalFaculty = 0;
$resFaculty = @mysqli_query($conn, "SELECT COUNT(*) AS total_faculty FROM teachers");
if ($resFaculty && $row = mysqli_fetch_assoc($resFaculty)) {
    $totalFaculty = $row['total_faculty'];
}

// Scheduled Today
$sqlTodayClasses = "SELECT ts.*, t.prof_name, r.room_name, s.subject_name 
                    FROM teacher_schedule ts
                    JOIN teachers t ON ts.prof_id = t.prof_id
                    JOIN room_list r ON ts.room_id = r.room_id
                    JOIN subjects s ON ts.sub_id = s.sub_id
                    WHERE UPPER(ts.day_of_week) = ?
                    ORDER BY ts.start_time ASC";
$stmtToday = @mysqli_prepare($conn, $sqlTodayClasses);
$todayClassesResult = false;
if ($stmtToday) {
    mysqli_stmt_bind_param($stmtToday, "s", $today);
    mysqli_stmt_execute($stmtToday);
    $todayClassesResult = mysqli_stmt_get_result($stmtToday);
}
$todayClassCount = $todayClassesResult ? mysqli_num_rows($todayClassesResult) : 0;

// Occupied Rooms
$sqlOccupied = "SELECT DISTINCT r.room_name, b.building_name, sub.subject_name, t.prof_name
                FROM teacher_schedule ts
                JOIN room_list r ON ts.room_id = r.room_id
                JOIN buildings b ON r.building_id = b.building_id
                JOIN subjects sub ON ts.sub_id = sub.sub_id
                JOIN teachers t ON ts.prof_id = t.prof_id
                WHERE UPPER(ts.day_of_week) = ? 
                AND ? BETWEEN ts.start_time AND ts.end_time";
$stmtOccupied = @mysqli_prepare($conn, $sqlOccupied);
$occupiedRoomsResult = false;
if ($stmtOccupied) {
    mysqli_stmt_bind_param($stmtOccupied, "ss", $today, $currentTime);
    mysqli_stmt_execute($stmtOccupied);
    $occupiedRoomsResult = mysqli_stmt_get_result($stmtOccupied);
}
$occupiedRoomCount = $occupiedRoomsResult ? mysqli_num_rows($occupiedRoomsResult) : 0;

// Active Conflicts
$sqlConflicts = "SELECT s1.room_id, s1.day_of_week, r.room_name, sub1.subject_name AS sub1, sub2.subject_name AS sub2
                 FROM teacher_schedule s1
                 JOIN teacher_schedule s2 
                   ON s1.room_id = s2.room_id 
                  AND s1.day_of_week = s2.day_of_week 
                  AND (s1.start_time < s2.end_time AND s1.end_time > s2.start_time)
                 JOIN room_list r ON s1.room_id = r.room_id
                 JOIN subjects sub1 ON s1.sub_id = sub1.sub_id
                 JOIN subjects sub2 ON s2.sub_id = sub2.sub_id
                 WHERE s1.prof_id != s2.prof_id
                 GROUP BY s1.room_id, s1.day_of_week";
$resConf = @mysqli_query($conn, $sqlConflicts);
$conflictCount = $resConf ? mysqli_num_rows($resConf) : 0;

// ==========================================
// 2. DATA FOR MANAGEMENT SECTIONS
// ==========================================
$resTeachersList = @mysqli_query($conn, "SELECT t.prof_id, t.prof_name, c.course_name FROM teachers t LEFT JOIN course_list c ON t.course_id = c.course_id ORDER BY t.prof_name ASC");
$resSubjectsList = @mysqli_query($conn, "SELECT sub_id, subject_name FROM subjects ORDER BY subject_name ASC");
$resRoomsList    = @mysqli_query($conn, "SELECT r.*, b.building_name FROM room_list r JOIN buildings b ON r.building_id = b.building_id ORDER BY r.room_name ASC");

// Fetch ALL schedules for matrix positioning
$sqlMasterSched = "SELECT ts.*, t.prof_name, r.room_name, s.subject_name 
                   FROM teacher_schedule ts
                   JOIN teachers t ON ts.prof_id = t.prof_id
                   JOIN room_list r ON ts.room_id = r.room_id
                   JOIN subjects s ON ts.sub_id = s.sub_id";
$resMasterSched = @mysqli_query($conn, $sqlMasterSched);

$masterSchedules = [];
if ($resMasterSched && mysqli_num_rows($resMasterSched) > 0) {
    while ($row = mysqli_fetch_assoc($resMasterSched)) {
        $masterSchedules[] = $row;
    }
}

// MATRIX TIMETABLE SLOTS (07:00 AM to 07:00 PM matching PSU layout)
$timeSlots = [
    ['start' => '07:00:00', 'end' => '08:00:00', 'label' => "07:00\n08:00"],
    ['start' => '08:00:00', 'end' => '09:00:00', 'label' => "08:00\n09:00"],
    ['start' => '09:00:00', 'end' => '10:00:00', 'label' => "09:00\n10:00"],
    ['start' => '10:00:00', 'end' => '11:00:00', 'label' => "10:00\n11:00"],
    ['start' => '11:00:00', 'end' => '12:00:00', 'label' => "11:00\n12:00"],
    ['type'  => 'break',    'label' => "12:00\n01:00", 'title' => 'LUNCH BREAK'],
    ['start' => '13:00:00', 'end' => '14:00:00', 'label' => "01:00\n02:00"],
    ['start' => '14:00:00', 'end' => '15:00:00', 'label' => "02:00\n03:00"],
    ['start' => '15:00:00', 'end' => '16:00:00', 'label' => "03:00\n04:00"],
    ['start' => '16:00:00', 'end' => '17:00:00', 'label' => "04:00\n05:00"],
    ['start' => '17:00:00', 'end' => '18:00:00', 'label' => "05:00\n06:00"],
    ['start' => '18:00:00', 'end' => '19:00:00', 'label' => "06:00\n07:00"],
];

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function matchSlotSchedules($schedules, $day, $slotStart, $slotEnd) {
    $matched = [];
    foreach ($schedules as $s) {
        if (strcasecmp(trim($s['day_of_week']), $day) === 0) {
            $sStart = strtotime($s['start_time']);
            $sEnd   = strtotime($s['end_time']);
            $tStart = strtotime($slotStart);
            $tEnd   = strtotime($slotEnd);

            if ($sStart < $tEnd && $sEnd > $tStart) {
                $matched[] = $s;
            }
        }
    }
    return $matched;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navi Track • Chairperson Operations Portal</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Space+Grotesk:wght@300..700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --bg-organic: #f7f6f2;
            --fg-dark: #1c1c1c;
            --accent-green: #3d7068;
            --border-line: #e5e4de;
            --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
        }

        body {
            background-color: var(--bg-organic);
            color: var(--fg-dark);
            font-family: 'Space Grotesk', sans-serif;
        }

        .font-playfair { font-family: 'Playfair Display', Georgia, serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .font-grotesk { font-family: 'Space Grotesk', sans-serif; }

        .editorial-grid-bg {
            background-size: 40px 40px;
            background-image: 
                linear-gradient(to right, rgba(229, 228, 222, 0.6) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(229, 228, 222, 0.6) 1px, transparent 1px);
        }

        .border-editorial {
            border: 1px solid var(--border-line);
            border-radius: 2px !important;
        }

        .btn-editorial {
            background-color: var(--accent-green);
            color: #ffffff;
            transition: letter-spacing 400ms var(--ease-editorial);
            letter-spacing: 0.15em;
        }
        .btn-editorial:hover {
            letter-spacing: 0.25em;
        }

        .nav-item-active {
            background-color: #3d7068;
            color: #ffffff !important;
        }

        .psu-table {
            border-collapse: collapse;
            width: 100%;
        }
        .psu-table th, .psu-table td {
            border: 1px solid #1c1c1c;
        }
    </style>
</head>
<body class="relative min-h-screen bg-[#f7f6f2] text-[#1c1c1c] overflow-x-hidden antialiased flex">

    <!-- LOADING OVERLAY -->
    <div id="loading-screen" class="fixed inset-0 z-[9999] bg-[#f7f6f2] flex items-center justify-center">
        <div class="editorial-grid-bg absolute inset-0 opacity-80"></div>
        <div class="relative z-10 text-center space-y-4 max-w-sm px-6">
            <div class="inline-flex items-center gap-2 px-3 py-1 border-editorial bg-white">
                <span class="w-2 h-2 rounded-full bg-[#3d7068] animate-pulse"></span>
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">Initializing Executive Portal</span>
            </div>
            <div class="flex items-center justify-center gap-3">
                <img src="../assets/images/NaviTrack_Logo.png" alt="NaviTrack Logo" class="w-8 h-8 object-contain">
                <h1 class="font-playfair text-3xl font-light uppercase tracking-wider text-[#1c1c1c]">Navi Track</h1>
            </div>
            <p class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c]/60">Department of Information Technology</p>
            <div class="w-full h-1 bg-[#e5e4de] border-editorial overflow-hidden">
                <div id="ls-fill" class="h-full bg-[#3d7068] w-0 transition-all duration-300"></div>
            </div>
            <div class="flex justify-between font-mono-tech text-[10px] text-[#1c1c1c]/60">
                <span id="ls-status">Verifying Executive Session...</span>
                <span id="ls-pct">0%</span>
            </div>
        </div>
    </div>

    <!-- SIDEBAR -->
    <aside class="w-64 h-screen fixed top-0 left-0 z-40 bg-white border-r border-[#e5e4de] flex flex-col justify-between p-6 overflow-y-auto shrink-0">
        <div class="space-y-8">
            <a href="chair.php" class="flex items-center gap-3">
                <img src="../assets/images/NaviTrack_Logo.png" alt="NaviTrack Logo" class="w-8 h-8 object-contain">
                <div>
                    <span class="block font-playfair text-lg font-light uppercase tracking-wider leading-none">Navi Track</span>
                    <span class="font-mono-tech text-[9px] uppercase text-[#3d7068] tracking-widest">Chairperson</span>
                </div>
            </a>

            <nav class="space-y-2 font-mono-tech text-[10px] uppercase tracking-[0.2em]">
                <button onclick="switchView('dashboard')" id="nav-dashboard" class="w-full text-left p-3 border-editorial transition-colors flex items-center gap-3 text-[#1c1c1c] nav-item-active cursor-pointer">
                    <i class="fas fa-chart-pie text-xs w-4"></i>
                    <span>Overview Dashboard</span>
                </button>
                <button onclick="switchView('sec-schedule')" id="nav-sec-schedule" class="w-full text-left p-3 border-editorial transition-colors flex items-center gap-3 text-[#1c1c1c] hover:bg-[#f7f6f2] cursor-pointer">
                    <i class="fas fa-calendar-alt text-xs w-4"></i>
                    <span>1. Schedule Manager</span>
                </button>
                <button onclick="switchView('sec-rooms')" id="nav-sec-rooms" class="w-full text-left p-3 border-editorial transition-colors flex items-center gap-3 text-[#1c1c1c] hover:bg-[#f7f6f2] cursor-pointer">
                    <i class="fas fa-door-open text-xs w-4"></i>
                    <span>2. Room Allocation Map</span>
                </button>
                <button onclick="switchView('sec-faculty')" id="nav-sec-faculty" class="w-full text-left p-3 border-editorial transition-colors flex items-center gap-3 text-[#1c1c1c] hover:bg-[#f7f6f2] cursor-pointer">
                    <i class="fas fa-users-cog text-xs w-4"></i>
                    <span>3. Faculty Directory</span>
                </button>
            </nav>
        </div>

        <div class="pt-6 border-t border-[#e5e4de] space-y-3">
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 bg-[#3d7068] text-white flex items-center justify-center font-mono-tech text-xs font-bold rounded-sm shrink-0">
                    <?= strtoupper(substr($username, 0, 2)); ?>
                </div>
                <div class="overflow-hidden">
                    <span class="block font-mono-tech text-xs font-bold text-[#1c1c1c] truncate"><?= htmlspecialchars($username); ?></span>
                    <span class="block font-mono-tech text-[9px] text-[#3d7068] uppercase">Department Chair</span>
                </div>
            </div>

            <a href="../LOGIN/login.php" class="w-full py-2.5 border-editorial bg-[#f7f6f2] hover:bg-red-50 text-red-700 font-mono-tech text-[10px] uppercase tracking-wider text-center flex items-center justify-center gap-2 transition-colors">
                <i class="fas fa-sign-out-alt"></i> End Session
            </a>
        </div>
    </aside>

    <!-- MAIN WORKSPACE -->
    <div class="ml-64 flex-1 min-h-screen relative p-8 md:p-12">
        <div class="fixed inset-0 pointer-events-none z-0 editorial-grid-bg opacity-70 ml-64"></div>

        <!-- DASHBOARD VIEW -->
        <div id="view-dashboard" class="space-y-8 relative z-10">
            <div class="space-y-2">
                <div class="inline-flex items-center gap-2 px-3 py-1 border-editorial bg-white">
                    <span class="w-2 h-2 rounded-full bg-[#3d7068] animate-pulse"></span>
                    <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">Executive Overview</span>
                </div>
                <h1 class="font-playfair text-4xl font-light uppercase text-[#1c1c1c]">Department Operations Dashboard</h1>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <div onclick="switchView('sec-faculty')" class="p-6 border-editorial bg-white space-y-2 cursor-pointer hover:border-[#3d7068] transition-colors">
                    <span class="block font-mono-tech text-[9px] uppercase tracking-widest text-[#1c1c1c]/50">1. Directory Faculty</span>
                    <span class="block font-playfair text-4xl text-[#1c1c1c]"><?= $totalFaculty; ?></span>
                    <span class="block font-mono-tech text-[10px] text-[#3d7068]">Assigned Teachers →</span>
                </div>

                <div onclick="switchView('sec-schedule')" class="p-6 border-editorial bg-white space-y-2 cursor-pointer hover:border-[#3d7068] transition-colors">
                    <span class="block font-mono-tech text-[9px] uppercase tracking-widest text-[#1c1c1c]/50">2. Scheduled Today</span>
                    <span class="block font-playfair text-4xl text-[#3d7068]"><?= $todayClassCount; ?></span>
                    <span class="block font-mono-tech text-[10px] text-[#3d7068]"><?= $today; ?> Sessions →</span>
                </div>

                <div onclick="switchView('sec-rooms')" class="p-6 border-editorial bg-white space-y-2 cursor-pointer hover:border-[#3d7068] transition-colors">
                    <span class="block font-mono-tech text-[9px] uppercase tracking-widest text-[#1c1c1c]/50">3. Rooms Active Now</span>
                    <span class="block font-playfair text-4xl text-[#1c1c1c]"><?= $occupiedRoomCount; ?></span>
                    <span class="block font-mono-tech text-[10px] text-[#3d7068]">CAST Facilities →</span>
                </div>

                <div onclick="switchView('sec-schedule')" class="p-6 border-editorial bg-white space-y-2 cursor-pointer hover:border-red-600 transition-colors">
                    <span class="block font-mono-tech text-[9px] uppercase tracking-widest text-[#1c1c1c]/50">4. Active Conflicts</span>
                    <span class="block font-playfair text-4xl <?= $conflictCount > 0 ? 'text-red-600' : 'text-[#3d7068]'; ?>"><?= $conflictCount; ?></span>
                    <span class="block font-mono-tech text-[10px] <?= $conflictCount > 0 ? 'text-red-600' : 'text-[#3d7068]'; ?>">
                        <?= $conflictCount > 0 ? 'Attention Required →' : 'All Clear →'; ?>
                    </span>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div class="lg:col-span-7 border-editorial bg-white p-6 space-y-4">
                    <div class="flex justify-between items-center border-b border-[#e5e4de] pb-3">
                        <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">Today's Scheduled Sessions</span>
                        <span class="font-mono-tech text-xs text-[#1c1c1c]/60"><?= $today; ?></span>
                    </div>

                    <div class="space-y-3">
                        <?php if ($todayClassesResult && mysqli_num_rows($todayClassesResult) > 0): ?>
                            <?php while ($c = mysqli_fetch_assoc($todayClassesResult)): ?>
                                <div class="p-3 border-editorial bg-[#f7f6f2] flex items-center justify-between font-mono-tech text-xs">
                                    <div>
                                        <span class="block font-bold text-[#3d7068]"><?= htmlspecialchars($c['subject_name']); ?></span>
                                        <span class="text-[10px] text-[#1c1c1c]/70"><?= htmlspecialchars($c['prof_name']); ?> • <?= htmlspecialchars($c['room_name']); ?></span>
                                    </div>
                                    <span class="text-[10px] font-bold text-[#1c1c1c]"><?= htmlspecialchars($c['start_time']) . " - " . htmlspecialchars($c['end_time']); ?></span>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="p-4 text-center font-mono-tech text-xs text-[#1c1c1c]/50">No classes scheduled for <?= $today; ?>.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="lg:col-span-5 border-editorial bg-white p-6 space-y-4">
                    <div class="flex justify-between items-center border-b border-[#e5e4de] pb-3">
                        <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">Currently Occupied Rooms</span>
                        <span class="font-mono-tech text-xs text-[#3d7068] font-bold"><?= date("h:i A"); ?></span>
                    </div>

                    <div class="space-y-3">
                        <?php if ($occupiedRoomsResult && mysqli_num_rows($occupiedRoomsResult) > 0): ?>
                            <?php while ($occ = mysqli_fetch_assoc($occupiedRoomsResult)): ?>
                                <div class="p-3 border-editorial bg-emerald-50/60 font-mono-tech text-xs space-y-1">
                                    <div class="flex justify-between font-bold text-emerald-950">
                                        <span><?= htmlspecialchars($occ['room_name']); ?></span>
                                        <span><?= htmlspecialchars($occ['building_name']); ?></span>
                                    </div>
                                    <p class="text-[10px] text-emerald-900"><?= htmlspecialchars($occ['subject_name']); ?> (<?= htmlspecialchars($occ['prof_name']); ?>)</p>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="p-4 text-center font-mono-tech text-xs text-[#1c1c1c]/50">No rooms are currently occupied at this exact time.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- MANAGEMENT SECTION 1: SCHEDULE MANAGER -->
        <div id="view-sec-schedule" class="hidden space-y-8 relative z-10">
            
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#e5e4de] pb-6">
                <div class="space-y-1">
                    <span class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068]">Management Module 01</span>
                    <h1 class="font-playfair text-3xl font-light uppercase text-[#1c1c1c]">Class Schedule Matrix</h1>
                    <p class="font-mono-tech text-xs text-[#1c1c1c]/60">Pangasinan State University • Bayambang Campus</p>
                </div>

                <!-- ADD SCHEDULE TRIGGER BUTTON -->
                <button onclick="openAddModal()" class="px-6 py-3.5 btn-editorial border-editorial font-mono-tech text-xs uppercase flex items-center gap-2 cursor-pointer shrink-0">
                    <i class="fas fa-plus"></i>
                    <span>Add Schedule Entry</span>
                </button>
            </div>

            <!-- OFFICIAL PSU CLASS SCHEDULE MATRIX FORMAT -->
            <div class="border-editorial bg-white p-6 space-y-4 overflow-x-auto shadow-sm">
                
                <div class="text-center space-y-1 border-b border-[#1c1c1c] pb-4">
                    <h2 class="font-playfair text-2xl font-bold uppercase tracking-wider text-[#1c1c1c]">CLASS SCHEDULE</h2>
                    <p class="font-mono-tech text-[10px] uppercase tracking-widest text-[#1c1c1c]/70">PANGASINAN STATE UNIVERSITY</p>
                    <p class="font-mono-tech text-xs font-bold text-[#3d7068] pt-1">
                        1st Semester, 2026- 2027 / Bayambang Campus
                    </p>
                </div>

                <table class="psu-table text-[#1c1c1c] font-sans">
                    <thead>
                        <tr class="bg-[#f7f6f2] font-mono-tech text-xs font-bold text-center">
                            <th class="p-2 w-24">TIME</th>
                            <?php foreach ($days as $day): ?>
                                <th class="p-2 min-w-[140px]"><?= $day; ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($timeSlots as $slot): ?>
                            <?php if (isset($slot['type']) && $slot['type'] === 'break'): ?>
                                <!-- LUNCH BREAK ROW -->
                                <tr class="bg-[#f7f6f2] text-center font-bold">
                                    <td class="p-2 font-mono-tech text-xs whitespace-pre-line leading-tight bg-[#e5e4de]"><?= $slot['label']; ?></td>
                                    <td colspan="6" class="p-3 font-mono-tech text-sm tracking-[0.3em] uppercase bg-[#f7f6f2]">
                                        <?= $slot['title']; ?>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td class="p-2 font-mono-tech text-xs font-bold text-center whitespace-pre-line leading-tight bg-[#f7f6f2]">
                                        <?= $slot['label']; ?>
                                    </td>
                                    <?php foreach ($days as $day): ?>
                                        <?php 
                                        $cellSchedules = matchSlotSchedules($masterSchedules, $day, $slot['start'], $slot['end']); 
                                        ?>
                                        <td class="p-1.5 align-top h-20 text-[11px] leading-snug">
                                            <?php if (!empty($cellSchedules)): ?>
                                                <?php foreach ($cellSchedules as $sched): ?>
                                                    <div class="p-2 bg-[#f7f6f2] border border-[#1c1c1c]/20 rounded-sm mb-1 space-y-1 relative group">
                                                        <div class="font-bold text-[#1c1c1c] border-b border-[#e5e4de] pb-1 flex justify-between items-center">
                                                            <span><?= htmlspecialchars($sched['subject_name']); ?></span>
                                                            <div class="opacity-0 group-hover:opacity-100 transition-opacity space-x-1">
                                                                <button onclick="openEditModal(<?= htmlspecialchars(json_encode($sched)); ?>)" class="text-[#3d7068] hover:text-[#1c1c1c]" title="Edit">[E]</button>
                                                                <a href="delete_schedule.php?id=<?= $sched['sched_id'] ?? $sched['id'] ?? ''; ?>" onclick="return confirm('Delete class entry?');" class="text-red-600 hover:text-red-900" title="Delete">[D]</a>
                                                            </div>
                                                        </div>
                                                        <div class="text-[10px] text-[#1c1c1c]/80">
                                                            Instructor: <?= htmlspecialchars($sched['prof_name']); ?>
                                                        </div>
                                                        <div class="text-[10px] font-mono-tech font-bold text-[#3d7068]">
                                                            <?= htmlspecialchars($sched['room_name']); ?>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- MANAGEMENT SECTION 2: ROOMS -->
        <div id="view-sec-rooms" class="hidden space-y-8 relative z-10">
            <div class="space-y-2">
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068]">Management Module 02</span>
                <h1 class="font-playfair text-4xl font-light uppercase text-[#1c1c1c]">CAST Room Directory & Infrastructure</h1>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php if ($resRoomsList && mysqli_num_rows($resRoomsList) > 0): ?>
                    <?php mysqli_data_seek($resRoomsList, 0); while ($rm = mysqli_fetch_assoc($resRoomsList)): ?>
                        <div class="p-6 border-editorial bg-white space-y-3">
                            <div class="flex justify-between items-center border-b border-[#e5e4de] pb-2">
                                <span class="font-mono-tech text-xs font-bold text-[#3d7068]"><?= htmlspecialchars($rm['room_name']); ?></span>
                                <span class="font-mono-tech text-[9px] uppercase text-[#1c1c1c]/50"><?= htmlspecialchars($rm['building_name']); ?></span>
                            </div>
                            <p class="font-grotesk text-xs text-[#1c1c1c]/70">CAST Building Facility</p>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="col-span-full p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 border-editorial bg-white">
                        No rooms mapped in system directory.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- MANAGEMENT SECTION 3: FACULTY -->
        <div id="view-sec-faculty" class="hidden space-y-8 relative z-10">
            <div class="space-y-2">
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068]">Management Module 03</span>
                <h1 class="font-playfair text-4xl font-light uppercase text-[#1c1c1c]">Department Faculty Directory</h1>
            </div>

            <div class="border-editorial bg-white p-6">
                <div class="overflow-x-auto">
                    <table class="w-full border-collapse font-mono-tech text-xs">
                        <thead>
                            <tr class="border-b border-[#e5e4de] bg-[#f7f6f2] text-[10px] text-[#3d7068] uppercase text-left">
                                <th class="p-3">ID</th>
                                <th class="p-3">Faculty Name</th>
                                <th class="p-3">Department / Course</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($resTeachersList && mysqli_num_rows($resTeachersList) > 0): ?>
                                <?php mysqli_data_seek($resTeachersList, 0); while ($fac = mysqli_fetch_assoc($resTeachersList)): ?>
                                    <tr class="border-b border-[#e5e4de] hover:bg-[#f7f6f2]/50 transition-colors">
                                        <td class="p-3 font-bold text-[#3d7068]">PSU-FAC-<?= htmlspecialchars($fac['prof_id']); ?></td>
                                        <td class="p-3 font-bold text-[#1c1c1c]"><?= htmlspecialchars($fac['prof_name']); ?></td>
                                        <td class="p-3 text-[#1c1c1c]/70"><?= htmlspecialchars($fac['course_name'] ?? 'Department of Information Technology'); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="p-6 text-center text-[#1c1c1c]/50">No faculty members found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <!-- MODAL 1: ADD SCHEDULE ENTRY -->
    <div id="add-schedule-modal" class="fixed inset-0 z-50 bg-[#1c1c1c]/60 backdrop-blur-sm hidden items-center justify-center p-4">
        <div class="max-w-xl w-full bg-white border-editorial p-8 relative space-y-6">
            <button type="button" onclick="closeAddModal()" class="absolute top-6 right-6 font-mono-tech text-xs uppercase border-editorial px-3 py-1 bg-[#f7f6f2] hover:bg-red-50 hover:text-red-700 cursor-pointer">[ Close ESC ]</button>
            <h2 class="font-playfair text-2xl font-light uppercase text-[#1c1c1c] pb-3 border-b border-[#e5e4de]">Add Schedule Entry</h2>

            <form action="add_new_schedule.php" method="POST" class="space-y-4">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Instructor</label>
                        <select name="prof_id" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                            <option value="">Select Instructor...</option>
                            <?php if ($resTeachersList): mysqli_data_seek($resTeachersList, 0); while ($t = mysqli_fetch_assoc($resTeachersList)): ?>
                                <option value="<?= $t['prof_id']; ?>"><?= htmlspecialchars($t['prof_name']); ?></option>
                            <?php endwhile; endif; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Subject</label>
                        <select name="sub_id" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                            <option value="">Select Subject...</option>
                            <?php if ($resSubjectsList): mysqli_data_seek($resSubjectsList, 0); while ($s = mysqli_fetch_assoc($resSubjectsList)): ?>
                                <option value="<?= $s['sub_id']; ?>"><?= htmlspecialchars($s['subject_name']); ?></option>
                            <?php endwhile; endif; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Room</label>
                        <select name="room_id" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                            <option value="">Select Room...</option>
                            <?php if ($resRoomsList): mysqli_data_seek($resRoomsList, 0); while ($r = mysqli_fetch_assoc($resRoomsList)): ?>
                                <option value="<?= $r['room_id']; ?>"><?= htmlspecialchars($r['room_name']); ?></option>
                            <?php endwhile; endif; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Day</label>
                        <select name="day_of_week" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                            <option value="Monday">Monday</option>
                            <option value="Tuesday">Tuesday</option>
                            <option value="Wednesday">Wednesday</option>
                            <option value="Thursday">Thursday</option>
                            <option value="Friday">Friday</option>
                            <option value="Saturday">Saturday</option>
                        </select>
                    </div>

                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Start Time</label>
                        <input type="time" name="start_time" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                    </div>

                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">End Time</label>
                        <input type="time" name="end_time" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                    </div>
                </div>

                <button type="submit" class="w-full py-3.5 btn-editorial font-mono-tech text-[10px] uppercase border-editorial cursor-pointer">
                    + Allocate Timetable Entry
                </button>
            </form>
        </div>
    </div>

    <!-- MODAL 2: EDIT SCHEDULE ENTRY -->
    <div id="edit-schedule-modal" class="fixed inset-0 z-50 bg-[#1c1c1c]/60 backdrop-blur-sm hidden items-center justify-center p-4">
        <div class="max-w-xl w-full bg-white border-editorial p-8 relative space-y-6">
            <button type="button" onclick="closeEditModal()" class="absolute top-6 right-6 font-mono-tech text-xs uppercase border-editorial px-3 py-1 bg-[#f7f6f2] hover:bg-red-50 hover:text-red-700 cursor-pointer">[ Close ESC ]</button>
            <h2 class="font-playfair text-2xl font-light uppercase text-[#1c1c1c] pb-3 border-b border-[#e5e4de]">Edit Schedule Allocation</h2>

            <form action="edit_schedule.php" method="POST" class="space-y-4">
                <input type="hidden" name="sched_id" id="edit_sched_id">

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Instructor</label>
                        <select name="prof_id" id="edit_prof_id" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                            <?php if ($resTeachersList): mysqli_data_seek($resTeachersList, 0); while ($t = mysqli_fetch_assoc($resTeachersList)): ?>
                                <option value="<?= $t['prof_id']; ?>"><?= htmlspecialchars($t['prof_name']); ?></option>
                            <?php endwhile; endif; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Subject</label>
                        <select name="sub_id" id="edit_sub_id" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                            <?php if ($resSubjectsList): mysqli_data_seek($resSubjectsList, 0); while ($s = mysqli_fetch_assoc($resSubjectsList)): ?>
                                <option value="<?= $s['sub_id']; ?>"><?= htmlspecialchars($s['subject_name']); ?></option>
                            <?php endwhile; endif; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Room</label>
                        <select name="room_id" id="edit_room_id" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                            <?php if ($resRoomsList): mysqli_data_seek($resRoomsList, 0); while ($r = mysqli_fetch_assoc($resRoomsList)): ?>
                                <option value="<?= $r['room_id']; ?>"><?= htmlspecialchars($r['room_name']); ?></option>
                            <?php endwhile; endif; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Day</label>
                        <select name="day_of_week" id="edit_day_of_week" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                            <option value="Monday">Monday</option>
                            <option value="Tuesday">Tuesday</option>
                            <option value="Wednesday">Wednesday</option>
                            <option value="Thursday">Thursday</option>
                            <option value="Friday">Friday</option>
                            <option value="Saturday">Saturday</option>
                        </select>
                    </div>

                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Start Time</label>
                        <input type="time" name="start_time" id="edit_start_time" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                    </div>

                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">End Time</label>
                        <input type="time" name="end_time" id="edit_end_time" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c]">
                    </div>
                </div>

                <button type="submit" class="w-full py-3.5 btn-editorial font-mono-tech text-[10px] uppercase border-editorial cursor-pointer">
                    Save Schedule Updates
                </button>
            </form>
        </div>
    </div>

    <!-- CLIENT SCRIPT -->
    <script>
    function switchView(viewName) {
        ['dashboard', 'sec-schedule', 'sec-rooms', 'sec-faculty'].forEach(v => {
            const el = document.getElementById('view-' + v);
            const btn = document.getElementById('nav-' + v);
            if (el) el.classList.toggle('hidden', v !== viewName);
            if (btn) btn.classList.toggle('nav-item-active', v === viewName);
        });
    }

    function openAddModal() {
        const modal = document.getElementById('add-schedule-modal');
        if (modal) {
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
        }
    }

    function closeAddModal() {
        const modal = document.getElementById('add-schedule-modal');
        if (modal) {
            modal.classList.add('hidden');
            modal.style.display = 'none';
        }
    }

    function openEditModal(data) {
        document.getElementById('edit_sched_id').value = data.sched_id || data.id || '';
        document.getElementById('edit_prof_id').value = data.prof_id || '';
        document.getElementById('edit_sub_id').value = data.sub_id || '';
        document.getElementById('edit_room_id').value = data.room_id || '';
        document.getElementById('edit_day_of_week').value = data.day_of_week || 'Monday';
        document.getElementById('edit_start_time').value = data.start_time || '';
        document.getElementById('edit_end_time').value = data.end_time || '';

        const modal = document.getElementById('edit-schedule-modal');
        if (modal) {
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
        }
    }

    function closeEditModal() {
        const modal = document.getElementById('edit-schedule-modal');
        if (modal) {
            modal.classList.add('hidden');
            modal.style.display = 'none';
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        // Loading Screen Animation
        const ls = document.getElementById('loading-screen');
        const fill = document.getElementById('ls-fill');
        const pct = document.getElementById('ls-pct');
        const status = document.getElementById('ls-status');

        if (ls) {
            let progress = 0;
            const stages = [
                { p: 35, msg: 'Verifying Session...' },
                { p: 70, msg: 'Loading Management Modules...' },
                { p: 100, msg: 'System Ready' }
            ];

            let currentStage = 0;

            const interval = setInterval(() => {
                if (currentStage < stages.length) {
                    progress = stages[currentStage].p;
                    if (fill) fill.style.width = progress + '%';
                    if (pct) pct.innerText = progress + '%';
                    if (status) status.innerText = stages[currentStage].msg;
                    currentStage++;
                } else {
                    clearInterval(interval);
                    setTimeout(() => {
                        ls.style.transition = 'opacity 500ms ease-out, visibility 500ms';
                        ls.style.opacity = '0';
                        ls.style.visibility = 'hidden';
                        setTimeout(() => ls.remove(), 500);
                    }, 300);
                }
            }, 200);
        }

        // Close modals on background click
        ['add-schedule-modal', 'edit-schedule-modal'].forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.addEventListener('click', (e) => {
                    if (e.target.id === id) {
                        closeAddModal();
                        closeEditModal();
                    }
                });
            }
        });

        // Close on ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeAddModal();
                closeEditModal();
            }
        });
    });
    </script>
</body>
</html>