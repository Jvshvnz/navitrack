<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../Sys_Database/db_connection.php';

global $conn;
try {
    $sql = <<<'SQL'
        SELECT
            rs.sched_id AS teacher_sched_id,
            t.prof_name,
            s.subject_name,
            b.blocks,
            r.room_name,
            rs.day_of_week,
            rs.start_time,
            rs.end_time,
            rs.prof_id
        FROM room_sched AS rs
        INNER JOIN teachers AS t ON rs.prof_id = t.prof_id
        INNER JOIN subjects AS s ON rs.sub_id = s.sub_id
        INNER JOIN blocks AS b ON rs.block_id = b.block_id
        INNER JOIN room_list AS r ON rs.room_id = r.room_id
        ORDER BY t.prof_name, s.subject_name, rs.day_of_week, rs.start_time
    SQL;
    $result = $conn->query($sql);
    echo json_encode($result->fetch_all(MYSQLI_ASSOC), JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('CHAIRPERSON/get_room_schedules.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Unable to load room schedules.']);
}
?>
