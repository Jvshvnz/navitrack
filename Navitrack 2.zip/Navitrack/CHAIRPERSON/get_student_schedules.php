<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../Sys_Database/db_connection.php';

global $conn;
try {
    $sql = <<<'SQL'
        SELECT
            ts.teacher_sched_id AS student_sched_id,
            b.block_id AS block_name,
            cl.course_name AS program,
            s.subject_name,
            t.prof_name AS instructor_name,
            r.room_name,
            ts.day_of_week,
            ts.start_time,
            ts.end_time
        FROM teacher_schedule AS ts
        INNER JOIN blocks AS b ON ts.block_id = b.block_id
        INNER JOIN subjects AS s ON ts.sub_id = s.sub_id
        INNER JOIN teachers AS t ON ts.prof_id = t.prof_id
        INNER JOIN room_list AS r ON ts.room_id = r.room_id
        LEFT JOIN course_list AS cl ON b.course_id = cl.course_id
        ORDER BY b.block_id, s.subject_name, ts.day_of_week, ts.start_time
    SQL;
    $result = $conn->query($sql);
    echo json_encode($result->fetch_all(MYSQLI_ASSOC), JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('CHAIRPERSON/get_student_schedules.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Unable to load student schedules.']);
}
?>
