<?php
require_once __DIR__ . '/../Sys_Database/db_connection.php';

global $conn;
function post_string(string $key): string { return trim((string)($_POST[$key] ?? '')); }
$school_year = post_string('school_year');
$semester = post_string('sy_sem_id');
$prof_id = filter_input(INPUT_POST, 'prof_id', FILTER_VALIDATE_INT);
$room_id = filter_input(INPUT_POST, 'room_id', FILTER_VALIDATE_INT);
$sub_id = post_string('sub_id');
$block_id = post_string('block_id');
$course_id = filter_input(INPUT_POST, 'course_id', FILTER_VALIDATE_INT);
$day = strtoupper(post_string('day'));
$start_time = post_string('start_time');
$end_time = post_string('end_time');
if ($school_year === '' || $semester === '' || $prof_id === false || $prof_id === null || $room_id === false || $room_id === null || $sub_id === '' || $block_id === '' || $course_id === false || $course_id === null || $day === '' || $start_time === '' || $end_time === '') {
    http_response_code(400); exit('All schedule fields are required.');
}
try {
    $stmt = $conn->prepare('INSERT INTO teacher_schedule (school_year, semester, prof_id, room_id, sub_id, block_id, course_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('ssiississs', $school_year, $semester, $prof_id, $room_id, $sub_id, $block_id, $course_id, $day, $start_time, $end_time);
    $stmt->execute();
    header('Location: chair.php'); exit;
} catch (Throwable $e) {
    error_log('CHAIRPERSON/add_new_schedule.php: ' . $e->getMessage());
    http_response_code(500); exit('Unable to save the schedule.');
}
?>
