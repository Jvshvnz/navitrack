<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../Sys_Database/db_connection.php';

if (!isset($_SESSION['user_id'])) { header("Location: ../LOGIN/login.php"); exit(); }

$msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $building_name = trim($_POST['building_name'] ?? $_POST['name'] ?? '');
    $building_code = trim($_POST['building_code'] ?? $_POST['code'] ?? 'CAST');

    if (!empty($building_name)) {
        try {
            $stmt = $conn->prepare("INSERT INTO buildings (building_name, building_code) VALUES (?, ?)");
            $stmt->bind_param("ss", $building_name, $building_code);
            if ($stmt->execute()) {
                header("Location: superAdmin.php");
                exit();
            } else {
                $msg = "Execution failed.";
            }
            $stmt->close();
        } catch (Exception $e) {
            // Fallback for schemas with single column
            try {
                $stmt2 = $conn->prepare("INSERT INTO building (building_name) VALUES (?)");
                $stmt2->bind_param("s", $building_name);
                if ($stmt2->execute()) { header("Location: superAdmin.php"); exit(); }
            } catch (Exception $e2) {
                $msg = "Database Error: " . $e2->getMessage();
            }
        }
    } else {
        $msg = "Building name is required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Navi Track • Add Building</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600&family=Space+Grotesk:wght@400;500&family=Space+Mono&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background-color: #f7f6f2; color: #1c1c1c; font-family: 'Space Grotesk', sans-serif; }
        .font-playfair { font-family: 'Playfair Display', serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .border-editorial { border: 1px solid #e5e4de; border-radius: 2px !important; }
        .btn-editorial { background-color: #3d7068; color: #ffffff; letter-spacing: 0.15em; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-6">
    <div class="max-w-md w-full border-editorial bg-white p-8 space-y-6">
        <div class="flex justify-between items-center border-b border-[#e5e4de] pb-4">
            <h1 class="font-playfair text-2xl uppercase font-light">Add Building</h1>
            <a href="superAdmin.php" class="font-mono-tech text-xs text-[#3d7068] hover:underline">[ Return ]</a>
        </div>
        <?php if ($msg): ?><p class="text-xs text-red-600 font-mono-tech border p-2 border-red-200 bg-red-50"><?php echo htmlspecialchars($msg); ?></p><?php endif; ?>
        <form action="add_building.php" method="POST" class="space-y-4 font-mono-tech text-xs">
            <div>
                <label class="block uppercase mb-1">Building Name</label>
                <input type="text" name="building_name" required placeholder="College of Arts and Sciences" class="w-full p-3 border-editorial bg-[#f7f6f2] focus:outline-none">
            </div>
            <div>
                <label class="block uppercase mb-1">Building Code / Tag</label>
                <input type="text" name="building_code" required placeholder="CAST" class="w-full p-3 border-editorial bg-[#f7f6f2] focus:outline-none">
            </div>
            <button type="submit" class="w-full py-3.5 btn-editorial uppercase text-[10px]">Save Building</button>
        </form>
    </div>
</body>
</html>