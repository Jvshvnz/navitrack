<?php
// SUPAD/add_user_process.php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../Sys_Database/db_connection.php';

// Authenticate session role
if (!isset($_SESSION['user_id'])) {
    header("Location: ../LOGIN/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role_id  = intval($_POST['role_id'] ?? 3);

    // Validation
    if (empty($username) || empty($email) || empty($password)) {
        header("Location: superAdmin.php?error=empty_fields");
        exit();
    }

    // Hash the password for database security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if username or email already exists
    $check_stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
    $check_stmt->bind_param("ss", $username, $email);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        $check_stmt->close();
        header("Location: superAdmin.php?error=user_exists");
        exit();
    }
    $check_stmt->close();

    // Insert new user into users table
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, role_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $username, $email, $hashed_password, $role_id);

    if ($stmt->execute()) {
        $stmt->close();
        
        // If the added role is FACULTY (role_id = 2), attempt insertion into teachers table with column fallbacks
        if ($role_id === 2) {
            $teacher_inserted = false;
            $queries = [
                "INSERT INTO teachers (name, email) VALUES (?, ?)",
                "INSERT INTO teachers (username, email) VALUES (?, ?)",
                "INSERT INTO teachers (fullname, email) VALUES (?, ?)",
                "INSERT INTO teachers (teacher_name, email) VALUES (?, ?)"
            ];

            foreach ($queries as $sql) {
                try {
                    $t_stmt = $conn->prepare($sql);
                    if ($t_stmt) {
                        $t_stmt->bind_param("ss", $username, $email);
                        if ($t_stmt->execute()) {
                            $t_stmt->close();
                            $teacher_inserted = true;
                            break;
                        }
                        $t_stmt->close();
                    }
                } catch (Exception $e) {
                    continue; // try next column name fallback
                }
            }
        }

        header("Location: superAdmin.php?msg=user_added");
        exit();
    } else {
        $stmt->close();
        header("Location: superAdmin.php?error=db_error");
        exit();
    }
} else {
    header("Location: superAdmin.php");
    exit();
}