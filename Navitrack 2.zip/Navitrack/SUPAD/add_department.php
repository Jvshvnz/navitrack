<?php
session_start();
require_once '../Sys_Database/db_connection.php';

// Ensure response is JSON for clean fetch/AJAX integration
header('Content-Type: application/json');

// Check Super Admin privileges (Role 1 in Super Admin context)
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize incoming fields (supports both form-data and JSON bodies)
    $dept_code = trim($_POST['dept_code'] ?? $_POST['department_code'] ?? '');
    $dept_name = trim($_POST['dept_name'] ?? $_POST['department_name'] ?? '');

    if (empty($dept_code) || empty($dept_name)) {
        echo json_encode(['status' => 'error', 'message' => 'Please fill in all required department fields.']);
        exit();
    }

    // Prepared statement to prevent SQL injection and duplicate key crashes
    $stmt = $conn->prepare("INSERT INTO departments (dept_code, dept_name) VALUES (?, ?)");
    if ($stmt) {
        $stmt->bind_param("ss", $dept_code, $dept_name);
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Department added successfully!']);
        } else {
            // Check for duplicate entry (MySQL error 1062)
            if ($conn->errno === 1062) {
                echo json_encode(['status' => 'error', 'message' => 'Department code already exists.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $stmt->error]);
            }
        }
        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to prepare query: ' . $conn->error]);
    }
} else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>