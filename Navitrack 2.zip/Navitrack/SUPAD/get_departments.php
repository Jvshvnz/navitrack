<?php
session_start();
require_once '../Sys_Database/db_connection.php';

// JSON Fetch Handler for AJAX / JavaScript calls
if (isset($_GET['action']) && $_GET['action'] === 'fetch') {
    header('Content-Type: application/json');
    
    $departments = [];
    $query = "SELECT * FROM departments ORDER BY department_id ASC";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $departments[] = [
                'department_id'   => $row['department_id'] ?? $row['id'] ?? '',
                'dept_code'       => $row['dept_code'] ?? $row['department_code'] ?? $row['code'] ?? '',
                'dept_name'       => $row['dept_name'] ?? $row['department_name'] ?? $row['name'] ?? ''
            ];
        }
    }
    
    echo json_encode($departments);
    exit();
}

// Form Submission Handler (Add New Department)
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_department'])) {
    $dept_code = trim($_POST['dept_code']);
    $dept_name = trim($_POST['dept_name']);

    if (!empty($dept_code) && !empty($dept_name)) {
        $stmt = $conn->prepare("INSERT INTO departments (dept_code, dept_name) VALUES (?, ?)");
        $stmt->bind_param("ss", $dept_code, $dept_name);
        
        if ($stmt->execute()) {
            $message = "<div class='alert alert-success'>Department added successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error adding department: " . $conn->error . "</div>";
        }
        $stmt->close();
    } else {
        $message = "<div class='alert alert-warning'>Please fill in all required fields.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Department Management - Super Admin</title>
    <link rel="stylesheet" href="../assets/css/editorial-theme.css">
</head>
<body>
    <div class="container my-4">
        <h2>Department Management</h2>
        <?= $message ?>

        <!-- Form for Adding New Department -->
        <form method="POST" action="add_department.php" class="mb-4">
            <div class="row">
                <div class="col-md-4 mb-2">
                    <input type="text" name="dept_code" class="form-control" placeholder="Department Code (e.g. IT)" required>
                </div>
                <div class="col-md-6 mb-2">
                    <input type="text" name="dept_name" class="form-control" placeholder="Department Name (e.g. Information Technology)" required>
                </div>
                <div class="col-md-2 mb-2">
                    <button type="submit" name="add_department" class="btn btn-primary w-100">Add</button>
                </div>
            </div>
        </form>

        <!-- Dynamic Department Table Container -->
        <div id="departmentTable">
            <table class="table table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Department ID</th>
                        <th>Code</th>
                        <th>Department Name</th>
                    </tr>
                </thead>
                <tbody id="department-list">
                    <!-- JavaScript populates rows here -->
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>