<?php
// SUPAD/superAdmin.php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../Sys_Database/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../LOGIN/login.php");
    exit();
}

$username = $_SESSION['username'] ?? 'SuperAdmin';

// Safe helper query function supporting plural table fallbacks
function getCount($conn, $queries) {
    if (!is_array($queries)) { $queries = [$queries]; }
    foreach ($queries as $sql) {
        try {
            $res = $conn->query($sql);
            if ($res && $row = $res->fetch_assoc()) {
                return $row['count'];
            }
        } catch (Exception $e) {
            continue;
        }
    }
    return 0;
}
// Safely compute sidebar counts matching your exact MySQL tables
$total_users       = getCount($conn, ["SELECT COUNT(*) as count FROM users"]);
$total_buildings   = getCount($conn, ["SELECT COUNT(*) as count FROM buildings", "SELECT COUNT(*) as count FROM building"]);
$total_rooms       = getCount($conn, ["SELECT COUNT(*) as count FROM rooms", "SELECT COUNT(*) as count FROM room"]);
$total_subjects    = getCount($conn, ["SELECT COUNT(*) as count FROM subjects"]);
$total_blocks      = getCount($conn, ["SELECT COUNT(*) as count FROM blocks"]);
$total_instructors = getCount($conn, ["SELECT COUNT(*) as count FROM teachers", "SELECT COUNT(*) as count FROM users WHERE role_id = 2"]);
$total_depts       = getCount($conn, ["SELECT COUNT(*) as count FROM departments"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navi Track • SuperAdmin Control Portal</title>
    
    <!-- Typography & Styling -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Space+Grotesk:wght@300..700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="adminstyle.css">

    <style>
        :root {
            --bg-organic: #f7f6f2;
            --fg-dark: #1c1c1c;
            --accent-green: #3d7068;
            --border-line: #e5e4de;
            --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
        }

        body {
            background-color: var(--bg-organic);
            color: var(--fg-dark);
            font-family: 'Space Grotesk', sans-serif;
            margin: 0;
            padding: 0;
        }

        .font-playfair { font-family: 'Playfair Display', Georgia, serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .font-grotesk { font-family: 'Space Grotesk', sans-serif; }

        .editorial-grid-bg {
            background-size: 40px 40px;
            background-image: 
                linear-gradient(to right, rgba(229, 228, 222, 0.6) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(229, 228, 222, 0.6) 1px, transparent 1px);
            mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
            -webkit-mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
        }

        .border-editorial {
            border: 1px solid var(--border-line);
            border-radius: 2px !important;
        }

        .btn-editorial {
            background-color: var(--accent-green);
            color: #ffffff;
            transition: letter-spacing 400ms var(--ease-editorial);
            letter-spacing: 0.15em;
        }
        .btn-editorial:hover {
            letter-spacing: 0.25em;
        }

        @keyframes scanSlide {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}
.animate-scan {
    animation: scanSlide 1.8s infinite cubic-bezier(0.8, 0, 0.2, 1);
}
    </style>

    <!-- GUARANTEED GLOBAL NAVIGATION & MODAL FUNCTIONS -->
    <script>
        window.switchView = function(viewName) {
            const panels = document.querySelectorAll('.view-panel');
            panels.forEach(panel => panel.classList.add('hidden'));

            const selectedPanel = document.getElementById('view-' + viewName);
            if (selectedPanel) {
                selectedPanel.classList.remove('hidden');
            }

            const titles = {
                'users': 'User Accounts',
                'year': 'School Year Management',
                'semester': 'Semester Allocation',
                'building': 'Building Infrastructure',
                'room': 'Rooms & Laboratories',
                'subject': 'Curriculum Subjects',
                'block': 'Section Blocks',
                'instructor': 'Faculty Instructors',
                'department': 'Academic Departments'
            };
            const activeTitle = document.getElementById('activeViewTitle');
            if (activeTitle) {
                activeTitle.textContent = titles[viewName] || 'System Management';
            }
        };

        window.toggleSystemMgmt = function() {
            const menu = document.getElementById('systemMgmtMenu');
            const chevron = document.getElementById('mgmtChevron');
            if (menu) menu.classList.toggle('hidden');
            if (chevron) chevron.classList.toggle('rotate-180');
        };

        window.openEditModal = function(type, id, val1 = '', val2 = '', val3 = '') {
            const modal = document.getElementById('editModal');
            const modalTitle = document.getElementById('modalTitle');
            const modalFields = document.getElementById('modalFields');
            
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_type').value = type;
            modalFields.innerHTML = '';

            switch(type) {
                case 'user':
                case 'instructor':
                    modalTitle.textContent = 'Edit User / Instructor';
                    modalFields.innerHTML = `
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Username / Identifier</label>
                            <input type="text" name="username" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                        </div>
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Email</label>
                            <input type="email" name="email" value="${val2}" class="w-full p-2 border-editorial text-xs" required>
                        </div>`;
                    break;

                case 'year':
                    modalTitle.textContent = 'Edit School Year';
                    modalFields.innerHTML = `
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Academic Year</label>
                            <input type="text" name="sy_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                        </div>`;
                    break;

                case 'semester':
                    modalTitle.textContent = 'Edit Semester';
                    modalFields.innerHTML = `
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Semester Name</label>
                            <input type="text" name="sem_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                        </div>`;
                    break;

                case 'building':
                    modalTitle.textContent = 'Edit Building';
                    modalFields.innerHTML = `
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Building Name</label>
                            <input type="text" name="building_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                        </div>
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Building Code</label>
                            <input type="text" name="building_code" value="${val2}" class="w-full p-2 border-editorial text-xs" required>
                        </div>`;
                    break;

                case 'room':
                    modalTitle.textContent = 'Edit Room';
                    modalFields.innerHTML = `
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Room Name / Number</label>
                            <input type="text" name="room_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                        </div>
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Building ID</label>
                            <input type="number" name="building_id" value="${val2}" class="w-full p-2 border-editorial text-xs" required>
                        </div>`;
                    break;

                case 'subject':
                    modalTitle.textContent = 'Edit Subject';
                    modalFields.innerHTML = `
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Subject Code</label>
                            <input type="text" name="subject_code" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                        </div>
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Subject Title</label>
                            <input type="text" name="subject_title" value="${val2}" class="w-full p-2 border-editorial text-xs" required>
                        </div>`;
                    break;

                case 'block':
                    modalTitle.textContent = 'Edit Section Block';
                    modalFields.innerHTML = `
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Section / Block Name</label>
                            <input type="text" name="block_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                        </div>`;
                    break;

                case 'department':
                    modalTitle.textContent = 'Edit Department';
                    modalFields.innerHTML = `
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase mb-1">Department Name</label>
                            <input type="text" name="dept_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                        </div>`;
                    break;
            }

            if (modal) modal.classList.remove('hidden');
        };

        window.closeEditModal = function() {
            const modal = document.getElementById('editModal');
            if (modal) modal.classList.add('hidden');
        };
        window.openAddUserModal = function() {
    const modal = document.getElementById('addUserModal');
    if (modal) modal.classList.remove('hidden');
};

window.closeAddUserModal = function() {
    const modal = document.getElementById('addUserModal');
    if (modal) modal.classList.add('hidden');
};

window.openEditModal = function(type, id, val1 = '', val2 = '', val3 = '') {
    const modal = document.getElementById('editModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalFields = document.getElementById('modalFields');
    
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_type').value = type;
    modalFields.innerHTML = '';

    switch(type) {
        case 'user':
            modalTitle.textContent = 'Edit User Account';
            modalFields.innerHTML = `
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Username / Identifier</label>
                    <input type="text" name="username" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                </div>
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Email Contact</label>
                    <input type="email" name="email" value="${val2}" class="w-full p-2 border-editorial text-xs" required>
                </div>
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Role Designation</label>
                    <select name="role_id" class="w-full p-2 border-editorial text-xs bg-white" required>
                        <option value="1" ${val3 == '1' ? 'selected' : ''}>ADMIN</option>
                        <option value="2" ${val3 == '2' ? 'selected' : ''}>FACULTY</option>
                        <option value="3" ${val3 == '3' ? 'selected' : ''}>STUDENT</option>
                    </select>
                </div>`;
            break;

        case 'instructor':
            modalTitle.textContent = 'Edit Instructor';
            modalFields.innerHTML = `
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Teacher Name</label>
                    <input type="text" name="username" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                </div>
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Email</label>
                    <input type="email" name="email" value="${val2}" class="w-full p-2 border-editorial text-xs" required>
                </div>`;
            break;

        case 'year':
            modalTitle.textContent = 'Edit School Year';
            modalFields.innerHTML = `
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Academic Year</label>
                    <input type="text" name="sy_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                </div>`;
            break;

        case 'semester':
            modalTitle.textContent = 'Edit Semester';
            modalFields.innerHTML = `
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Semester Name</label>
                    <input type="text" name="sem_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                </div>`;
            break;

        case 'building':
            modalTitle.textContent = 'Edit Building';
            modalFields.innerHTML = `
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Building Name</label>
                    <input type="text" name="building_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                </div>
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Building Code</label>
                    <input type="text" name="building_code" value="${val2}" class="w-full p-2 border-editorial text-xs" required>
                </div>`;
            break;

        case 'room':
            modalTitle.textContent = 'Edit Room';
            modalFields.innerHTML = `
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Room Name / Number</label>
                    <input type="text" name="room_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                </div>
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Building ID</label>
                    <input type="number" name="building_id" value="${val2}" class="w-full p-2 border-editorial text-xs" required>
                </div>`;
            break;

        case 'subject':
            modalTitle.textContent = 'Edit Subject';
            modalFields.innerHTML = `
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Subject Code</label>
                    <input type="text" name="subject_code" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                </div>
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Subject Title</label>
                    <input type="text" name="subject_title" value="${val2}" class="w-full p-2 border-editorial text-xs" required>
                </div>`;
            break;

        case 'block':
            modalTitle.textContent = 'Edit Section Block';
            modalFields.innerHTML = `
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Section / Block Name</label>
                    <input type="text" name="block_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                </div>`;
            break;

        case 'department':
            modalTitle.textContent = 'Edit Department';
            modalFields.innerHTML = `
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase mb-1">Department Name</label>
                    <input type="text" name="dept_name" value="${val1}" class="w-full p-2 border-editorial text-xs" required>
                </div>`;
            break;
    }

    if (modal) modal.classList.remove('hidden');
};
    </script>
</head>
<body class="relative min-h-screen overflow-x-hidden antialiased">

    <!-- Background Grid -->
    <div class="fixed inset-0 pointer-events-none z-0 editorial-grid-bg"></div>

    <!-- MAIN DASHBOARD FLEX WRAPPER -->
    <div class="relative z-10 flex flex-row min-h-screen w-full">

        <!-- LEFT SIDEBAR CONTAINER -->
        <aside class="w-80 bg-white border-r border-[#e5e4de] flex flex-col justify-between p-6 shrink-0 h-screen sticky top-0 overflow-y-auto z-20">
            <div class="space-y-6">
                
                <!-- BRANDING -->
                <div class="flex items-center gap-3">
                    <div style="height: 40px; width: 40px; flex-shrink: 0;" class="overflow-hidden flex items-center justify-center">
                        <img src="../assets/images/NaviTrack_Logo.png" 
                             alt="NaviTrack Logo" 
                             style="max-height: 100%; max-width: 100%; object-fit: contain;">
                    </div>
                    <span class="font-playfair text-2xl uppercase tracking-widest text-[#1c1c1c]">Navi Track</span>
                </div>

                <!-- SYSTEM MANAGEMENT MENU -->
                <div class="space-y-2">
                    <button type="button" onclick="toggleSystemMgmt()" 
                            class="w-full py-3 px-4 bg-[#f7f6f2] border-editorial flex items-center justify-between font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c] font-bold hover:border-[#3d7068] transition-colors cursor-pointer">
                        <div class="flex items-center gap-2 pointer-events-none">
                            <i class="fa-solid fa-sliders text-[#3d7068]"></i>
                            <span>System Management</span>
                        </div>
                        <i id="mgmtChevron" class="fa-solid fa-chevron-down text-xs transition-transform duration-300 pointer-events-none"></i>
                    </button>

                    <div id="systemMgmtMenu" class="pl-2 space-y-1 font-mono-tech text-[10px] uppercase tracking-wider border-l-2 border-[#3d7068] my-2">
                        <button type="button" onclick="switchView('users')" class="w-full text-left block py-2 px-3 text-[#1c1c1c]/70 hover:text-[#3d7068] hover:bg-[#f7f6f2] transition-colors cursor-pointer">User Accounts</button>
                        <button type="button" onclick="switchView('year')" class="w-full text-left block py-2 px-3 text-[#1c1c1c]/70 hover:text-[#3d7068] hover:bg-[#f7f6f2] transition-colors cursor-pointer">School Year</button>
                        <button type="button" onclick="switchView('semester')" class="w-full text-left block py-2 px-3 text-[#1c1c1c]/70 hover:text-[#3d7068] hover:bg-[#f7f6f2] transition-colors cursor-pointer">Semester</button>
                        <button type="button" onclick="switchView('building')" class="w-full text-left block py-2 px-3 text-[#1c1c1c]/70 hover:text-[#3d7068] hover:bg-[#f7f6f2] transition-colors cursor-pointer">Building</button>
                        <button type="button" onclick="switchView('room')" class="w-full text-left block py-2 px-3 text-[#1c1c1c]/70 hover:text-[#3d7068] hover:bg-[#f7f6f2] transition-colors cursor-pointer">Room</button>
                        <button type="button" onclick="switchView('subject')" class="w-full text-left block py-2 px-3 text-[#1c1c1c]/70 hover:text-[#3d7068] hover:bg-[#f7f6f2] transition-colors cursor-pointer">Subject</button>
                        <button type="button" onclick="switchView('block')" class="w-full text-left block py-2 px-3 text-[#1c1c1c]/70 hover:text-[#3d7068] hover:bg-[#f7f6f2] transition-colors cursor-pointer">Block</button>
                        <button type="button" onclick="switchView('instructor')" class="w-full text-left block py-2 px-3 text-[#1c1c1c]/70 hover:text-[#3d7068] hover:bg-[#f7f6f2] transition-colors cursor-pointer">Instructor</button>
                        <button type="button" onclick="switchView('department')" class="w-full text-left block py-2 px-3 text-[#1c1c1c]/70 hover:text-[#3d7068] hover:bg-[#f7f6f2] transition-colors cursor-pointer">Department</button>
                    </div>
                </div>

                <!-- METRICS OVERVIEW -->
                <div class="space-y-3 pt-2">
                    <div class="font-mono-tech text-[9px] uppercase tracking-[0.25em] text-[#3d7068] border-b border-[#e5e4de] pb-1">
                        [ Metrics Overview ]
                    </div>

                    <div class="grid grid-cols-2 gap-2.5">
                        <div onclick="switchView('users')" class="border-editorial p-3 bg-white hover:bg-[#f7f6f2] transition-colors cursor-pointer">
                            <div class="flex justify-between items-center text-[#1c1c1c]/40 text-xs pointer-events-none"><i class="fa-solid fa-users"></i><span class="font-mono-tech text-[8px]">01</span></div>
                            <div class="font-playfair text-xl font-bold text-[#1c1c1c] mt-1 pointer-events-none"><?php echo $total_users; ?></div>
                            <div class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] pointer-events-none">Users</div>
                        </div>

                        <div onclick="switchView('year')" class="border-editorial p-3 bg-white hover:bg-[#f7f6f2] transition-colors cursor-pointer">
                            <div class="flex justify-between items-center text-[#1c1c1c]/40 text-xs pointer-events-none"><i class="fa-solid fa-calendar"></i><span class="font-mono-tech text-[8px]">02</span></div>
                            <div class="font-playfair text-xs font-bold text-[#1c1c1c] mt-2 pointer-events-none">2026-2027</div>
                            <div class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] mt-1 pointer-events-none">Current SY</div>
                        </div>

                        <div onclick="switchView('building')" class="border-editorial p-3 bg-white hover:bg-[#f7f6f2] transition-colors cursor-pointer">
                            <div class="flex justify-between items-center text-[#1c1c1c]/40 text-xs pointer-events-none"><i class="fa-solid fa-building"></i><span class="font-mono-tech text-[8px]">03</span></div>
                            <div class="font-playfair text-xl font-bold text-[#1c1c1c] mt-1 pointer-events-none"><?php echo $total_buildings; ?></div>
                            <div class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] pointer-events-none">Buildings</div>
                        </div>

                        <div onclick="switchView('room')" class="border-editorial p-3 bg-white hover:bg-[#f7f6f2] transition-colors cursor-pointer">
                            <div class="flex justify-between items-center text-[#1c1c1c]/40 text-xs pointer-events-none"><i class="fa-solid fa-door-open"></i><span class="font-mono-tech text-[8px]">04</span></div>
                            <div class="font-playfair text-xl font-bold text-[#1c1c1c] mt-1 pointer-events-none"><?php echo $total_rooms; ?></div>
                            <div class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] pointer-events-none">Rooms</div>
                        </div>

                        <div onclick="switchView('subject')" class="border-editorial p-3 bg-white hover:bg-[#f7f6f2] transition-colors cursor-pointer">
                            <div class="flex justify-between items-center text-[#1c1c1c]/40 text-xs pointer-events-none"><i class="fa-solid fa-book"></i><span class="font-mono-tech text-[8px]">05</span></div>
                            <div class="font-playfair text-xl font-bold text-[#1c1c1c] mt-1 pointer-events-none"><?php echo $total_subjects; ?></div>
                            <div class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] pointer-events-none">Subjects</div>
                        </div>

                        <div onclick="switchView('block')" class="border-editorial p-3 bg-white hover:bg-[#f7f6f2] transition-colors cursor-pointer">
                            <div class="flex justify-between items-center text-[#1c1c1c]/40 text-xs pointer-events-none"><i class="fa-solid fa-cubes"></i><span class="font-mono-tech text-[8px]">06</span></div>
                            <div class="font-playfair text-xl font-bold text-[#1c1c1c] mt-1 pointer-events-none"><?php echo $total_blocks; ?></div>
                            <div class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] pointer-events-none">Blocks</div>
                        </div>

                        <div onclick="switchView('instructor')" class="border-editorial p-3 bg-white hover:bg-[#f7f6f2] transition-colors cursor-pointer">
                            <div class="flex justify-between items-center text-[#1c1c1c]/40 text-xs pointer-events-none"><i class="fa-solid fa-user-graduate"></i><span class="font-mono-tech text-[8px]">07</span></div>
                            <div class="font-playfair text-xl font-bold text-[#1c1c1c] mt-1 pointer-events-none"><?php echo $total_instructors; ?></div>
                            <div class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] pointer-events-none">Instructors</div>
                        </div>

                        <div onclick="switchView('department')" class="border-editorial p-3 bg-white hover:bg-[#f7f6f2] transition-colors cursor-pointer">
                            <div class="flex justify-between items-center text-[#1c1c1c]/40 text-xs pointer-events-none"><i class="fa-solid fa-sitemap"></i><span class="font-mono-tech text-[8px]">08</span></div>
                            <div class="font-playfair text-xl font-bold text-[#1c1c1c] mt-1 pointer-events-none"><?php echo $total_depts; ?></div>
                            <div class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] pointer-events-none">Departments</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Logout -->
            <div class="pt-4 border-t border-[#e5e4de] mt-auto">
                <a href="../LOGIN/login.php" class="w-full py-2.5 border-editorial font-mono-tech text-[10px] uppercase text-center block text-red-700 hover:bg-red-50 transition-colors">
                    Logout
                </a>
            </div>
        </aside>

        <!-- RIGHT MAIN CONTENT PANEL CONTAINER -->
        <main class="flex-1 p-10 space-y-10 overflow-y-auto z-10 min-w-0">
            
            <div class="flex items-center justify-between pb-6 border-b border-[#e5e4de]">
                <div>
                    <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068] block mb-1">
                        System Management Portal
                    </span>
                    <h1 id="activeViewTitle" class="font-playfair text-4xl uppercase font-light text-[#1c1c1c]">User Accounts</h1>
                </div>
                <div class="font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50">
                    SUPERADMIN: <?php echo htmlspecialchars($username); ?>
                </div>
            </div>

<!-- VIEW 1: USER ACCOUNTS -->
<section id="view-users" class="view-panel border-editorial bg-white p-8 space-y-6">
    <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
        <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">[ Registered Users Table ]</div>
        <button type="button" onclick="openAddUserModal()" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase border-editorial cursor-pointer">+ Add Account</button>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-left text-xs font-grotesk">
            <thead class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] border-b border-[#e5e4de] bg-[#f7f6f2]">
                <tr>
                    <th class="p-4">User ID</th>
                    <th class="p-4">Identifier</th>
                    <th class="p-4">Email Contact</th>
                    <th class="p-4">Role Designation</th>
                    <th class="p-4 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-[#e5e4de]">
                <?php
                // Ordered sequentially by user_id ASC
                $user_res = $conn->query("SELECT user_id, role_id, username, email FROM users ORDER BY user_id ASC");
                if ($user_res && $user_res->num_rows > 0):
                    while ($row = $user_res->fetch_assoc()):
                        $role_name = ($row['role_id'] == 1) ? 'ADMIN' : (($row['role_id'] == 2) ? 'FACULTY' : 'STUDENT');
                ?>
                    <tr class="hover:bg-[#f7f6f2] transition-colors">
                        <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/60">#<?php echo htmlspecialchars($row['user_id']); ?></td>
                        <td class="p-4 font-semibold text-[#1c1c1c]"><?php echo htmlspecialchars($row['username']); ?></td>
                        <td class="p-4 text-[#1c1c1c]/70 font-mono-tech text-[11px]"><?php echo htmlspecialchars($row['email']); ?></td>
                        <td class="p-4"><span class="px-2.5 py-1 font-mono-tech text-[9px] uppercase border-editorial bg-[#f7f6f2] text-[#3d7068]"><?php echo $role_name; ?></span></td>
                        <td class="p-4 text-right">
                            <button type="button" onclick="openEditModal('user', '<?= $row['user_id']; ?>', '<?= htmlspecialchars($row['username'], ENT_QUOTES); ?>', '<?= htmlspecialchars($row['email'], ENT_QUOTES); ?>', '<?= $row['role_id']; ?>')" class="px-3 py-1.5 border-editorial font-mono-tech text-[9px] uppercase hover:bg-[#3d7068] hover:text-white transition-colors cursor-pointer">Edit</button>
                        </td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr><td colspan="5" class="p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 uppercase">No user records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
            <!-- VIEW 2: SCHOOL YEAR -->
            <section id="view-year" class="view-panel hidden border-editorial bg-white p-8 space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">[ School Year Directory ]</div>
                    <a href="add_year.php" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase border-editorial">+ Add School Year</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs font-grotesk">
                        <thead class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] border-b border-[#e5e4de] bg-[#f7f6f2]">
                            <tr><th class="p-4">SY ID</th><th class="p-4">Academic Year</th><th class="p-4">Status</th><th class="p-4 text-right">Actions</th></tr>
                        </thead>
                        <tbody class="divide-y divide-[#e5e4de]">
    <?php
    $sy_res = $conn->query("SELECT * FROM school_year ORDER BY 1 DESC");
    if ($sy_res && $sy_res->num_rows > 0):
        while ($row = $sy_res->fetch_assoc()):
            $id   = $row['sy_id'] ?? $row['id'] ?? '1';
            $name = $row['sy_name'] ?? $row['school_year'] ?? $row['year'] ?? 'N/A';
    ?>
        <tr class="hover:bg-[#f7f6f2] transition-colors">
            <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/60">#<?= htmlspecialchars($id); ?></td>
            <td class="p-4 font-semibold text-[#1c1c1c]"><?= htmlspecialchars($name); ?></td>
            <td class="p-4"><span class="px-2.5 py-1 font-mono-tech text-[9px] uppercase border-editorial bg-[#f7f6f2] text-[#3d7068]">Active</span></td>
            <td class="p-4 text-right">
                <button type="button" onclick="openEditModal('year', '<?= $id; ?>', '<?= htmlspecialchars($name, ENT_QUOTES); ?>')" class="px-3 py-1.5 border-editorial font-mono-tech text-[9px] uppercase hover:bg-[#3d7068] hover:text-white transition-colors cursor-pointer">Edit</button>
            </td>
        </tr>
    <?php endwhile; else: ?>
        <tr><td colspan="4" class="p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 uppercase">No school year records found.</td></tr>
    <?php endif; ?>
</tbody>
                    </table>
                </div>
            </section>

            <!-- VIEW 3: SEMESTER -->
            <section id="view-semester" class="view-panel hidden border-editorial bg-white p-8 space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">[ Semester Records ]</div>
                    <a href="add_sem.php" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase border-editorial">+ Add Semester</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs font-grotesk">
                        <thead class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] border-b border-[#e5e4de] bg-[#f7f6f2]">
                            <tr><th class="p-4">Sem ID</th><th class="p-4">Semester Designation</th><th class="p-4 text-right">Actions</th></tr>
                        </thead>
                        <tbody class="divide-y divide-[#e5e4de]">
                            <?php
                            $sem_res = $conn->query("SELECT * FROM semester ORDER BY 1 DESC") ?: $conn->query("SELECT * FROM semesters ORDER BY 1 DESC");
                            if ($sem_res && $sem_res->num_rows > 0):
                                while ($row = $sem_res->fetch_assoc()):
                            ?>
                                <tr class="hover:bg-[#f7f6f2] transition-colors">
                                    <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/60">#<?php echo htmlspecialchars($row['sem_id'] ?? $row['id'] ?? '1'); ?></td>
                                    <td class="p-4 font-semibold text-[#1c1c1c]"><?php echo htmlspecialchars($row['sem_name'] ?? $row['semester'] ?? 'N/A'); ?></td>
                                    <td class="p-4 text-right">
                                        <button type="button" onclick="openEditModal('semester', '<?= $row['sem_id'] ?? $row['id']; ?>', '<?= htmlspecialchars($row['sem_name'] ?? $row['semester'] ?? '', ENT_QUOTES); ?>')" class="px-3 py-1.5 border-editorial font-mono-tech text-[9px] uppercase hover:bg-[#3d7068] hover:text-white transition-colors cursor-pointer">Edit</button>
                                    </td>
                                </tr>
                            <?php endwhile; else: ?>
                                <tr><td colspan="3" class="p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 uppercase">No semester records found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- VIEW 4: BUILDING -->
            <section id="view-building" class="view-panel hidden border-editorial bg-white p-8 space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">[ Campus Building Directory ]</div>
                    <a href="add_building.php" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase border-editorial">+ Add Building</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs font-grotesk">
                        <thead class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] border-b border-[#e5e4de] bg-[#f7f6f2]">
                            <tr><th class="p-4">Building ID</th><th class="p-4">Building Name</th><th class="p-4">Code / Tag</th><th class="p-4 text-right">Actions</th></tr>
                        </thead>
                        <tbody class="divide-y divide-[#e5e4de]">
                            <?php
                            $bld_res = $conn->query("SELECT * FROM buildings ORDER BY 1 DESC") ?: $conn->query("SELECT * FROM building ORDER BY 1 DESC");
                            if ($bld_res && $bld_res->num_rows > 0):
                                while ($row = $bld_res->fetch_assoc()):
                            ?>
                                <tr class="hover:bg-[#f7f6f2] transition-colors">
                                    <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/60">#<?php echo htmlspecialchars($row['building_id'] ?? $row['id'] ?? '1'); ?></td>
                                    <td class="p-4 font-semibold text-[#1c1c1c]"><?php echo htmlspecialchars($row['building_name'] ?? $row['name'] ?? 'N/A'); ?></td>
                                    <td class="p-4 font-mono-tech text-[11px] text-[#3d7068]"><?php echo htmlspecialchars($row['building_code'] ?? $row['code'] ?? 'CAST'); ?></td>
                                    <td class="p-4 text-right">
                                        <button type="button" onclick="openEditModal('building', '<?= $row['building_id'] ?? $row['id']; ?>', '<?= htmlspecialchars($row['building_name'] ?? '', ENT_QUOTES); ?>', '<?= htmlspecialchars($row['building_code'] ?? '', ENT_QUOTES); ?>')" class="px-3 py-1.5 border-editorial font-mono-tech text-[9px] uppercase hover:bg-[#3d7068] hover:text-white transition-colors cursor-pointer">Edit</button>
                                    </td>
                                </tr>
                            <?php endwhile; else: ?>
                                <tr><td colspan="4" class="p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 uppercase">No building records found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- VIEW 5: ROOM -->
            <section id="view-room" class="view-panel hidden border-editorial bg-white p-8 space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">[ Classrooms & Laboratories ]</div>
                    <a href="add_room.php" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase border-editorial">+ Add Room</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs font-grotesk">
                        <thead class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] border-b border-[#e5e4de] bg-[#f7f6f2]">
                            <tr><th class="p-4">Room ID</th><th class="p-4">Room Identifier</th><th class="p-4">Building ID</th><th class="p-4 text-right">Actions</th></tr>
                        </thead>
                        <tbody class="divide-y divide-[#e5e4de]">
                            <?php
                            $room_res = $conn->query("SELECT * FROM rooms ORDER BY room_id DESC") ?: $conn->query("SELECT * FROM room ORDER BY id DESC");
                            if ($room_res && $room_res->num_rows > 0):
                                while ($row = $room_res->fetch_assoc()):
                                    $id       = $row['room_id'] ?? $row['id'] ?? '1';
                                    $name     = $row['room_name'] ?? $row['room_no'] ?? 'N/A';
                                    $building = $row['building_id'] ?? '1';
                            ?>
                                <tr class="hover:bg-[#f7f6f2] transition-colors">
                                    <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/60">#<?= htmlspecialchars($id); ?></td>
                                    <td class="p-4 font-semibold text-[#1c1c1c]"><?= htmlspecialchars($name); ?></td>
                                    <td class="p-4 font-mono-tech text-[11px] text-[#3d7068]">Building #<?= htmlspecialchars($building); ?></td>
                                    <td class="p-4 text-right">
                                        <button type="button" onclick="openEditModal('room', '<?= $id; ?>', '<?= htmlspecialchars($name, ENT_QUOTES); ?>', '<?= $building; ?>')" class="px-3 py-1.5 border-editorial font-mono-tech text-[9px] uppercase hover:bg-[#3d7068] hover:text-white transition-colors cursor-pointer">Edit</button>
                                    </td>
                                </tr>
                            <?php 
                                endwhile; 
                            else: 
                            ?>
                                <tr>
                                    <td colspan="4" class="p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 uppercase">
                                        No room records found in database. Click "+ ADD ROOM" to create one.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- VIEW 6: SUBJECT -->
            <section id="view-subject" class="view-panel hidden border-editorial bg-white p-8 space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">[ Curriculum Subjects ]</div>
                    <a href="add_sub.php" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase border-editorial">+ Add Subject</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs font-grotesk">
                        <thead class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] border-b border-[#e5e4de] bg-[#f7f6f2]">
                            <tr><th class="p-4">Subject ID</th><th class="p-4">Subject Code</th><th class="p-4">Title / Description</th><th class="p-4 text-right">Actions</th></tr>
                        </thead>
                        <tbody class="divide-y divide-[#e5e4de]">
    <?php
    $sub_res = $conn->query("SELECT * FROM subjects ORDER BY 1 DESC");
    if ($sub_res && $sub_res->num_rows > 0):
        while ($row = $sub_res->fetch_assoc()):
            $id    = $row['subject_id'] ?? $row['sub_id'] ?? $row['id'] ?? '1';
            $code  = $row['subject_code'] ?? $row['sub_code'] ?? $row['code'] ?? 'N/A';
            $title = $row['subject_title'] ?? $row['sub_title'] ?? $row['title'] ?? 'N/A';
    ?>
        <tr class="hover:bg-[#f7f6f2] transition-colors">
            <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/60">#<?= htmlspecialchars($id); ?></td>
            <td class="p-4 font-mono-tech text-[11px] font-bold text-[#3d7068]"><?= htmlspecialchars($code); ?></td>
            <td class="p-4 text-[#1c1c1c] font-semibold"><?= htmlspecialchars($title); ?></td>
            <td class="p-4 text-right">
                <button type="button" onclick="openEditModal('subject', '<?= $id; ?>', '<?= htmlspecialchars($code, ENT_QUOTES); ?>', '<?= htmlspecialchars($title, ENT_QUOTES); ?>')" class="px-3 py-1.5 border-editorial font-mono-tech text-[9px] uppercase hover:bg-[#3d7068] hover:text-white transition-colors cursor-pointer">Edit</button>
            </td>
        </tr>
    <?php endwhile; else: ?>
        <tr><td colspan="4" class="p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 uppercase">No subject records found.</td></tr>
    <?php endif; ?>
</tbody>
                    </table>
                </div>
            </section>

            <!-- VIEW 7: BLOCK -->
            <section id="view-block" class="view-panel hidden border-editorial bg-white p-8 space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">[ Section Blocks ]</div>
                    <a href="add_block.php" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase border-editorial">+ Add Block</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs font-grotesk">
                        <thead class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] border-b border-[#e5e4de] bg-[#f7f6f2]">
                            <tr><th class="p-4">Block ID</th><th class="p-4">Section Name</th><th class="p-4 text-right">Actions</th></tr>
                        </thead>
                        <tbody class="divide-y divide-[#e5e4de]">
    <?php
    $blk_res = $conn->query("SELECT * FROM blocks ORDER BY 1 DESC");
    if ($blk_res && $blk_res->num_rows > 0):
        while ($row = $blk_res->fetch_assoc()):
            $id   = $row['block_id'] ?? $row['id'] ?? '1';
            $name = $row['block_name'] ?? $row['section'] ?? $row['name'] ?? 'N/A';
    ?>
        <tr class="hover:bg-[#f7f6f2] transition-colors">
            <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/60">#<?= htmlspecialchars($id); ?></td>
            <td class="p-4 font-semibold text-[#1c1c1c]"><?= htmlspecialchars($name); ?></td>
            <td class="p-4 text-right">
                <button type="button" onclick="openEditModal('block', '<?= $id; ?>', '<?= htmlspecialchars($name, ENT_QUOTES); ?>')" class="px-3 py-1.5 border-editorial font-mono-tech text-[9px] uppercase hover:bg-[#3d7068] hover:text-white transition-colors cursor-pointer">Edit</button>
            </td>
        </tr>
    <?php endwhile; else: ?>
        <tr><td colspan="3" class="p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 uppercase">No section block records found.</td></tr>
    <?php endif; ?>
</tbody>s
                    </table>
                </div>
            </section>

            <!-- VIEW 8: INSTRUCTOR -->
            <section id="view-instructor" class="view-panel hidden border-editorial bg-white p-8 space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">[ Faculty Instructors ]</div>
                    <a href="add_prof.php" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase border-editorial">+ Add Instructor</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs font-grotesk">
                        <thead class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] border-b border-[#e5e4de] bg-[#f7f6f2]">
                            <tr><th class="p-4">User ID</th><th class="p-4">Faculty Name</th><th class="p-4">Email Contact</th><th class="p-4 text-right">Actions</th></tr>
                        </thead>
                       <tbody class="divide-y divide-[#e5e4de]">
    <?php
    // Querying your exact teachers table
    $inst_res = $conn->query("SELECT * FROM teachers ORDER BY 1 DESC") ?: $conn->query("SELECT user_id, username, email FROM users WHERE role_id = 2 ORDER BY user_id DESC");
    if ($inst_res && $inst_res->num_rows > 0):
        while ($row = $inst_res->fetch_assoc()):
            $id    = $row['teacher_id'] ?? $row['user_id'] ?? $row['id'] ?? '1';
            $name  = $row['teacher_name'] ?? $row['username'] ?? $row['name'] ?? 'N/A';
            $email = $row['email'] ?? $row['email_address'] ?? 'N/A';
    ?>
        <tr class="hover:bg-[#f7f6f2] transition-colors">
            <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/60">#<?= htmlspecialchars($id); ?></td>
            <td class="p-4 font-semibold text-[#1c1c1c]"><?= htmlspecialchars($name); ?></td>
            <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/70"><?= htmlspecialchars($email); ?></td>
            <td class="p-4 text-right">
                <button type="button" onclick="openEditModal('instructor', '<?= $id; ?>', '<?= htmlspecialchars($name, ENT_QUOTES); ?>', '<?= htmlspecialchars($email, ENT_QUOTES); ?>')" class="px-3 py-1.5 border-editorial font-mono-tech text-[9px] uppercase hover:bg-[#3d7068] hover:text-white transition-colors cursor-pointer">Edit</button>
            </td>
        </tr>
    <?php endwhile; else: ?>
        <tr><td colspan="4" class="p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 uppercase">No teacher records found in database.</td></tr>
    <?php endif; ?>
</tbody>
                    </table>
                </div>
            </section>

            <!-- VIEW 9: DEPARTMENT -->
            <section id="view-department" class="view-panel hidden border-editorial bg-white p-8 space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">[ Academic Departments ]</div>
                    <a href="add_department.php" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase border-editorial">+ Add Department</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs font-grotesk">
                        <thead class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] border-b border-[#e5e4de] bg-[#f7f6f2]">
                            <tr><th class="p-4">Dept ID</th><th class="p-4">Department Title</th><th class="p-4 text-right">Actions</th></tr>
                        </thead>
                        <tbody class="divide-y divide-[#e5e4de]">
                            <?php
                            $dept_res = $conn->query("SELECT * FROM departments ORDER BY department_id DESC") ?: $conn->query("SELECT * FROM department ORDER BY id DESC");
                            if ($dept_res &&$dept_res->num_rows > 0):
                                while ($row =$dept_res->fetch_assoc()):
                                    $id   =$row['department_id'] ?? $row['dept_id'] ?? $row['id'] ?? '1';
                                    $name =$row['department_name'] ?? $row['dept_name'] ?? $row['name'] ?? 'N/A';
                            ?>
                                <tr class="hover:bg-[#f7f6f2] transition-colors">
                                    <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/60">#<?= htmlspecialchars($id); ?></td>
                                    <td class="p-4 font-semibold text-[#1c1c1c]"><?= htmlspecialchars($name); ?></td>
                                    <td class="p-4 text-right">
                                        <button type="button" onclick="openEditModal('department', '<?= $id; ?>', '<?= htmlspecialchars($name, ENT_QUOTES); ?>')" class="px-3 py-1.5 border-editorial font-mono-tech text-[9px] uppercase hover:bg-[#3d7068] hover:text-white transition-colors cursor-pointer">Edit</button>
                                    </td>
                                </tr>
                            <?php 
                                endwhile; 
                            else: 
                            ?>
                                <tr>
                                    <td colspan="3" class="p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 uppercase">
                                        No department records found in database. Click "+ ADD DEPARTMENT" to create one.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </div>
<!-- DEDICATED ADD USER MODAL -->
<div id="addUserModal" class="fixed inset-0 z-50 hidden bg-black/50 flex items-center justify-center p-4">
    <div class="bg-white border-editorial p-6 max-w-md w-full space-y-4 shadow-2xl relative">
        <div class="flex justify-between items-center border-b border-[#e5e4de] pb-3">
            <h3 class="font-playfair text-xl uppercase font-bold text-[#1c1c1c]">Add New Account</h3>
            <button type="button" onclick="closeAddUserModal()" class="text-gray-500 hover:text-black font-mono-tech text-lg cursor-pointer">&times;</button>
        </div>

        <form method="POST" action="add_user_process.php" class="space-y-4 font-grotesk">
            <div>
                <label class="block font-mono-tech text-[10px] uppercase mb-1">Username / Identifier</label>
                <input type="text" name="username" placeholder="e.g. jdoe" class="w-full p-2 border-editorial text-xs" required>
            </div>
            <div>
                <label class="block font-mono-tech text-[10px] uppercase mb-1">Email Contact</label>
                <input type="email" name="email" placeholder="user@psu.edu.ph" class="w-full p-2 border-editorial text-xs" required>
            </div>
            <div>
                <label class="block font-mono-tech text-[10px] uppercase mb-1">Initial Password</label>
                <input type="password" name="password" placeholder="••••••••" class="w-full p-2 border-editorial text-xs" required>
            </div>
            <div>
                <label class="block font-mono-tech text-[10px] uppercase mb-1">Role Designation</label>
                <select name="role_id" class="w-full p-2 border-editorial text-xs bg-white" required>
                    <option value="3">STUDENT</option>
                    <option value="2">FACULTY</option>
                    <option value="1">ADMIN</option>
                </select>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t border-[#e5e4de]">
                <button type="button" onclick="closeAddUserModal()" class="px-4 py-2 border-editorial font-mono-tech text-[10px] uppercase hover:bg-gray-100 cursor-pointer">Cancel</button>
                <button type="submit" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase cursor-pointer">Create Account</button>
            </div>
        </form>
    </div>
</div>
    <!-- UNIVERSAL EDIT MODAL -->
    <div id="editModal" class="fixed inset-0 z-50 hidden bg-black/50 flex items-center justify-center p-4">
        <div class="bg-white border-editorial p-6 max-w-md w-full space-y-4 shadow-2xl relative">
            <div class="flex justify-between items-center border-b border-[#e5e4de] pb-3">
                <h3 id="modalTitle" class="font-playfair text-xl uppercase font-bold text-[#1c1c1c]">Edit Record</h3>
                <button type="button" onclick="closeEditModal()" class="text-gray-500 hover:text-black font-mono-tech text-lg">&times;</button>
            </div>

            <form id="editForm" method="POST" action="update_user.php" class="space-y-4 font-grotesk">
                <input type="hidden" id="edit_id" name="id">
                <input type="hidden" id="edit_type" name="type">

                <div id="modalFields" class="space-y-3">
                    <!-- Dynamic fields loaded by JS -->
                </div>

                <div class="flex justify-end gap-2 pt-3 border-t border-[#e5e4de]">
                    <button type="button" onclick="closeEditModal()" class="px-4 py-2 border-editorial font-mono-tech text-[10px] uppercase hover:bg-gray-100">Cancel</button>
                    <button type="submit" class="px-4 py-2 btn-editorial font-mono-tech text-[10px] uppercase">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
<!-- EDITORIAL TECH LOADING OVERLAY -->
<div id="editorialLoader" class="fixed inset-0 z-[100] bg-[#f7f6f2] flex flex-col items-center justify-center p-6 space-y-6 transition-opacity duration-500 pointer-events-none">
    <div class="flex items-center gap-3">
        <span class="w-6 h-[1px] bg-[#1c1c1c]"></span>
        <img src="../assets/images/NaviTrack_Logo.png" 
             alt="NaviTrack Logo" 
             style="height: 40px; width: 40px; object-fit: contain;">
        <span class="font-playfair text-2xl uppercase tracking-widest text-[#1c1c1c]">Navi Track</span>
        <span class="w-6 h-[1px] bg-[#1c1c1c]"></span>
    </div>

    <div class="border-editorial p-6 bg-white max-w-sm w-full text-center space-y-4">
        <div class="flex items-center justify-between font-mono-tech text-[10px] text-[#3d7068]">
            <span>[ INITIALIZING SYSTEM MANAGEMENT ]</span>
            <span id="loadProgressText">0%</span>
        </div>

        <div class="h-[2px] w-full bg-[#e5e4de] overflow-hidden relative">
            <div class="h-full w-full bg-[#3d7068] animate-scan"></div>
        </div>

        <p class="font-grotesk text-[11px] text-[#1c1c1c]/60">
            Synchronizing system records and department structures...
        </p>
    </div>
</div>

<!-- FAILSAFE LOADING SCREEN ANIMATION HANDLER -->
<script>
    function triggerEditorialLoader() {
        let progress = 0;
        const progressText = document.getElementById('loadProgressText');
        const loader = document.getElementById('editorialLoader');

        if (!loader) return;

        const interval = setInterval(function() {
            progress += Math.floor(Math.random() * 25) + 15;
            if (progress >= 100) {
                progress = 100;
                if (progressText) progressText.textContent = '100%';
                clearInterval(interval);
                
                setTimeout(function() {
                    loader.style.opacity = '0';
                    setTimeout(function() {
                        loader.style.display = 'none';
                    }, 500);
                }, 150);
            } else {
                if (progressText) progressText.textContent = progress + '%';
            }
        }, 40);
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        triggerEditorialLoader();
    } else {
        document.addEventListener('DOMContentLoaded', triggerEditorialLoader);
    }
</script>
</body>
</html>