<?php
session_start();
require_once '../Sys_Database/db_connection.php';

// JSON Fetch Handler for AJAX / JavaScript calls
if (isset($_GET['action']) && $_GET['action'] === 'fetch') {
    header('Content-Type: application/json');
    
    $subjects = [];
    $query = "SELECT * FROM subjects ORDER BY subject_id ASC";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $subjects[] = [
                'subject_id'    => $row['subject_id'] ?? $row['id'] ?? '',
                'subject_code'  => $row['subject_code'] ?? $row['sub_code'] ?? $row['code'] ?? '',
                'subject_title' => $row['subject_title'] ?? $row['sub_title'] ?? $row['title'] ?? '',
                'units'         => $row['units'] ?? $row['unit'] ?? '0'
            ];
        }
    }
    
    echo json_encode($subjects);
    exit();
}

// Form Submission Handler (Add New Subject)
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_subject'])) {
    $subject_code  = trim($_POST['subject_code']);
    $subject_title = trim($_POST['subject_title']);
    $units         = intval($_POST['units'] ?? 0);

    if (!empty($subject_code) && !empty($subject_title)) {
        $stmt = $conn->prepare("INSERT INTO subjects (subject_code, subject_title, units) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $subject_code, $subject_title, $units);
        
        if ($stmt->execute()) {
            $message = "<div class='alert alert-success'>Subject added successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error adding subject: " . $conn->error . "</div>";
        }
        $stmt->close();
    } else {
        $message = "<div class='alert alert-warning'>Please fill in all required fields.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Curriculum Subjects - Super Admin</title>
    <link rel="stylesheet" href="../assets/css/editorial-theme.css">
</head>
<body>
    <div class="container my-4">
        <h2>Curriculum Subjects Management</h2>
        <?= $message ?>

        <!-- Form for Adding New Subject -->
        <form method="POST" action="add_sub.php" class="mb-4">
            <div class="row">
                <div class="col-md-4 mb-2">
                    <input type="text" name="subject_code" class="form-control" placeholder="Subject Code (e.g. IT 311)" required>
                </div>
                <div class="col-md-5 mb-2">
                    <input type="text" name="subject_title" class="form-control" placeholder="Subject Title / Description" required>
                </div>
                <div class="col-md-2 mb-2">
                    <input type="number" name="units" class="form-control" placeholder="Units" min="1" max="10" required>
                </div>
                <div class="col-md-1 mb-2">
                    <button type="submit" name="add_subject" class="btn btn-primary w-100">Add</button>
                </div>
            </div>
        </form>

        <!-- Dynamic Subjects Table Container -->
        <div id="subjectTable">
            <table class="table table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Subject ID</th>
                        <th>Subject Code</th>
                        <th>Title / Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="subject-list">
                    <!-- JavaScript populates rows here -->
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>