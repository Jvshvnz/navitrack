<?php
// SUPAD/get_subjects.php
session_start();
require_once '../Sys_Database/db_connection.php';

header('Content-Type: application/json');

$subjects = [];

// Query your database table
$query = "SELECT * FROM subjects ORDER BY subject_id ASC";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $subjects[] = [
            'subject_id'    => $row['subject_id'] ?? $row['id'] ?? '',
            'subject_code'  => $row['subject_code'] ?? $row['sub_code'] ?? $row['code'] ?? '',
            'subject_title' => $row['subject_title'] ?? $row['sub_title'] ?? $row['title'] ?? ''
        ];
    }
}

echo json_encode($subjects);
exit();