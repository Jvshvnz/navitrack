<?php
// SUPAD/update_user.php
session_start();
require_once __DIR__ . '/../Sys_Database/db_connection.php';

// Ensure request is POST and user is logged in
if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: superAdmin.php");
    exit();
}

$type = $_POST['type'] ?? '';
$id   = intval($_POST['id'] ?? 0);

if ($id <= 0 || empty($type)) {
    header("Location: superAdmin.php");
    exit();
}

// Execute the appropriate UPDATE query based on record type
switch ($type) {
    case 'user':
    case 'instructor':
        $username = trim($_POST['username']);
        $email    = trim($_POST['email']);
        $stmt = $conn->prepare("UPDATE users SET username = ?, email = ? WHERE user_id = ?");
        $stmt->bind_param("ssi", $username, $email, $id);
        $stmt->execute();
        $stmt->close();
        break;

    case 'year':
        $sy_name = trim($_POST['sy_name']);
        $stmt = $conn->prepare("UPDATE school_year SET sy_name = ? WHERE sy_id = ?");
        if (!$stmt) { $stmt = $conn->prepare("UPDATE school_years SET sy_name = ? WHERE id = ?"); }
        $stmt->bind_param("si", $sy_name, $id);
        $stmt->execute();
        $stmt->close();
        break;

    case 'semester':
        $sem_name = trim($_POST['sem_name']);
        $stmt = $conn->prepare("UPDATE semester SET sem_name = ? WHERE sem_id = ?");
        if (!$stmt) { $stmt = $conn->prepare("UPDATE semesters SET sem_name = ? WHERE id = ?"); }
        $stmt->bind_param("si", $sem_name, $id);
        $stmt->execute();
        $stmt->close();
        break;

    case 'building':
        $building_name = trim($_POST['building_name']);
        $building_code = trim($_POST['building_code']);
        $stmt = $conn->prepare("UPDATE buildings SET building_name = ?, building_code = ? WHERE building_id = ?");
        if (!$stmt) { $stmt = $conn->prepare("UPDATE building SET building_name = ?, building_code = ? WHERE id = ?"); }
        $stmt->bind_param("ssi", $building_name, $building_code, $id);
        $stmt->execute();
        $stmt->close();
        break;

    case 'room':
        $room_name   = trim($_POST['room_name']);
        $building_id = intval($_POST['building_id']);
        $stmt = $conn->prepare("UPDATE rooms SET room_name = ?, building_id = ? WHERE room_id = ?");
        if (!$stmt) { $stmt = $conn->prepare("UPDATE room SET room_name = ?, building_id = ? WHERE id = ?"); }
        $stmt->bind_param("sii", $room_name, $building_id, $id);
        $stmt->execute();
        $stmt->close();
        break;

    case 'subject':
        $subject_code  = trim($_POST['subject_code']);
        $subject_title = trim($_POST['subject_title']);
        $stmt = $conn->prepare("UPDATE subjects SET subject_code = ?, subject_title = ? WHERE subject_id = ?");
        if (!$stmt) { $stmt = $conn->prepare("UPDATE subject SET subject_code = ?, subject_title = ? WHERE id = ?"); }
        $stmt->bind_param("ssi", $subject_code, $subject_title, $id);
        $stmt->execute();
        $stmt->close();
        break;

    case 'block':
        $block_name = trim($_POST['block_name']);
        $stmt = $conn->prepare("UPDATE blocks SET block_name = ? WHERE block_id = ?");
        if (!$stmt) { $stmt = $conn->prepare("UPDATE block SET block_name = ? WHERE id = ?"); }
        $stmt->bind_param("si", $block_name, $id);
        $stmt->execute();
        $stmt->close();
        break;

    case 'department':
        $dept_name = trim($_POST['dept_name']);
        $stmt = $conn->prepare("UPDATE departments SET department_name = ? WHERE department_id = ?");
        if (!$stmt) { $stmt = $conn->prepare("UPDATE department SET department_name = ? WHERE id = ?"); }
        $stmt->bind_param("si", $dept_name, $id);
        $stmt->execute();
        $stmt->close();
        break;
}

// Redirect back to dashboard after saving
header("Location: superAdmin.php");
exit();