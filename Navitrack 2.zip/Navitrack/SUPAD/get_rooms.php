<?php
session_start();
require_once '../Sys_Database/db_connection.php';
header('Content-Type: application/json');

$rooms = [];
$result = mysqli_query($conn, "SELECT * FROM rooms");
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $rooms[] = $row;
    }
}
echo json_encode($rooms);