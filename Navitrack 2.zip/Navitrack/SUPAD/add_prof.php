<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../Sys_Database/db_connection.php';

if (!isset($_SESSION['user_id'])) { header("Location: ../LOGIN/login.php"); exit(); }

$msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $department_name = trim($_POST['department_name'] ?? $_POST['name'] ?? '');

    if (!empty($department_name)) {
        try {
            $stmt = $conn->prepare("INSERT INTO department (department_name) VALUES (?)");
            $stmt->bind_param("s", $department_name);
            if ($stmt->execute()) {
                header("Location: superAdmin.php");
                exit();
            } else {
                $msg = "Execution failed.";
            }
            $stmt->close();
        } catch (Exception $e) {
            $msg = "Database Error: " . $e->getMessage();
        }
    } else {
        $msg = "Department name is required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Navi Track • Add Department</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600&family=Space+Grotesk:wght@400;500&family=Space+Mono&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background-color: #f7f6f2; color: #1c1c1c; font-family: 'Space Grotesk', sans-serif; }
        .font-playfair { font-family: 'Playfair Display', serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .border-editorial { border: 1px solid #e5e4de; border-radius: 2px !important; }
        .btn-editorial { background-color: #3d7068; color: #ffffff; letter-spacing: 0.15em; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-6">
    <div class="max-w-md w-full border-editorial bg-white p-8 space-y-6">
        <div class="flex justify-between items-center border-b border-[#e5e4de] pb-4">
            <h1 class="font-playfair text-2xl uppercase font-light">Add Department</h1>
            <a href="superAdmin.php" class="font-mono-tech text-xs text-[#3d7068] hover:underline">[ Return ]</a>
        </div>
        <?php if ($msg): ?><p class="text-xs text-red-600 font-mono-tech border p-2 border-red-200 bg-red-50"><?php echo htmlspecialchars($msg); ?></p><?php endif; ?>
        <form action="add_department.php" method="POST" class="space-y-4 font-mono-tech text-xs">
            <div>
                <label class="block uppercase mb-1">Department Title</label>
                <input type="text" name="department_name" required placeholder="Department of Computing" class="w-full p-3 border-editorial bg-[#f7f6f2] focus:outline-none">
            </div>
            <button type="submit" class="w-full py-3.5 btn-editorial uppercase text-[10px]">Save Department</button>
        </form>
    </div>
</body>
</html>