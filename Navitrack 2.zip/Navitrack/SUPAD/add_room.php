<?php
session_start();
require_once '../Sys_Database/db_connection.php';

// JSON Fetch Handler for AJAX / JavaScript calls
if (isset($_GET['action']) && $_GET['action'] === 'fetch') {
    header('Content-Type: application/json');
    
    $rooms = [];
    $query = "SELECT * FROM rooms ORDER BY room_id ASC";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $rooms[] = [
                'room_id'       => $row['room_id'] ?? $row['id'] ?? '',
                'room_name'     => $row['room_name'] ?? $row['room_no'] ?? $row['name'] ?? '',
                'building_name' => $row['building_name'] ?? $row['building'] ?? 'Unassigned',
                'capacity'      => $row['capacity'] ?? 0
            ];
        }
    }
    
    echo json_encode($rooms);
    exit();
}

// Form Submission Handler (Add New Room)
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_room'])) {
    $room_name     = trim($_POST['room_name']);
    $building_name = trim($_POST['building_name'] ?? 'Main');
    $capacity      = intval($_POST['capacity'] ?? 30);

    if (!empty($room_name)) {
        $stmt = $conn->prepare("INSERT INTO rooms (room_name, building_name, capacity) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $room_name, $building_name, $capacity);
        
        if ($stmt->execute()) {
            $message = "<div class='alert alert-success'>Room added successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error adding room: " . $conn->error . "</div>";
        }
        $stmt->close();
    } else {
        $message = "<div class='alert alert-warning'>Please enter a valid room name.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Room Management - Super Admin</title>
    <link rel="stylesheet" href="../assets/css/editorial-theme.css">
</head>
<body>
    <div class="container my-4">
        <h2>Room Management</h2>
        <?= $message ?>

        <!-- Form for Adding New Room -->
        <form method="POST" action="add_room.php" class="mb-4">
            <div class="row">
                <div class="col-md-5 mb-2">
                    <input type="text" name="room_name" class="form-control" placeholder="Room Name / Number (e.g. Lab 101)" required>
                </div>
                <div class="col-md-4 mb-2">
                    <input type="text" name="building_name" class="form-control" placeholder="Building Name">
                </div>
                <div class="col-md-2 mb-2">
                    <input type="number" name="capacity" class="form-control" placeholder="Capacity" min="1" required>
                </div>
                <div class="col-md-1 mb-2">
                    <button type="submit" name="add_room" class="btn btn-primary w-100">Add</button>
                </div>
            </div>
        </form>

        <!-- Dynamic Room Table Container -->
        <div id="roomTable">
            <table class="table table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Room ID</th>
                        <th>Room Name</th>
                        <th>Building</th>
                        <th>Capacity</th>
                    </tr>
                </thead>
                <tbody id="room-list">
                    <!-- JavaScript populates rows here -->
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>