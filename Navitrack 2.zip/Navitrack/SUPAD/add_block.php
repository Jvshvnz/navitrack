<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../Sys_Database/db_connection.php';

if (!isset($_SESSION['user_id'])) { header("Location: ../LOGIN/login.php"); exit(); }

$msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $block_name = trim($_POST['block_name'] ?? $_POST['section'] ?? '');
    
    if (!empty($block_name)) {
        try {
            $stmt = $conn->prepare("INSERT INTO blocks (block_name) VALUES (?)");
            $stmt->bind_param("s", $block_name);
            if ($stmt->execute()) {
                header("Location: superAdmin.php");
                exit();
            } else {
                $msg = "Insert execution failed.";
            }
            $stmt->close();
        } catch (Exception $e) {
            $msg = "Database Error: " . $e->getMessage();
        }
    } else {
        $msg = "Block/Section name cannot be empty.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Navi Track • Add Section Block</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600&family=Space+Grotesk:wght@400;500&family=Space+Mono&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background-color: #f7f6f2; color: #1c1c1c; font-family: 'Space Grotesk', sans-serif; }
        .font-playfair { font-family: 'Playfair Display', serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .border-editorial { border: 1px solid #e5e4de; border-radius: 2px !important; }
        .btn-editorial { background-color: #3d7068; color: #ffffff; letter-spacing: 0.15em; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-6">
    <div class="max-w-md w-full border-editorial bg-white p-8 space-y-6">
        <div class="flex justify-between items-center border-b border-[#e5e4de] pb-4">
            <h1 class="font-playfair text-2xl uppercase font-light">Add Section Block</h1>
            <a href="superAdmin.php" class="font-mono-tech text-xs text-[#3d7068] hover:underline">[ Return ]</a>
        </div>
        <?php if ($msg): ?><p class="text-xs text-red-600 font-mono-tech border p-2 border-red-200 bg-red-50"><?php echo htmlspecialchars($msg); ?></p><?php endif; ?>
        <form action="add_block.php" method="POST" class="space-y-4 font-mono-tech text-xs">
            <div>
                <label class="block uppercase mb-1">Block / Section Name</label>
                <input type="text" name="block_name" required placeholder="e.g. BSIT-3A" class="w-full p-3 border-editorial bg-[#f7f6f2] focus:outline-none">
            </div>
            <button type="submit" class="w-full py-3.5 btn-editorial uppercase text-[10px]">Create Block</button>
        </form>
    </div>
</body>
</html>