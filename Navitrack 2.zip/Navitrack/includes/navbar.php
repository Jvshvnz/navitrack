<?php
$header_username = $_SESSION['username'] ?? $username ?? 'Teacher';
?>
<header class="fixed top-0 left-0 right-0 z-40 bg-[#f7f6f2]/90 backdrop-blur-md border-b border-[#e5e4de] w-full">
    <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between gap-4">
        
        <!-- Left Section: Logo & Brand -->
        <div class="flex items-center gap-3 shrink-0">
            <a href="teacher.php" class="flex items-center gap-3">
                <img src="../assets/images/NaviTrack_Logo.png" alt="NaviTrack Logo" class="w-8 h-8 object-contain">
                <span class="font-playfair text-xl tracking-tight uppercase font-light text-[#1c1c1c] whitespace-nowrap">Navi Track</span>
            </a>
            <span class="h-4 w-px bg-[#e5e4de] hidden sm:block"></span>
            <span class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#3d7068] hidden sm:block whitespace-nowrap">
                PSU Bayambang
            </span>
        </div>

        <!-- Center Section: Navigation Links -->
        <nav class="hidden lg:flex items-center gap-6 font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c]/80 shrink-0">
            <a href="#home" class="hover:text-[#3d7068] transition-colors">Overview</a>
            <a href="#room-locator" class="hover:text-[#3d7068] transition-colors">Verification</a>
            <a href="#block-schedule" class="hover:text-[#3d7068] transition-colors">Schedule</a>
            <a href="#about" class="hover:text-[#3d7068] transition-colors">About</a>
        </nav>

        <!-- Right Section: Profile Badge & Logout -->
        <div class="flex items-center gap-3 shrink-0">
            <button id="profileHeaderBtn" type="button" class="border-editorial bg-white px-3 py-1.5 flex items-center gap-2.5 shadow-sm hover:border-[#3d7068] transition-colors cursor-pointer">
                <div class="w-7 h-7 bg-[#3d7068] text-white flex items-center justify-center font-mono-tech text-xs font-bold rounded-sm shrink-0">
                    <?php echo strtoupper(substr($header_username, 0, 2)); ?>
                </div>
                <div class="text-left">
                    <div class="font-mono-tech text-xs font-bold text-[#1c1c1c] leading-tight whitespace-nowrap">
                        <?php echo htmlspecialchars($header_username); ?>
                    </div>
                    <div class="font-mono-tech text-[9px] text-[#3d7068] uppercase tracking-wider leading-none mt-0.5 whitespace-nowrap">
                        Faculty Session
                    </div>
                </div>
            </button>

            <a href="../LOGIN/login.php" class="p-2.5 border-editorial bg-white hover:bg-red-50 text-red-700 transition-colors flex items-center justify-center shrink-0" title="Logout">
                <i class="fa-solid fa-arrow-right-from-bracket text-xs"></i>
            </a>
        </div>

    </div>
</header>