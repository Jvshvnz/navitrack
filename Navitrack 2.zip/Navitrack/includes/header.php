<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Campus Nav — PSU's official web room locator, scheduling system, and laboratory attendance platform.">
    <title>Navi Track • System Portal</title>

    <script src="https://cdn.tailwindcss.com"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
        <link rel="stylesheet" href="../assets/css/editorial-theme.css">
    
    <link rel="stylesheet" href="profile.css">
    <link rel="stylesheet" href="scanner.css">
</head>
<body class="relative min-h-screen bg-[#f7f6f2] text-[#1c1c1c] overflow-x-hidden antialiased">

    <div class="fixed inset-0 pointer-events-none z-0 flex justify-between max-w-7xl mx-auto px-6">
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
    </div>

    <div class="fixed inset-0 pointer-events-none z-0 editorial-grid-bg opacity-70"></div>