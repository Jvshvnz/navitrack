<footer class="border-t border-slate-200 bg-white py-6 text-center text-xs text-slate-500">
    <p>&copy; <?php echo date('Y'); ?> NaviTrack — PSU Bayambang. All rights reserved.</p>
</footer>