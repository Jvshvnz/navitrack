<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../Sys_Database/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../LOGIN/login.php");
    exit();
}

$username = $_SESSION['username'] ?? 'Student';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navi Track</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Space+Grotesk:wght@300..700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="css.css">
    
    <!-- Three.js & OrbitControls for 3D Interactive Map -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
    
    <style>
        :root {
            --bg-organic: #f7f6f2;
            --fg-dark: #1c1c1c;
            --accent-green: #3d7068;
            --border-line: #e5e4de;
            --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
        }

        body {
            background-color: var(--bg-organic);
            color: var(--fg-dark);
            font-family: 'Space Grotesk', sans-serif;
            transition: all 700ms var(--ease-editorial);
        }

        .font-playfair { font-family: 'Playfair Display', Georgia, serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .font-grotesk { font-family: 'Space Grotesk', sans-serif; }

        .editorial-grid-bg {
            background-size: 40px 40px;
            background-image: 
                linear-gradient(to right, rgba(229, 228, 222, 0.6) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(229, 228, 222, 0.6) 1px, transparent 1px);
            mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
            -webkit-mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
        }

        @keyframes scanSlide {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        .animate-scan {
            animation: scanSlide 2s infinite cubic-bezier(0.8, 0, 0.2, 1);
        }

        .btn-editorial {
            background-color: var(--accent-green);
            color: #ffffff;
            transition: letter-spacing 400ms var(--ease-editorial), transform 200ms var(--ease-editorial);
            letter-spacing: 0.25em;
        }
        .btn-editorial:hover {
            letter-spacing: 0.4em;
        }

        .border-editorial {
            border: 1px solid var(--border-line);
            border-radius: 2px !important;
        }

        #threejs-container {
            width: 100%;
            height: 520px;
            background-color: #0f172a;
            position: relative;
            overflow: hidden;
        }
    </style>

<!-- STUDENT LOADING SCREEN OVERLAY -->
<div id="loading-screen" class="fixed inset-0 w-screen h-screen z-[9999] bg-[#f7f6f2] flex items-center justify-center">
    <div class="editorial-grid-bg absolute inset-0 opacity-80"></div>
    <div class="relative z-10 text-center space-y-4 max-w-sm px-6">
        <div class="inline-flex items-center gap-2 px-3 py-1 border-editorial bg-white">
            <span class="w-2 h-2 rounded-full bg-[#3d7068] animate-pulse"></span>
            <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">Initializing Student Portal</span>
        </div>

        <!-- LOGO + NAVI TRACK TITLE -->
        <div class="flex items-center justify-center gap-3">
            <img src="../assets/images/NaviTrack_Logo.png" 
                 alt="NaviTrack Logo" 
                 class="w-8 h-8 flex-shrink-0 object-contain">
            <h1 class="font-playfair text-3xl font-light uppercase tracking-wider text-[#1c1c1c] whitespace-nowrap">
                Navi Track
            </h1>
        </div>

        <p class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c]/60">Pangasinan State University</p>
        
        <!-- PROGRESS BAR -->
        <div class="w-full h-1 bg-[#e5e4de] border-editorial overflow-hidden">
            <div id="ls-fill" class="h-full bg-[#3d7068] w-0 transition-all duration-300"></div>
        </div>
        <div class="flex justify-between font-mono-tech text-[10px] text-[#1c1c1c]/60">
            <span id="ls-status">Verifying Credentials...</span>
            <span id="ls-pct">0%</span>
        </div>
    </div>
</div>

<!-- LOADING SCREEN ANIMATION SCRIPT -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const ls = document.getElementById('loading-screen');
    const fill = document.getElementById('ls-fill');
    const status = document.getElementById('ls-status');
    const pct = document.getElementById('ls-pct');
    if (!ls || !fill || !status || !pct) return;

    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.floor(Math.random() * 15) + 10;
        if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
            fill.style.width = '100%';
            pct.textContent = '100%';
            status.textContent = 'Portal Ready';
            setTimeout(() => {
                ls.style.opacity = '0';
                ls.style.transition = 'opacity 0.5s ease';
                setTimeout(() => ls.remove(), 500);
            }, 300);
        } else {
            fill.style.width = progress + '%';
            pct.textContent = progress + '%';
        }
    }, 150);
});
</script>
</head>
<body class="relative min-h-screen overflow-x-hidden antialiased">

    <div class="fixed inset-0 pointer-events-none z-0 flex justify-between max-w-7xl mx-auto px-6">
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
    </div>

    <div class="fixed inset-0 pointer-events-none z-0 editorial-grid-bg"></div>

    <header class="fixed top-0 left-0 right-0 z-50 transition-all duration-500 bg-[#f7f6f2]/80 backdrop-blur-md border-b border-[#e5e4de]">
        <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            
            <div class="flex items-center gap-3">
                <span class="w-6 h-[1px] bg-[#1c1c1c]"></span>
                <img src="../assets/images/NaviTrack_Logo.png" 
                     alt="NaviTrack Logo" 
                     class="w-8 h-8 flex-shrink-0 object-contain">
                <span class="font-playfair text-xl tracking-tight uppercase font-light text-[#1c1c1c] whitespace-nowrap">Navi Track</span>
                <span class="w-8 h-[1px] bg-[#1c1c1c]"></span>
            </div>

            <nav class="flex items-center gap-6 font-mono-tech text-[10px] uppercase tracking-[0.3em]">
                <a href="html_block_sched.php" class="text-[#1c1c1c] hover:text-[#3d7068] transition-colors flex items-center gap-2">
                    <span>Block Schedule</span>
                </a>
                <button onclick="open3DMapModal()" class="text-[#1c1c1c] hover:text-[#3d7068] transition-colors flex items-center gap-2 uppercase">
                    <span>Cast Map</span>
                </button>
                <a href="../LOGIN/login.php" class="text-red-700 hover:opacity-70 transition-opacity" title="Sign Out">
                    [ Exit ]
                </a>
            </nav>
        </div>
    </header>

    <main class="relative z-10 max-w-7xl mx-auto px-6 pt-32 pb-24 space-y-24">

        <section class="text-center py-12 border-b border-[#e5e4de] space-y-6">

            <div class="inline-flex items-center gap-3 px-4 py-1.5 border-editorial bg-[#f7f6f2]">
                <span class="w-2 h-2 rounded-full bg-[#3d7068] animate-pulse"></span>
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">
                    System Portal • User: <?php echo htmlspecialchars($username); ?>
                </span>
            </div>

            <h1 class="font-playfair text-[8.5vw] leading-[0.95] font-light uppercase tracking-tighter text-[#1c1c1c]">
                Campus <span class="italic text-[#B4B4B4] font-normal">Navigation</span> Platform
            </h1>

            <p class="font-grotesk max-w-xl mx-auto text-sm text-[#1c1c1c]/70 leading-relaxed">
                Precision spatial orientation, real-time schedule allocation, and laboratory status tracking designed for college operations.
            </p>

            <div class="pt-4">
                <!-- Enter Interactive Map Trigger -->
                <button onclick="open3DMapModal()" class="inline-block px-8 py-4 btn-editorial font-mono-tech text-[10px] uppercase border-editorial shadow-sm cursor-pointer">
                    Enter Interactive Map
                </button>
            </div>
        </section>

        <!-- Statistics Grid Section -->
        <section class="grid grid-cols-1 md:grid-cols-3 border-editorial bg-[#f7f6f2]">
            <div class="p-10 border-b md:border-b-0 md:border-r border-[#e5e4de] hover:bg-white transition-colors duration-500 space-y-4">
                <div class="w-12 h-12 border-editorial flex items-center justify-center text-[#3d7068]">
                    <i class="fa-solid fa-layer-group"></i>
                </div>
                <div class="font-playfair text-4xl text-[#1c1c1c]">04</div>
                <div class="font-mono-custom font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#3d7068]">Active Floor Levels</div>
            </div>

            <div class="p-10 border-b md:border-b-0 md:border-r border-[#e5e4de] hover:bg-white transition-colors duration-500 space-y-4">
                <div class="w-12 h-12 border-editorial flex items-center justify-center text-[#3d7068]">
                    <i class="fa-solid fa-microchip"></i>
                </div>
                <div class="font-playfair text-4xl text-[#1c1c1c]">12</div>
                <div class="font-mono-custom font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#3d7068]">Computer Laboratories</div>
            </div>

            <div class="p-10 hover:bg-white transition-colors duration-500 space-y-4">
                <div class="w-12 h-12 border-editorial flex items-center justify-center text-[#3d7068]">
                    <i class="fa-solid fa-clock"></i>
                </div>
                <div class="font-playfair text-4xl text-[#1c1c1c]">100%</div>
                <div class="font-mono-custom font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#3d7068]">Schedule Accuracy</div>
            </div>
        </section>

        <!-- Text Reveal Section -->
        <section class="py-12 border-y border-[#e5e4de] text-center" id="revealSection">
            <p class="font-playfair text-2xl md:text-5xl leading-tight max-w-4xl mx-auto" id="revealParagraph">
                <span>Navi Track</span> <span>delivers</span> <span>seamless</span> <span>spatial</span> <span>intelligence</span> <span>connecting</span> <span>students</span> <span>and</span> <span>faculty</span> <span>to</span> <span>their</span> <span>academic</span> <span>destinations.</span>
            </p>
        </section>

        <!-- Interactive Workflow Section -->
        <section class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <!-- Left: Step Trigger Column -->
            <div class="space-y-8">
                <div class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068] border-b border-[#e5e4de] pb-3">
                    [ System Workflow ]
                </div>

                <div class="space-y-6">
                    <div onclick="selectWorkflow(1)" id="step-1" class="cursor-pointer transition-opacity duration-300 space-y-2 border-editorial p-6 bg-white">
                        <div class="font-mono-tech text-xs text-[#3d7068]">01 / SCAN</div>
                        <h3 class="font-playfair text-xl text-[#1c1c1c]">QR Laboratory Verification</h3>
                        <p class="font-grotesk text-xs text-[#1c1c1c]/70">Instantly check laboratory status and instructor schedules by scanning room QR identifiers.</p>
                    </div>

                    <div onclick="selectWorkflow(2)" id="step-2" class="cursor-pointer opacity-40 transition-opacity duration-300 space-y-2 border-editorial p-6 bg-[#f7f6f2]">
                        <div class="font-mono-tech text-xs text-[#3d7068]">02 / LOCATE</div>
                        <h3 class="font-playfair text-xl text-[#1c1c1c]">Interactive Floorplan Navigation</h3>
                        <p class="font-grotesk text-xs text-[#1c1c1c]/70">Explore the CAST building layout with precise room markers and destination highlights.</p>
                    </div>

                    <div onclick="selectWorkflow(3)" id="step-3" class="cursor-pointer opacity-40 transition-opacity duration-300 space-y-2 border-editorial p-6 bg-[#f7f6f2]">
                        <div class="font-mono-tech text-xs text-[#3d7068]">03 / TIMETABLE</div>
                        <h3 class="font-playfair text-xl text-[#1c1c1c]">Dynamic Schedule Synchronization</h3>
                        <p class="font-grotesk text-xs text-[#1c1c1c]/70">Access personal course timelines and block schedules updated by department chairs.</p>
                    </div>
                </div>
            </div>

            <!-- Right: Sticky Card with Scan-Line Progress Bar -->
            <div class="sticky top-28 border-editorial p-8 bg-white space-y-6">
                <div class="flex justify-between items-center border-b border-[#e5e4de] pb-4">
                    <span class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c]">Live Scanner Interface</span>
                    <span class="font-mono-tech text-[10px] text-[#3d7068]">ONLINE</span>
                </div>

                <div class="relative h-64 bg-[#1c1c1c] border-editorial overflow-hidden flex items-center justify-center">
                    <i class="fa-solid fa-qrcode text-6xl text-[#f7f6f2]/20"></i>
                    <div class="absolute inset-0 bg-gradient-to-b from-transparent via-[#3d7068]/20 to-transparent"></div>
                </div>

                <!-- Scan-Line Component -->
                <div class="space-y-2">
                    <div class="flex justify-between font-mono-tech text-[10px] text-[#1c1c1c]/60">
                        <span>SCANNING SYSTEM</span>
                        <span>ACTIVE</span>
                    </div>
                    <div class="h-[2px] w-full bg-[#e5e4de] overflow-hidden relative">
                        <div class="h-full w-full bg-[#3b82f6] animate-scan"></div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Use Case Tabs & Benefits Grid -->
        <section class="border-editorial p-10 bg-[#f7f6f2] relative overflow-hidden space-y-12">
            <div class="absolute right-[-40px] bottom-[-40px] opacity-[0.05] pointer-events-none">
                <i class="fa-solid fa-compass text-[240px] text-[#1c1c1c]"></i>
            </div>

            <div class="text-center space-y-4 max-w-xl mx-auto relative z-10">
                <div class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068]">
                    [ Institutional Services ]
                </div>
                <h2 class="font-playfair text-3xl md:text-4xl text-[#1c1c1c]">Integrated Academic Workflows</h2>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10 pt-6 border-t border-[#e5e4de]">
                <div class="space-y-2">
                    <span class="font-mono-tech text-xs text-[#3d7068]">01. STUDENT</span>
                    <h4 class="font-playfair text-lg text-[#1c1c1c]">Timetable View</h4>
                    <p class="font-grotesk text-xs text-[#1c1c1c]/70">Track room assignments and instructor schedules in real time.</p>
                </div>
                <div class="space-y-2">
                    <span class="font-mono-tech text-xs text-[#3d7068]">02. FACULTY</span>
                    <h4 class="font-playfair text-lg text-[#1c1c1c]">Laboratory Control</h4>
                    <p class="font-grotesk text-xs text-[#1c1c1c]/70">Manage subject allocations and laboratory occupancy availability.</p>
                </div>
                <div class="space-y-2">
                    <span class="font-mono-tech text-xs text-[#3d7068]">03. ADMINISTRATION</span>
                    <h4 class="font-playfair text-lg text-[#1c1c1c]">Central Management</h4>
                    <p class="font-grotesk text-xs text-[#1c1c1c]/70">Maintain user access roles, building structures, and course blocks.</p>
                </div>
            </div>
        </section>

        <!-- Access Request Contact Form -->
        <section class="grid grid-cols-1 lg:grid-cols-2 gap-12 border-editorial p-10 bg-white">
            <div class="space-y-4">
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068]">[ Inquiries ]</span>
                <h2 class="font-playfair text-4xl text-[#1c1c1c]">Request System Access</h2>
                <p class="font-grotesk text-xs text-[#1c1c1c]/70 max-w-md">
                    Require updated permissions or technical assistance with campus navigation credentials? Submit a formal request to administration.
                </p>
            </div>

            <form action="#" method="POST" class="space-y-6">
                <div>
                    <input type="text" placeholder="FULL NAME" required
                           class="w-full pb-3 bg-transparent border-b border-[#e5e4de] font-mono-tech text-xs text-[#1c1c1c] placeholder-[#1c1c1c]/40 focus:outline-none focus:border-[#3d7068] transition-colors">
                </div>
                <div>
                    <input type="email" placeholder="INSTITUTIONAL EMAIL" required
                           class="w-full pb-3 bg-transparent border-b border-[#e5e4de] font-mono-tech text-xs text-[#1c1c1c] placeholder-[#1c1c1c]/40 focus:outline-none focus:border-[#3d7068] transition-colors">
                </div>
                <div>
                    <input type="text" placeholder="DEPARTMENT / SECTION" required
                           class="w-full pb-3 bg-transparent border-b border-[#e5e4de] font-mono-tech text-xs text-[#1c1c1c] placeholder-[#1c1c1c]/40 focus:outline-none focus:border-[#3d7068] transition-colors">
                </div>
                
                <button type="submit" 
                        class="w-full py-4 btn-editorial font-mono-tech text-[10px] uppercase border-editorial shadow-sm">
                    Submit Access Request
                </button>
            </form>
        </section>

    </main>

    <!-- INTERACTIVE 3D MAP MODAL -->
    <div id="map3DModal" class="fixed inset-0 bg-[#1c1c1c]/80 backdrop-blur-md z-[99999] flex items-center justify-center hidden p-4">
        <div class="bg-[#f7f6f2] border-editorial text-[#1c1c1c] shadow-2xl w-full max-w-5xl overflow-hidden flex flex-col">
            
            <!-- Modal Header -->
            <div class="p-4 bg-[#f7f6f2] flex justify-between items-center border-b border-[#e5e4de]">
                <div class="flex items-center gap-3">
                    <span class="w-2 h-2 rounded-full bg-[#3d7068] animate-pulse"></span>
                    <div>
                        <h3 class="font-playfair text-lg font-bold uppercase tracking-wider text-[#1c1c1c]">CAST Building Interactive 3D Map</h3>
                        <p class="font-mono-tech text-[10px] text-[#1c1c1c]/60 uppercase tracking-widest">Left Click + Drag: Orbit | Scroll: Zoom | Click Room Block: Inspect</p>
                    </div>
                </div>
                <button onclick="close3DMapModal()" class="font-mono-tech text-sm uppercase px-3 py-1 hover:bg-[#e5e4de] border-editorial transition">
                    [ Close ]
                </button>
            </div>

            <!-- Modal Body (3D Viewport) -->
            <div class="relative">
                <div id="threejs-container"></div>
                
                <!-- HUD Room Info Overlay -->
                <div id="room-info-card" class="absolute top-4 left-4 bg-white/90 backdrop-blur border-editorial p-4 shadow-lg w-64 hidden space-y-1">
                    <span class="font-mono-tech text-[9px] uppercase text-[#3d7068] tracking-widest">[ Room Details ]</span>
                    <h4 id="info-room-name" class="font-playfair font-bold text-lg text-[#1c1c1c]">Room Name</h4>
                    <div class="font-mono-tech text-[10px] text-[#1c1c1c]/80 space-y-1 border-t border-[#e5e4de] pt-2">
                        <p>Location: CAST Building</p>
                        <p>Status: Active / Monitored</p>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="p-3 bg-[#f7f6f2] flex justify-between items-center border-t border-[#e5e4de] font-mono-tech text-[10px] text-[#1c1c1c]/60 uppercase tracking-widest">
                <span>NaviTrack Spatial Engine v1.0</span>
                <button onclick="reset3DCamera()" class="px-3 py-1 border-editorial hover:bg-white transition">
                    Reset Camera View
                </button>
            </div>
        </div>
    </div>

    <footer class="border-t border-[#e5e4de] bg-[#f7f6f2] relative z-10 py-8">
        <div class="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center gap-4 font-mono-tech text-[10px] text-[#1c1c1c]/60 uppercase tracking-widest">
            <div>© 2026 Navi Track • College of Arts & Sciences • BSIT WMT 3-1  </div>
            <div>Pangasinan State University</div>
        </div>
    </footer>

    <script>
        function selectWorkflow(stepNum) {
            for (let i = 1; i <= 3; i++) {
                const el = document.getElementById('step-' + i);
                if (i === stepNum) {
                    el.className = 'cursor-pointer transition-opacity duration-300 space-y-2 border-editorial p-6 bg-white opacity-100';
                } else {
                    el.className = 'cursor-pointer opacity-40 transition-opacity duration-300 space-y-2 border-editorial p-6 bg-[#f7f6f2]';
                }
            }
        }

        window.addEventListener('scroll', function() {
            const section = document.getElementById('revealSection');
            const spans = document.querySelectorAll('#revealParagraph span');
            if (!section) return;

            const rect = section.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            if (rect.top < windowHeight && rect.bottom > 0) {
                const progress = Math.min(Math.max((windowHeight - rect.top) / (windowHeight + rect.height), 0), 1);
                const activeIndex = Math.floor(progress * spans.length * 1.5);

                spans.forEach((span, idx) => {
                    if (idx <= activeIndex) {
                        span.style.opacity = '1.0';
                        span.style.color = '#1c1c1c';
                    } else {
                        span.style.opacity = '0.15';
                    }
                });
            }
        });

        /* THREE.JS 3D INTERACTIVE MAP LOGIC */
        let scene, camera, renderer, controls;
        let roomObjects = [];
        let raycaster = new THREE.Raycaster();
        let mouse = new THREE.Vector2();
        let is3DInitialized = false;

        function open3DMapModal() {
            document.getElementById('map3DModal').classList.remove('hidden');
            if (!is3DInitialized) {
                init3DMap();
                is3DInitialized = true;
            }
        }

        function close3DMapModal() {
            document.getElementById('map3DModal').classList.add('hidden');
        }

        function init3DMap() {
            const container = document.getElementById('threejs-container');
            const width = container.clientWidth;
            const height = container.clientHeight;

            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x0f172a);

            camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
            camera.position.set(0, 25, 35);

            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(width, height);
            renderer.shadowMap.enabled = true;
            container.appendChild(renderer.domElement);

            controls = new THREE.OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.maxPolarAngle = Math.PI / 2.1;

            const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
            scene.add(ambientLight);

            const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
            dirLight.position.set(20, 40, 20);
            scene.add(dirLight);

            // Ground Floor Geometry
            const floorGeo = new THREE.PlaneGeometry(30, 20);
            const floorMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, side: THREE.DoubleSide });
            const floor = new THREE.Mesh(floorGeo, floorMat);
            floor.rotation.x = -Math.PI / 2;
            scene.add(floor);

            const gridHelper = new THREE.GridHelper(30, 20, 0x3d7068, 0x334155);
            gridHelper.position.y = 0.01;
            scene.add(gridHelper);

      // CAST Building - First Floor Floorplan Coordinates
const roomsData = [
    // Top Row (North Wing)
    { name: "Business Incubation", x: -14, z: -10, w: 5, h: 3, d: 7, color: 0xE67E22 },
    { name: "IT Faculty Office", x: -7, z: -10, w: 6, h: 3, d: 6, color: 0x8FBC8F },
    { name: "Lobby / Main Hallway", x: 0, z: -10, w: 5, h: 0.2, d: 6, color: 0xCCCCCC },
    { name: "Business Ad Faculty Office", x: 7, z: -10, w: 6, h: 3, d: 6, color: 0xF1C40F },
    { name: "ABEL Faculty Office", x: 15, z: -10, w: 7, h: 3, d: 6, color: 0xB0C4DE },

    // Middle Row / Labs (Central Wing)
    { name: "Computer Laboratory 1", x: -8, z: -3, w: 9, h: 3, d: 4, color: 0x0047AB },
    { name: "Computer Laboratory 2 (iMAC)", x: 8, z: -3, w: 9, h: 3, d: 4, color: 0x0047AB },
    { name: "Speech Laboratory", x: 11, z: 2, w: 4, h: 3, d: 5, color: 0xF4D03F },

    // Left Inner Wing (Swapped Lab 3 & CAST Room 6 Positions & Colors)
    { name: "CAST Room 6", x: -10, z: 2, w: 4, h: 3, d: 4, color: 0xB0C4DE },
    { name: "Computer Laboratory 3", x: -10, z: 7, w: 4, h: 3, d: 3, color: 0x0047AB },
    { name: "CAST Room 5", x: -10, z: 11, w: 4, h: 3, d: 3, color: 0xB0C4DE },
    { name: "CAST Room 4", x: -10, z: 15, w: 4, h: 3, d: 3, color: 0xB0C4DE },

    // Left Corridor (West Wing)
    { name: "CR Ladies / Gents", x: -20, z: -11, w: 4, h: 3, d: 3, color: 0x85C1E9 },
    { name: "Stock Room", x: -20, z: -7, w: 4, h: 3, d: 2, color: 0x27AE60 },
    { name: "Office of the College Dean", x: -20, z: -4, w: 4, h: 3, d: 3, color: 0x9B59B6 },
    { name: "CAST Room 1", x: -20, z: 0, w: 4, h: 3, d: 4, color: 0xB0C4DE },
    { name: "CAST Room 2", x: -20, z: 5, w: 4, h: 3, d: 4, color: 0xB0C4DE },
    { name: "CAST Room 3", x: -20, z: 10, w: 4, h: 3, d: 4, color: 0xB0C4DE },
    { name: "BPA Faculty Office", x: -20, z: 15, w: 4, h: 3, d: 4, color: 0x800000 },

    // Right Corridor (East Wing)
    { name: "CAST Room 14", x: 20, z: -8, w: 4, h: 3, d: 6, color: 0xB0C4DE },
    { name: "ASTSA Office", x: 20, z: -3, w: 4, h: 3, d: 3, color: 0xB0C4DE },
    { name: "CAST Room 13", x: 20, z: 2, w: 4, h: 3, d: 5, color: 0xB0C4DE },
    { name: "CAST Room 12", x: 20, z: 8, w: 4, h: 3, d: 5, color: 0xB0C4DE },
    { name: "CAST Room 11", x: 20, z: 14, w: 4, h: 3, d: 5, color: 0xB0C4DE },

    // Right Inner Wing
    { name: "CAST Room 10", x: 12, z: 8, w: 4, h: 3, d: 4, color: 0xB0C4DE },
    { name: "CAST Room 9", x: 12, z: 14, w: 4, h: 3, d: 5, color: 0xB0C4DE }
];
            roomsData.forEach(r => {
                const geo = new THREE.BoxGeometry(r.w, r.h, r.d);
                const mat = new THREE.MeshStandardMaterial({ color: r.color, roughness: 0.3 });
                const mesh = new THREE.Mesh(geo, mat);
                mesh.position.set(r.x, r.h / 2, r.z);
                mesh.userData = { name: r.name };
                scene.add(mesh);
                roomObjects.push(mesh);
            });

            renderer.domElement.addEventListener('pointerdown', onPointerDown);

            window.addEventListener('resize', () => {
                if (!container) return;
                camera.aspect = container.clientWidth / container.clientHeight;
                camera.updateProjectionMatrix();
                renderer.setSize(container.clientWidth, container.clientHeight);
            });

            animate();
        }

        function onPointerDown(event) {
            const rect = renderer.domElement.getBoundingClientRect();
            mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            raycaster.setFromCamera(mouse, camera);
            const intersects = raycaster.intersectObjects(roomObjects);

            if (intersects.length > 0) {
                const clickedObj = intersects[0].object;
                showRoomDetails(clickedObj.userData.name);
            }
        }

        function showRoomDetails(name) {
            const card = document.getElementById('room-info-card');
            const title = document.getElementById('info-room-name');
            title.textContent = name;
            card.classList.remove('hidden');
        }

        function reset3DCamera() {
            if (camera && controls) {
                camera.position.set(0, 25, 35);
                controls.target.set(0, 0, 0);
                controls.update();
            }
        }

        function animate() {
            requestAnimationFrame(animate);
            if (controls) controls.update();
            if (renderer && scene && camera) renderer.render(scene, camera);
        }
    </script>
    <script src="js.js"></script>
</body>
</html>