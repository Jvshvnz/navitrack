<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../Sys_Database/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../LOGIN/login.php");
    exit();
}

$username =$_SESSION['username'] ?? 'Student';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navi Track • Block Overview</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Space+Grotesk:wght@300..700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="css.css">
    
    <style>
        :root {
            --bg-organic: #f7f6f2;
            --fg-dark: #1c1c1c;
            --accent-green: #3d7068;
            --border-line: #e5e4de;
            --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
        }

        body {
            background-color: var(--bg-organic);
            color: var(--fg-dark);
            font-family: 'Space Grotesk', sans-serif;
            transition: all 700ms var(--ease-editorial);
        }

        .font-playfair { font-family: 'Playfair Display', Georgia, serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .font-grotesk { font-family: 'Space Grotesk', sans-serif; }

        .editorial-grid-bg {
            background-size: 40px 40px;
            background-image: 
                linear-gradient(to right, rgba(229, 228, 222, 0.6) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(229, 228, 222, 0.6) 1px, transparent 1px);
            mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
            -webkit-mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
        }

        .border-editorial {
            border: 1px solid var(--border-line);
            border-radius: 2px !important;
        }

        .btn-editorial {
            background-color: var(--accent-green);
            color: #ffffff;
            transition: letter-spacing 400ms var(--ease-editorial);
            letter-spacing: 0.25em;
        }
        .btn-editorial:hover {
            letter-spacing: 0.35em;
        }
    </style>
</head>
<body class="relative min-h-screen overflow-x-hidden antialiased">

    <div class="fixed inset-0 pointer-events-none z-0 flex justify-between max-w-7xl mx-auto px-6">
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
    </div>

    <div class="fixed inset-0 pointer-events-none z-0 editorial-grid-bg"></div>

    <header class="fixed top-0 left-0 right-0 z-50 bg-[#f7f6f2]/80 backdrop-blur-md border-b border-[#e5e4de]">
        <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            
            <div class="flex items-center gap-3">
                <span class="w-6 h-[1px] bg-[#1c1c1c]"></span>
                <span class="font-playfair text-xl tracking-tight uppercase font-light text-[#1c1c1c]">Navi Track</span>
                <span class="w-8 h-[1px] bg-[#1c1c1c]"></span>
            </div>

            <nav class="flex items-center gap-6 font-mono-tech text-[10px] uppercase tracking-[0.3em]">
                <a href="student.php" class="text-[#1c1c1c] hover:text-[#3d7068] transition-colors flex items-center gap-2">
                    <span>[ ← Back To Portal ]</span>
                </a>
            </nav>
        </div>
    </header>

    <main class="relative z-10 max-w-7xl mx-auto px-6 pt-32 pb-24 space-y-12">

        <section class="border-editorial p-10 bg-white space-y-4">
            <div class="inline-flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-[#3d7068]"></span>
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">
                    Block Overview • Section BSIT-WMT 3-1
                </span>
            </div>
            
            <h1 class="font-playfair text-4xl md:text-5xl uppercase font-light text-[#1c1c1c]">
                Section Block <span class="italic text-[#B4B4B4]">Schedule</span>
            </h1>
            
            <p class="font-grotesk text-xs text-[#1c1c1c]/70 max-w-xl">
                Master timetable allocation for BSIT 3rd Year students assigned to the College of Arts & Sciences Building.
            </p>
        </section>

        <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            <div class="border-editorial p-8 bg-white hover:bg-[#f7f6f2] transition-colors duration-500 space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <span class="font-mono-tech text-[10px] uppercase tracking-widest text-[#3d7068]">[ MONDAY ]</span>
                    <span class="font-mono-tech text-[10px] text-[#1c1c1c]/50">LAB 1</span>
                </div>
                <div>
                    <h3 class="font-playfair text-2xl text-[#1c1c1c]">System Analysis & Design</h3>
                    <p class="font-mono-tech text-xs text-[#1c1c1c]/60 mt-2">08:00 AM - 11:00 AM</p>
                </div>
                <div class="pt-4 border-t border-[#e5e4de] font-mono-tech text-[10px] text-[#3d7068]">
                    STATUS: ACTIVE
                </div>
            </div>

            <div class="border-editorial p-8 bg-white hover:bg-[#f7f6f2] transition-colors duration-500 space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <span class="font-mono-tech text-[10px] uppercase tracking-widest text-[#3d7068]">[ TUESDAY ]</span>
                    <span class="font-mono-tech text-[10px] text-[#1c1c1c]/50">LAB 3</span>
                </div>
                <div>
                    <h3 class="font-playfair text-2xl text-[#1c1c1c]">Web Development 2</h3>
                    <p class="font-mono-tech text-xs text-[#1c1c1c]/60 mt-2">01:00 PM - 04:00 PM</p>
                </div>
                  <div class="pt-4 border-t border-[#e5e4de] font-mono-tech text-[10px] text-[#3d7068]">
                    STATUS: ACTIVE
                </div>
            </div>
