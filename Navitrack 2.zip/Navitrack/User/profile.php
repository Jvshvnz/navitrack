<?php
session_start();
require_once "../Sys_Database/db_connection.php";
global $conn;

// Session validation
if (!isset($_SESSION['user_id']) && !isset($_SESSION['prof_id'])) {
    header("Location: ../LOGIN/login.php");
    exit();
}

$user_id = $_SESSION['user_id'] ?? null;
$prof_id = $_SESSION['prof_id'] ?? null;

// 1. FETCH TEACHER & USER PROFILE FROM DATABASE (Guaranteed Columns Only)
$teacher_sql = "SELECT 
                    t.prof_id,
                    t.prof_name,
                    u.email
                FROM users u
                LEFT JOIN teachers t ON t.user_id = u.user_id
                WHERE u.user_id = ? OR t.prof_id = ?
                LIMIT 1";

$stmt = mysqli_prepare($conn, $teacher_sql);
mysqli_stmt_bind_param($stmt, "is", $user_id, $prof_id);
mysqli_stmt_execute($stmt);
$teacher = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Safe values with defaults
$prof_id_val   = $teacher['prof_id'] ?? ($_SESSION['prof_id'] ?? 'PSU-FACULTY');
$prof_name_val = $teacher['prof_name'] ?? ($_SESSION['username'] ?? 'Faculty Member');
$email_val     = $teacher['email'] ?? 'faculty@psu.edu.ph';
$dept_val      = "Information Technology";
$position_val  = "Instructor I";
$status_val    = "Active";
$role_val      = $_SESSION['role'] ?? 'Faculty';

// 2. FETCH DYNAMIC METRICS FROM DATABASE
// Count Assigned Subjects
$sub_count_sql = "SELECT COUNT(DISTINCT sub_id) AS total_subs FROM teacher_schedule WHERE prof_id = ?";
$stmt_sub = mysqli_prepare($conn, $sub_count_sql);
mysqli_stmt_bind_param($stmt_sub, "s", $prof_id_val);
mysqli_stmt_execute($stmt_sub);
$sub_count = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_sub))['total_subs'] ?? 0;

// Count Classes Today
$today_sql = "SELECT COUNT(*) AS total_today FROM teacher_schedule WHERE prof_id = ? AND UPPER(day_of_week) = UPPER(DAYNAME(CURDATE()))";
$stmt_today = mysqli_prepare($conn, $today_sql);
mysqli_stmt_bind_param($stmt_today, "s", $prof_id_val);
mysqli_stmt_execute($stmt_today);
$today_count = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_today))['total_today'] ?? 0;

// Count Assigned Rooms
$room_count_sql = "SELECT COUNT(DISTINCT room_id) AS total_rooms FROM teacher_schedule WHERE prof_id = ?";
$stmt_room = mysqli_prepare($conn, $room_count_sql);
mysqli_stmt_bind_param($stmt_room, "s", $prof_id_val);
mysqli_stmt_execute($stmt_room);
$room_count = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_room))['total_rooms'] ?? 0;

// 3. FETCH FULL TEACHING SCHEDULE FROM DATABASE (No joins on missing tables)
$schedule_sql = "SELECT 
                    ts.*
                 FROM teacher_schedule ts
                 WHERE ts.prof_id = ?
                 ORDER BY FIELD(ts.day_of_week, 'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'), ts.start_time";

$stmt_sched = mysqli_prepare($conn, $schedule_sql);
mysqli_stmt_bind_param($stmt_sched, "s", $prof_id_val);
mysqli_stmt_execute($stmt_sched);
$schedules_result = mysqli_stmt_get_result($stmt_sched);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navi Track • Teacher Profile</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/editorial-theme.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Space+Mono:ital,wght@0,400;0,700;1,400&family=Playfair+Display:ital,wght@0,400;0,600;1,400&display=swap');
        body { font-family: 'Space Grotesk', sans-serif; background-color: #f7f6f2; color: #1c1c1c; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .font-playfair { font-family: 'Playfair Display', serif; }
        .tab-active { background-color: #1c1c1c; color: #ffffff !important; }
    </style>
</head>
<body class="relative min-h-screen bg-[#f7f6f2] text-[#1c1c1c] antialiased">

    <!-- MAIN NAVBAR INCLUDE -->
    <?php include '../includes/navbar.php'; ?>

    <main class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">

        <!-- BREADCRUMB & HEADER -->
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#e5e4de] pb-6">
            <div>
                <nav class="flex items-center gap-2 font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c]/50 mb-1">
                    <a href="teacher.php" class="hover:text-[#3d7068]">Dashboard</a>
                    <span>/</span>
                    <span class="text-[#1c1c1c] font-bold">My Profile</span>
                </nav>
                <h1 class="font-playfair text-3xl sm:text-4xl font-normal text-[#1c1c1c]">Faculty Profile</h1>
            </div>

            <div class="flex items-center gap-4 font-mono-tech text-xs">
                <div class="px-3 py-1.5 bg-white border border-[#e5e4de] text-[#3d7068] font-bold">
                    <i class="far fa-calendar-alt mr-1.5"></i> A.Y. 2026–2027
                </div>
            </div>
        </div>

        <!-- PROFILE HEADER CARD (DB DRIVEN) -->
        <section class="bg-white border border-[#e5e4de] p-6 sm:p-8 shadow-sm">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div class="flex flex-col sm:flex-row items-start sm:items-center gap-6">
                    <div class="w-24 h-24 bg-[#3d7068] text-white flex items-center justify-center font-mono-tech text-3xl font-bold border-2 border-[#1c1c1c]">
                        <?= strtoupper(substr($prof_name_val, 0, 2)) ?>
                    </div>

                    <div class="space-y-1.5">
                        <div class="flex flex-wrap items-center gap-2">
                            <h2 class="font-playfair text-2xl sm:text-3xl font-bold text-[#1c1c1c]">
                                <?= htmlspecialchars($prof_name_val) ?>
                            </h2>
                            <span class="px-2.5 py-0.5 bg-emerald-50 border border-emerald-200 text-emerald-800 font-mono-tech text-[10px] font-bold uppercase">
                                <?= htmlspecialchars($status_val) ?>
                            </span>
                        </div>

                        <p class="font-mono-tech text-xs text-[#3d7068] font-bold uppercase tracking-wider">
                            <?= htmlspecialchars($position_val) ?> • <?= htmlspecialchars($dept_val) ?>
                        </p>
                        
                        <p class="text-xs text-[#1c1c1c]/70">
                            College of Arts, Sciences and Technology — PSU Bayambang
                        </p>

                        <div class="pt-2 flex flex-wrap items-center gap-4 text-xs font-mono-tech text-[#1c1c1c]/80">
                            <span><i class="far fa-id-badge mr-1.5 text-[#3d7068]"></i> ID: <strong><?= htmlspecialchars($prof_id_val) ?></strong></span>
                            <span><i class="far fa-envelope mr-1.5 text-[#3d7068]"></i> <?= htmlspecialchars($email_val) ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- DYNAMIC SUMMARY CARDS FROM DB -->
        <section class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div class="bg-white border border-[#e5e4de] p-5">
                <div class="flex items-center justify-between text-[#3d7068] mb-2"><i class="fas fa-book-open text-lg"></i></div>
                <div class="font-playfair text-3xl font-bold text-[#1c1c1c]"><?= $sub_count ?></div>
                <div class="font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c]/60 mt-1">Assigned Subjects</div>
            </div>

            <div class="bg-white border border-[#e5e4de] p-5">
                <div class="flex items-center justify-between text-[#3d7068] mb-2"><i class="fas fa-chalkboard-teacher text-lg"></i></div>
                <div class="font-playfair text-3xl font-bold text-[#1c1c1c]"><?= $today_count ?></div>
                <div class="font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c]/60 mt-1">Classes Today</div>
            </div>

            <div class="bg-white border border-[#e5e4de] p-5">
                <div class="flex items-center justify-between text-[#3d7068] mb-2"><i class="fas fa-door-open text-lg"></i></div>
                <div class="font-playfair text-3xl font-bold text-[#1c1c1c]"><?= $room_count ?></div>
                <div class="font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c]/60 mt-1">Assigned Rooms</div>
            </div>

            <div class="bg-white border border-[#e5e4de] p-5">
                <div class="flex items-center justify-between text-emerald-600 mb-2"><i class="fas fa-user-check text-lg"></i></div>
                <div class="font-playfair text-3xl font-bold text-[#1c1c1c]"><?= htmlspecialchars($role_val) ?></div>
                <div class="font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c]/60 mt-1">System Role</div>
            </div>
        </section>

        <!-- SCHEDULE TABLE FROM DB -->
        <section class="bg-white border border-[#e5e4de] p-6 sm:p-8 space-y-4">
            <div class="border-b border-[#e5e4de] pb-3 flex justify-between items-center">
                <h3 class="font-playfair text-xl font-bold text-[#1c1c1c]">Academic Teaching Load</h3>
                <span class="font-mono-tech text-xs text-[#3d7068]">Database Synced</span>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-sm">
                    <thead>
                        <tr class="border-b border-[#1c1c1c] font-mono-tech text-[10px] uppercase text-[#1c1c1c]/60 bg-[#f7f6f2]">
                            <th class="py-3 px-4">Subject</th>
                            <th class="py-3 px-4">Section / Block</th>
                            <th class="py-3 px-4">Day</th>
                            <th class="py-3 px-4">Time</th>
                            <th class="py-3 px-4">Room</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-[#e5e4de]">
                        <?php if ($schedules_result && mysqli_num_rows($schedules_result) > 0): ?>
                            <?php while ($sched = mysqli_fetch_assoc($schedules_result)): ?>
                                <tr class="hover:bg-[#f7f6f2]/60">
                                    <td class="py-3.5 px-4 font-mono-tech font-bold text-[#3d7068]">
                                        <?= htmlspecialchars($sched['sub_id'] ?? '—') ?>
                                    </td>
                                    <td class="py-3.5 px-4 font-mono-tech text-xs"><?= htmlspecialchars($sched['section'] ?? '—') ?></td>
                                    <td class="py-3.5 px-4 text-xs font-mono-tech"><?= htmlspecialchars($sched['day_of_week'] ?? '—') ?></td>
                                    <td class="py-3.5 px-4 text-xs font-mono-tech"><?= htmlspecialchars($sched['start_time'] ?? '') ?> – <?= htmlspecialchars($sched['end_time'] ?? '') ?></td>
                                    <td class="py-3.5 px-4 font-mono-tech text-xs"><?= htmlspecialchars($sched['room_id'] ?? '—') ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="py-8 text-center text-[#1c1c1c]/40 font-mono-tech text-xs">
                                    No active schedule assignments found in the database.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

    </main>

    <?php include '../includes/footer.php'; ?>
</body>
</html>