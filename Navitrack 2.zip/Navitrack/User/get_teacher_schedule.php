<?php
session_start();
require_once __DIR__ . '/../Sys_Database/db_connection.php';
$prof_id = (int)($_SESSION['prof_id'] ?? 0);
try {
    $stmt = $conn->prepare('SELECT ts.prof_id, ts.sub_id, s.subject_name, ts.room_id, r.room_name, ts.block_id, ts.day_of_week, ts.start_time, ts.end_time FROM teacher_schedule ts INNER JOIN subjects s ON ts.sub_id = s.sub_id INNER JOIN room_list r ON ts.room_id = r.room_id WHERE ts.prof_id = ? ORDER BY ts.day_of_week, ts.start_time');
    $stmt->bind_param('i', $prof_id); $stmt->execute();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($stmt->get_result()->fetch_all(MYSQLI_ASSOC), JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) { error_log('User/get_teacher_schedule.php: ' . $e->getMessage()); http_response_code(500); echo json_encode(['error' => 'Unable to load teacher schedule.']); }
?>
