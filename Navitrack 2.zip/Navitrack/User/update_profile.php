<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../Sys_Database/db_connection.php';

if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 2) {
    header("Location: ../LOGIN/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prof_name        = trim($_POST['prof_name'] ?? '');
    $new_password     = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // 1. Update Faculty Name in `teachers` table
    if (!empty($prof_name)) {
        $stmtProf = $conn->prepare("UPDATE teachers SET prof_name = ? WHERE user_id = ?");
        $stmtProf->bind_param("si", $prof_name, $user_id);
        $stmtProf->execute();
        $stmtProf->close();
    }

    // 2. Update Password if provided
    if (!empty($new_password)) {
        if ($new_password === $confirm_password) {
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $stmtPass = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $stmtPass->bind_param("si", $hashed_password, $user_id);
            $stmtPass->execute();
            $stmtPass->close();
        } else {
            header("Location: teacher.php?profile_msg=password_mismatch");
            exit;
        }
    }

    header("Location: teacher.php?profile_msg=updated");
    exit;
} else {
    header("Location: teacher.php");
    exit;
}
?>