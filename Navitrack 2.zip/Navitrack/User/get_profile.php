<?php
session_start();
require_once "../Sys_Database/db_connection.php";
global $conn;

header('Content-Type: application/json');

if (!isset($_SESSION['prof_id']) && !isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized session"]);
    exit();
}

$prof_id = $_SESSION['prof_id'] ?? null;
$user_id = $_SESSION['user_id'] ?? null;

// Query ONLY standard core columns from users and teachers
$sql = "SELECT 
            t.prof_id,
            t.prof_name,
            u.email
        FROM users u
        LEFT JOIN teachers t ON t.user_id = u.user_id
        WHERE u.user_id = ? OR t.prof_id = ?
        LIMIT 1";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "is", $user_id, $prof_id);
mysqli_stmt_execute($stmt);
$profile = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Fetch active class schedule if exists
$sched_sql = "SELECT 
                ts.sub_id,
                ts.room_id,
                ts.day_of_week,
                ts.start_time,
                ts.end_time
              FROM teacher_schedule ts
              WHERE ts.prof_id = ?
              AND UPPER(ts.day_of_week) = UPPER(DAYNAME(CURDATE()))
              AND CURTIME() BETWEEN ts.start_time AND ts.end_time
              LIMIT 1";

$stmt2 = mysqli_prepare($conn, $sched_sql);
mysqli_stmt_bind_param($stmt2, "s", $prof_id);
mysqli_stmt_execute($stmt2);
$currentClass = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt2));

echo json_encode([
    "prof_id"      => $profile['prof_id'] ?? ($_SESSION['prof_id'] ?? 'PSU-FACULTY'),
    "prof_name"    => $profile['prof_name'] ?? ($_SESSION['username'] ?? 'Faculty Member'),
    "email"        => $profile['email'] ?? 'faculty@psu.edu.ph',
    "department"   => "Information Technology",
    "position"     => "Instructor I",
    "role"         => $_SESSION['role'] ?? "Faculty",
    "status"       => "Active",
    "currentClass" => $currentClass ?? null
]);