<?php
session_start();
require_once "../Sys_Database/db_connection.php";
global $conn;

if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 2) {
    header("Location: ../LOGIN/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT user_id, username, role_id, is_active
        FROM users
        WHERE user_id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

$sqlTeacher = "SELECT * FROM teachers WHERE user_id = ?";

$stmt = mysqli_prepare($conn, $sqlTeacher);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$resultTeacher = mysqli_stmt_get_result($stmt);
$teacher = mysqli_fetch_assoc($resultTeacher);
$prof_id = $teacher['prof_id'] ?? 0;

$course_id = $teacher['course_id'] ?? 0;

$sqlCourse = "SELECT course_name FROM course_list WHERE course_id = ?";

$stmtCourse = mysqli_prepare($conn, $sqlCourse);
mysqli_stmt_bind_param($stmtCourse, "i", $course_id);
mysqli_stmt_execute($stmtCourse);
$resultCourse = mysqli_stmt_get_result($stmtCourse);
$course = mysqli_fetch_assoc($resultCourse);

date_default_timezone_set('Asia/Manila');
$today = strtoupper(date("l"));
$currentTime = date("H:i:s");

$sqlCurrentClass = "SELECT room_list.room_name, buildings.building_name, subjects.subject_name
                    FROM teacher_schedule
                    JOIN room_list 
                        ON teacher_schedule.room_id = room_list.room_id
                    JOIN buildings 
                        ON room_list.building_id = buildings.building_id
                    JOIN subjects 
                        ON teacher_schedule.sub_id = subjects.sub_id
                    WHERE teacher_schedule.prof_id = ? 
                    AND teacher_schedule.day_of_week = ? 
                    AND ? BETWEEN teacher_schedule.start_time 
                        AND teacher_schedule.end_time
                    LIMIT 1";
$stmtCurrent = mysqli_prepare($conn, $sqlCurrentClass);
mysqli_stmt_bind_param($stmtCurrent, "iss", $prof_id, $today, $currentTime);
mysqli_stmt_execute($stmtCurrent);

$resultCurrent = mysqli_stmt_get_result($stmtCurrent);
$currentClass = mysqli_fetch_assoc($resultCurrent);

$username = $user['username'] ?? 'Teacher';
$profile_msg = $_GET['profile_msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Campus Nav — PSU's official web room locator, scheduling system, and laboratory attendance & monitoring platform.">
    <title>Navi Track • Faculty Intelligence Portal</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Space+Grotesk:wght@300..700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="profile.css">
    <link rel="stylesheet" href="../assets/css/scanner.css">

    <style>
        :root {
            --bg-organic: #f7f6f2;
            --fg-dark: #1c1c1c;
            --accent-green: #3d7068;
            --border-line: #e5e4de;
            --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
        }

        body {
            background-color: var(--bg-organic);
            color: var(--fg-dark);
            font-family: 'Space Grotesk', sans-serif;
        }

        .font-playfair { font-family: 'Playfair Display', Georgia, serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .font-grotesk { font-family: 'Space Grotesk', sans-serif; }

        .editorial-grid-bg {
            background-size: 40px 40px;
            background-image: 
                linear-gradient(to right, rgba(229, 228, 222, 0.6) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(229, 228, 222, 0.6) 1px, transparent 1px);
        }

        .border-editorial {
            border: 1px solid var(--border-line);
            border-radius: 2px !important;
        }

        .btn-editorial {
            background-color: var(--accent-green);
            color: #ffffff;
            transition: letter-spacing 400ms var(--ease-editorial);
            letter-spacing: 0.15em;
        }
        .btn-editorial:hover {
            letter-spacing: 0.25em;
        }

        ::-webkit-scrollbar {
            height: 6px;
            width: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #f7f6f2;
        }
        ::-webkit-scrollbar-thumb {
            background: #3d7068;
        }
    </style>
</head>
<body class="relative min-h-screen bg-[#f7f6f2] text-[#1c1c1c] overflow-x-hidden antialiased pt-20">

    <!-- 1. LOADING OVERLAY -->
    <div id="loading-screen" class="fixed inset-0 z-[9999] bg-[#f7f6f2] flex items-center justify-center">
        <div class="editorial-grid-bg absolute inset-0 opacity-80"></div>
        <div class="relative z-10 text-center space-y-4 max-w-sm px-6">
            <div class="inline-flex items-center gap-2 px-3 py-1 border-editorial bg-white">
                <span class="w-2 h-2 rounded-full bg-[#3d7068] animate-pulse"></span>
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">Initializing Faculty System</span>
            </div>
            <div class="flex items-center justify-center gap-3">
                <img src="../assets/images/NaviTrack_Logo.png" alt="NaviTrack Logo" class="w-8 h-8 object-contain">
                <h1 class="font-playfair text-3xl font-light uppercase tracking-wider text-[#1c1c1c]">Navi Track</h1>
            </div>
            <p class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c]/60">Pangasinan State University</p>
            <div class="w-full h-1 bg-[#e5e4de] border-editorial overflow-hidden">
                <div id="ls-fill" class="h-full bg-[#3d7068] w-0 transition-all duration-300"></div>
            </div>
            <div class="flex justify-between font-mono-tech text-[10px] text-[#1c1c1c]/60">
                <span id="ls-status">Verifying Credentials...</span>
                <span id="ls-pct">0%</span>
            </div>
        </div>
    </div>

    <!-- 2. NAVBAR HEADER -->
    <?php include "../includes/navbar.php"; ?>

    <div class="fixed inset-0 pointer-events-none z-0 flex justify-between max-w-7xl mx-auto px-6">
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
    </div>

    <div class="fixed inset-0 pointer-events-none z-0 editorial-grid-bg opacity-70"></div>

    <!-- 3. INTERACTIVE PROFILE MODAL OVERLAY (VIEW & EDIT) -->
    <div id="profile-overlay" class="fixed inset-0 z-50 bg-[#1c1c1c]/60 backdrop-blur-sm hidden items-center justify-center p-4">
        <div class="max-w-2xl w-full bg-white border-editorial p-8 relative space-y-6 max-h-[90vh] overflow-y-auto" id="profile-panel">

            <button type="button" class="absolute top-6 right-6 font-mono-tech text-xs uppercase tracking-wider border-editorial px-3 py-1 bg-[#f7f6f2] hover:bg-red-50 hover:text-red-700 transition-colors cursor-pointer" onclick="closeProfileOverlay()">
                [ Close ESC ]
            </button>

            <!-- PROFILE HEADER -->
            <div class="flex flex-col sm:flex-row items-start sm:items-center gap-6 pb-6 border-b border-[#e5e4de]">
                <div class="w-20 h-20 bg-[#3d7068] text-white flex items-center justify-center font-playfair text-3xl border-editorial shrink-0">
                    <?= strtoupper(substr($teacher['prof_name'] ?? $username, 0, 2)); ?>
                </div>
                <div class="space-y-1">
                    <div class="inline-flex items-center gap-2 px-2.5 py-0.5 border-editorial bg-[#f7f6f2] font-mono-tech text-[9px] uppercase tracking-widest text-[#3d7068]">
                        <i class="fas fa-shield-alt"></i> Verified Faculty Account
                    </div>
                    <h2 class="font-playfair text-2xl font-light text-[#1c1c1c]"><?= htmlspecialchars($teacher['prof_name'] ?? $username); ?></h2>
                    <p class="font-mono-tech text-xs text-[#1c1c1c]/70">Instructor I • <?= htmlspecialchars($course['course_name'] ?? 'Department of Information Technology'); ?></p>
                </div>
            </div>

            <!-- PROFILE NAVIGATION TABS -->
            <div class="flex gap-2 border-b border-[#e5e4de] pb-3">
                <button type="button" id="tab-p-view" onclick="toggleProfileTab('view')" class="px-4 py-1.5 border-editorial bg-[#3d7068] text-white font-mono-tech text-[10px] uppercase tracking-wider">
                    Account Details
                </button>
                <button type="button" id="tab-p-edit" onclick="toggleProfileTab('edit')" class="px-4 py-1.5 border-editorial bg-white hover:bg-[#f7f6f2] font-mono-tech text-[10px] uppercase tracking-wider text-[#1c1c1c] transition-colors">
                    Edit Information
                </button>
            </div>

            <!-- TAB 1: VIEW PROFILE DETAILS -->
            <div id="profile-view-content" class="space-y-4">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="p-3 border-editorial bg-[#f7f6f2]">
                        <span class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/50">Username / Email</span>
                        <span class="font-mono-tech text-xs text-[#1c1c1c]"><?= htmlspecialchars($user['username'] ?? 'faculty@psu.edu.ph'); ?></span>
                    </div>
                    <div class="p-3 border-editorial bg-[#f7f6f2]">
                        <span class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/50">Faculty ID</span>
                        <span class="font-mono-tech text-xs text-[#3d7068] font-bold">PSU-FAC-<?= htmlspecialchars($prof_id); ?></span>
                    </div>
                    <div class="p-3 border-editorial bg-[#f7f6f2]">
                        <span class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/50">Academic Rank</span>
                        <span class="font-mono-tech text-xs text-[#1c1c1c]">Instructor I</span>
                    </div>
                    <div class="p-3 border-editorial bg-[#f7f6f2]">
                        <span class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/50">Campus Location</span>
                        <span class="font-mono-tech text-xs text-[#1c1c1c]">PSU Bayambang</span>
                    </div>
                </div>
            </div>

            <!-- TAB 2: EDIT PROFILE FORM -->
            <form id="profile-edit-content" action="update_profile.php" method="POST" class="hidden space-y-4">
                <div>
                    <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Full Display Name</label>
                    <input type="text" name="prof_name" value="<?= htmlspecialchars($teacher['prof_name'] ?? ''); ?>" required class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c] focus:outline-none focus:border-[#3d7068]">
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">New Password</label>
                        <input type="password" name="new_password" placeholder="Leave blank to keep current" class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c] focus:outline-none focus:border-[#3d7068]">
                    </div>
                    <div>
                        <label class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/70 mb-1">Confirm New Password</label>
                        <input type="password" name="confirm_password" placeholder="Confirm new password" class="w-full p-2.5 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#1c1c1c] focus:outline-none focus:border-[#3d7068]">
                    </div>
                </div>

                <button type="submit" class="w-full py-3.5 btn-editorial font-mono-tech text-[10px] uppercase border-editorial cursor-pointer">
                    Save Profile Changes
                </button>
            </form>

            <div class="pt-4 border-t border-[#e5e4de] flex flex-wrap gap-4 justify-between items-center">
                <button type="button" class="px-5 py-3 border-editorial bg-white font-mono-tech text-[10px] uppercase tracking-wider hover:bg-[#f7f6f2] transition-colors cursor-pointer" onclick="closeProfileOverlay(); document.getElementById('block-schedule').scrollIntoView({behavior:'smooth'})">
                    <i class="fas fa-calendar-week mr-2"></i> View Schedule
                </button>
                <button type="button" onclick="window.location.href='../LOGIN/login.php'" class="px-5 py-3 border-editorial bg-red-600 text-white font-mono-tech text-[10px] uppercase tracking-wider hover:bg-red-700 transition-colors cursor-pointer">
                    <i class="fas fa-sign-out-alt mr-2"></i> End Session
                </button>
            </div>
        </div>
    </div>

    <!-- MAIN BODY SECTION -->
    <section id="home" class="relative z-10 max-w-7xl mx-auto px-6 py-12 md:py-16">
        
        <?php if ($profile_msg === 'updated'): ?>
            <div class="mb-6 p-4 border-editorial bg-emerald-50 text-emerald-900 font-mono-tech text-xs flex items-center justify-between">
                <span>✓ Profile information updated successfully.</span>
                <a href="teacher.php" class="text-emerald-950 font-bold">[ Dismiss ]</a>
            </div>
        <?php elseif ($profile_msg === 'password_mismatch'): ?>
            <div class="mb-6 p-4 border-editorial bg-red-50 text-red-900 font-mono-tech text-xs flex items-center justify-between">
                <span>⚠ New passwords do not match. Please try again.</span>
                <a href="teacher.php" class="text-red-950 font-bold">[ Dismiss ]</a>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <div class="lg:col-span-7 space-y-8">
                <div class="inline-flex items-center gap-2 px-3 py-1 border-editorial bg-white">
                    <span class="w-2 h-2 rounded-full bg-[#3d7068] animate-pulse"></span>
                    <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">
                        Active Faculty Session
                    </span>
                </div>

                <div class="space-y-2">
                    <h1 class="font-playfair text-4xl sm:text-6xl font-light uppercase tracking-tight text-[#1c1c1c] leading-none">
                        Navigate.<br>
                        Schedule.<br>
                        <span class="italic text-[#3d7068]">Monitor.</span>
                    </h1>
                    <p class="font-grotesk text-sm sm:text-base text-[#1c1c1c]/70 max-w-xl">
                        PSU Bayambang's unified faculty hub — real-time classroom location verification, 
                        automated block scheduling, and QR-integrated laboratory monitoring for the CAST building.
                    </p>
                </div>

                <div class="grid grid-cols-3 gap-4 p-6 border-editorial bg-white">
                    <div>
                        <span class="block font-playfair text-3xl text-[#1c1c1c]">169</span>
                        <span class="font-mono-tech text-[9px] uppercase tracking-widest text-[#1c1c1c]/50">Faculty & Students</span>
                    </div>
                    <div class="border-l border-[#e5e4de] pl-4">
                        <span class="block font-playfair text-3xl text-[#3d7068]">24</span>
                        <span class="font-mono-tech text-[9px] uppercase tracking-widest text-[#1c1c1c]/50">Rooms Mapped</span>
                    </div>
                    <div class="border-l border-[#e5e4de] pl-4">
                        <span class="block font-playfair text-3xl text-[#1c1c1c]">CAST</span>
                        <span class="font-mono-tech text-[9px] uppercase tracking-widest text-[#1c1c1c]/50">Building Core</span>
                    </div>
                </div>

                <div class="flex flex-wrap gap-4 pt-2">
                    <button onclick="document.getElementById('room-locator').scrollIntoView({behavior:'smooth'})" class="px-8 py-4 btn-editorial border-editorial font-mono-tech text-[11px] uppercase cursor-pointer">
                        <i class="fas fa-qrcode mr-2"></i> Launch Verification Scanner
                    </button>
                    <button onclick="document.getElementById('block-schedule').scrollIntoView({behavior:'smooth'})" class="px-8 py-4 border-editorial bg-white hover:bg-[#f7f6f2] font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c] transition-colors cursor-pointer">
                        <i class="fas fa-calendar-alt mr-2"></i> Weekly Schedule
                    </button>
                </div>
            </div>

            <div class="lg:col-span-5 space-y-6">
                
                <div class="border-editorial bg-white p-6 space-y-4">
                    <div class="flex justify-between items-center border-b border-[#e5e4de] pb-3">
                        <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">Whereabouts Status</span>
                        <span class="w-2 h-2 rounded-full bg-[#3d7068]"></span>
                    </div>

                    <div>
                        <span class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/40 mb-1">Current Active Class</span>
                        <h3 class="font-playfair text-2xl text-[#1c1c1c]">
                            <?php
                            if ($currentClass) {
                                echo htmlspecialchars($currentClass['room_name'] . " · " . $currentClass['building_name'] . " · " . $currentClass['subject_name']);
                            } else {
                                echo "No scheduled class right now";
                            }
                            ?>
                        </h3>
                    </div>

                    <div class="pt-4 border-t border-[#e5e4de] flex items-center justify-between font-mono-tech text-xs">
                        <div class="flex items-center gap-2 text-[#3d7068]">
                            <i class="fas fa-clock"></i>
                            <span id="liveClock" class="font-bold">00:00:00</span>
                        </div>
                        <span id="currentDate" class="text-[#1c1c1c]/60">—</span>
                    </div>
                </div>

                <div class="border-editorial bg-white p-6 space-y-4">
                    <div class="flex justify-between items-center border-b border-[#e5e4de] pb-3">
                        <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#1c1c1c]/60">CAST Floor 1 Overview</span>
                        <span class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068]">Interactive</span>
                    </div>
                    
                    <div class="w-full h-48 bg-[#f7f6f2] border-editorial overflow-hidden relative flex items-center justify-center">
                        <img src="mapmap.jpg" alt="CAST Building Floor Map" class="w-full h-full object-contain p-2">
                    </div>

                    <a href="#room-locator" class="block text-center font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#3d7068] hover:underline">
                        Examine Room Layout Map →
                    </a>
                </div>

            </div>
        </div>
    </section>

    <!-- SCANNER SECTION -->
    <section id="room-locator" class="relative z-10 border-t border-[#e5e4de] bg-white py-16">
        <div class="max-w-7xl mx-auto px-6 space-y-8">

            <div class="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#e5e4de] pb-6">
                <div>
                    <div class="inline-flex items-center gap-2 font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068] mb-2">
                        <span>Laboratory Attendance</span>
                        <span>•</span>
                        <span>QR Verification</span>
                    </div>
                    <h2 class="font-playfair text-3xl md:text-4xl font-light uppercase text-[#1c1c1c]">Room Verification Scanner</h2>
                </div>
                <div class="px-4 py-2 border-editorial bg-[#f7f6f2] font-mono-tech text-xs text-[#3d7068] flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-[#3d7068] animate-pulse"></span>
                    <span id="liveTime">System Active</span>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">

                <div class="lg:col-span-8 space-y-6">
                    <div class="border-editorial bg-[#f7f6f2] p-6 space-y-6">
                        
                        <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                            <div>
                                <h3 class="font-mono-tech text-xs uppercase tracking-[0.2em] font-bold text-[#1c1c1c]">Scanner Feed</h3>
                                <p class="font-grotesk text-xs text-[#1c1c1c]/60">Align room QR code within camera focus frame</p>
                            </div>
                            <div id="statusBadge" class="px-3 py-1 border-editorial bg-white font-mono-tech text-[10px] uppercase tracking-widest text-[#3d7068]">
                                Ready
                            </div>
                        </div>

                        <div class="relative w-full aspect-video bg-[#1c1c1c] border-editorial overflow-hidden flex items-center justify-center">
                            <div id="reader" class="w-full h-full"></div>
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <button id="startBtn" class="py-4 btn-editorial font-mono-tech text-[10px] uppercase border-editorial cursor-pointer">
                                ▶ Start Camera Scanner
                            </button>
                            <button id="stopBtn" class="py-4 border-editorial bg-red-600 text-white font-mono-tech text-[10px] uppercase tracking-wider hover:bg-red-700 transition-colors cursor-pointer" disabled>
                                ■ Stop Camera Scanner
                            </button>
                        </div>

                        <div id="errorBox" class="hidden p-4 border-editorial bg-red-50 text-red-800 font-mono-tech text-xs"></div>
                    </div>

                    <div id="roomPanel" class="hidden border-editorial bg-emerald-50 p-6 space-y-4">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-emerald-700 text-xl"></i>
                            <h3 class="font-mono-tech text-xs uppercase tracking-widest font-bold text-emerald-900">Room Authenticated Successfully</h3>
                        </div>
                        <div id="roomDetails" class="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono-tech text-xs text-emerald-950"></div>
                    </div>
                </div>

                <div class="lg:col-span-4 space-y-6">
                    <div class="border-editorial bg-[#f7f6f2] p-6 space-y-6">
                        <h3 class="font-mono-tech text-xs uppercase tracking-[0.25em] text-[#1c1c1c] pb-3 border-b border-[#e5e4de]">Attendance Status</h3>

                        <div id="scanResultBox" class="p-5 border-editorial bg-white space-y-4">
                            <div class="flex items-center gap-3">
                                <div id="scanIcon" class="w-8 h-8 border-editorial bg-[#f7f6f2] flex items-center justify-center font-mono-tech text-xs">
                                    ⏳
                                </div>
                                <div>
                                    <p id="scanTitle" class="font-mono-tech text-xs font-bold text-[#1c1c1c]">Awaiting Room Scan...</p>
                                    <p id="scanSubtitle" class="font-grotesk text-[10px] text-[#1c1c1c]/60">Scan QR code located at entrance</p>
                                </div>
                            </div>

                            <div class="pt-3 border-t border-[#e5e4de] font-mono-tech text-[10px] space-y-2 uppercase text-[#1c1c1c]/70">
                                <div class="flex justify-between">
                                    <span>Room State:</span>
                                    <span id="roomStatusText" class="font-bold text-[#1c1c1c]">—</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>System Action:</span>
                                    <span id="actionText" class="font-bold text-[#1c1c1c]">—</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Timestamp:</span>
                                    <span id="timeText" class="font-bold text-[#3d7068]">—</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- SCHEDULE MATRIX SECTION -->
    <section id="block-schedule" class="relative z-10 max-w-7xl mx-auto px-6 py-16 space-y-8">
        
        <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#e5e4de] pb-6">
            <div>
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068]">Teaching Assignment</span>
                <h2 class="font-playfair text-3xl sm:text-4xl font-light uppercase text-[#1c1c1c]">Faculty Schedule Grid</h2>
            </div>
            
            <div class="flex gap-2">
                <button onclick="switchSchedView('grid')" id="tab-grid" class="px-5 py-2 border-editorial bg-[#3d7068] text-white font-mono-tech text-[10px] uppercase tracking-wider cursor-pointer">
                    Weekly Grid
                </button>
                <button onclick="switchSchedView('list')" id="tab-list" class="px-5 py-2 border-editorial bg-white hover:bg-[#f7f6f2] font-mono-tech text-[10px] uppercase tracking-wider text-[#1c1c1c] transition-colors cursor-pointer">
                    List Mode
                </button>
            </div>
        </div>

        <div id="sched-view-grid" class="border-editorial bg-white overflow-x-auto p-4">
            <table class="w-full border-collapse min-w-[860px]">
                <thead>
                    <tr class="border-b border-[#e5e4de] bg-[#f7f6f2]">
                        <th class="text-left p-3 font-mono-tech text-[10px] uppercase tracking-widest text-[#3d7068] font-bold w-20">Time</th>
                        <th class="text-left p-3 font-mono-tech text-[10px] uppercase tracking-widest text-[#1c1c1c] font-bold">Monday</th>
                        <th class="text-left p-3 font-mono-tech text-[10px] uppercase tracking-widest text-[#1c1c1c] font-bold">Tuesday</th>
                        <th class="text-left p-3 font-mono-tech text-[10px] uppercase tracking-widest text-[#1c1c1c] font-bold">Wednesday</th>
                        <th class="text-left p-3 font-mono-tech text-[10px] uppercase tracking-widest text-[#1c1c1c] font-bold">Thursday</th>
                        <th class="text-left p-3 font-mono-tech text-[10px] uppercase tracking-widest text-[#1c1c1c] font-bold">Friday</th>
                        <th class="text-left p-3 font-mono-tech text-[10px] uppercase tracking-widest text-[#1c1c1c] font-bold">Saturday</th>
                    </tr>
                </thead>
                <tbody id="grid-body">
                </tbody>
            </table>
        </div>

        <div id="sched-view-list" class="hidden border-editorial bg-white p-6 font-mono-tech text-xs">
            <p class="text-[#1c1c1c]/60">Switch back to Weekly Grid view for detailed hourly assignment cards.</p>
        </div>
    </section>

    <!-- ABOUT / SYSTEM SPEC SECTION -->
    <section id="about" class="relative z-10 border-t border-[#e5e4de] bg-[#f7f6f2] py-16">
        <div class="max-w-7xl mx-auto px-6 space-y-12">
            
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div class="lg:col-span-6 space-y-4">
                    <span class="font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[#3d7068]">System Specification</span>
                    <h2 class="font-playfair text-3xl font-light uppercase text-[#1c1c1c]">Built for PSU Bayambang</h2>
                    <p class="font-grotesk text-sm text-[#1c1c1c]/70 leading-relaxed">
                        Navi Track eliminates room allocation confusion, resolves schedule overlaps, 
                        and digitizes laboratory attendance tracking across the CAST building.
                    </p>
                    <div class="pt-4 border-t border-[#e5e4de] font-mono-tech text-[10px] text-[#1c1c1c]/50 uppercase">
                        Version 2.4 • Academic Year 2025–2026
                    </div>
                </div>

                <div class="lg:col-span-6 grid grid-cols-2 gap-4 font-mono-tech text-xs">
                    <div class="p-4 border-editorial bg-white">
                        <span class="block text-[9px] uppercase text-[#1c1c1c]/50">Subsystem 01</span>
                        <span class="font-bold text-[#1c1c1c]">CampusNav 2</span>
                        <p class="font-grotesk text-[10px] text-[#1c1c1c]/60 mt-1">Interactive room locator & class schedules</p>
                    </div>
                    <div class="p-4 border-editorial bg-white">
                        <span class="block text-[9px] uppercase text-[#1c1c1c]/50">Subsystem 02</span>
                        <span class="font-bold text-[#3d7068]">BSIT SmartLog</span>
                        <p class="font-grotesk text-[10px] text-[#1c1c1c]/60 mt-1">QR lab attendance monitoring</p>
                    </div>
                </div>
            </div>

            <div class="pt-8 border-t border-[#e5e4de]">
                <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#1c1c1c]/50 mb-6">Development Engineering Team</div>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div class="p-4 border-editorial bg-white space-y-1">
                        <span class="block font-mono-tech text-xs font-bold text-[#1c1c1c]">Joshua Vince Junio II</span>
                        <span class="block font-mono-tech text-[9px] uppercase text-[#3d7068]">Frontend Developer • UI/UX</span>
                    </div>
                    <div class="p-4 border-editorial bg-white space-y-1">
                        <span class="block font-mono-tech text-xs font-bold text-[#1c1c1c]">Elijah Josh Fajardo</span>
                        <span class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/60">Backend Developer • Logic</span>
                    </div>
                    <div class="p-4 border-editorial bg-white space-y-1">
                        <span class="block font-mono-tech text-xs font-bold text-[#1c1c1c]">Viktor Isaac Arcega</span>
                        <span class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/60">Documentation • Testing</span>
                    </div>
                    <div class="p-4 border-editorial bg-white space-y-1">
                        <span class="block font-mono-tech text-xs font-bold text-[#1c1c1c]">Jesreel Ignacio Calimlim</span>
                        <span class="block font-mono-tech text-[9px] uppercase text-[#1c1c1c]/60">Figma • System Analysis</span>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <?php include "../includes/footer.php"; ?>

    <!-- GLOBAL JS DEPENDENCIES -->
    <script src="https://unpkg.com/html5-qrcode"></script>
    <script>
    window.currentUser = {
        profId: "<?php echo htmlspecialchars($_SESSION['prof_id'] ?? $prof_id); ?>",
        username: "<?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?>"
    };
    </script>
    <script src="../assets/js/mainuser.js"></script>
    <script src="../assets/js/scanner.js"></script>

    <!-- UNIFIED CLIENT LOGIC -->
    <script>
    function openProfileOverlay() {
        const overlay = document.getElementById('profile-overlay');
        if (overlay) {
            overlay.classList.remove('hidden');
            overlay.style.display = 'flex';
        }
    }

    function closeProfileOverlay() {
        const overlay = document.getElementById('profile-overlay');
        if (overlay) {
            overlay.classList.add('hidden');
            overlay.style.display = 'none';
        }
    }

    function toggleProfileTab(tab) {
        const viewTab = document.getElementById('profile-view-content');
        const editTab = document.getElementById('profile-edit-content');
        const btnView = document.getElementById('tab-p-view');
        const btnEdit = document.getElementById('tab-p-edit');

        if (tab === 'edit') {
            viewTab.classList.add('hidden');
            editTab.classList.remove('hidden');
            btnEdit.className = "px-4 py-1.5 border-editorial bg-[#3d7068] text-white font-mono-tech text-[10px] uppercase tracking-wider cursor-pointer";
            btnView.className = "px-4 py-1.5 border-editorial bg-white hover:bg-[#f7f6f2] font-mono-tech text-[10px] uppercase tracking-wider text-[#1c1c1c] transition-colors cursor-pointer";
        } else {
            editTab.classList.add('hidden');
            viewTab.classList.remove('hidden');
            btnView.className = "px-4 py-1.5 border-editorial bg-[#3d7068] text-white font-mono-tech text-[10px] uppercase tracking-wider cursor-pointer";
            btnEdit.className = "px-4 py-1.5 border-editorial bg-white hover:bg-[#f7f6f2] font-mono-tech text-[10px] uppercase tracking-wider text-[#1c1c1c] transition-colors cursor-pointer";
        }
    }

    function switchSchedView(view) {
        const grid = document.getElementById('sched-view-grid');
        const list = document.getElementById('sched-view-list');
        if (grid && list) {
            grid.classList.toggle('hidden', view !== 'grid');
            list.classList.toggle('hidden', view !== 'list');
        }
        
        const tabGrid = document.getElementById('tab-grid');
        const tabList = document.getElementById('tab-list');
        if (tabGrid && tabList) {
            if (view === 'grid') {
                tabGrid.className = "px-5 py-2 border-editorial bg-[#3d7068] text-white font-mono-tech text-[10px] uppercase tracking-wider cursor-pointer";
                tabList.className = "px-5 py-2 border-editorial bg-white hover:bg-[#f7f6f2] font-mono-tech text-[10px] uppercase tracking-wider text-[#1c1c1c] transition-colors cursor-pointer";
            } else {
                tabList.className = "px-5 py-2 border-editorial bg-[#3d7068] text-white font-mono-tech text-[10px] uppercase tracking-wider cursor-pointer";
                tabGrid.className = "px-5 py-2 border-editorial bg-white hover:bg-[#f7f6f2] font-mono-tech text-[10px] uppercase tracking-wider text-[#1c1c1c] transition-colors cursor-pointer";
            }
        }
    }

    const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const TIMES = ['7:00','7:30','8:00','8:30','9:00','9:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30'];

    function timeInRange(checkTime, startTime, endTime) {
        const toM = (t) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
        return toM(checkTime) >= toM(startTime) && toM(checkTime) < toM(endTime);
    }

    async function initGrid() {
        try {
            const response = await fetch('get_schedule_json.php');
            const mySched = await response.json();

            const tbody = document.getElementById('grid-body');
            if (!tbody) return;
            tbody.innerHTML = '';

            TIMES.forEach(time => {
                const tr = document.createElement('tr');
                tr.className = 'border-b border-[#e5e4de] hover:bg-[#f7f6f2]/50 transition-colors';
                tr.innerHTML = `<td class="p-2 font-mono-tech text-[10px] text-[#3d7068] font-bold border-r border-[#e5e4de]">${time}</td>`;

                DAYS.forEach(day => {
                    const td = document.createElement('td');
                    td.className = 'border-r border-[#e5e4de] align-top p-1 min-w-[110px]';
                    
                    const matches = mySched.filter(s => 
                        s.day_of_week && s.day_of_week.trim().toLowerCase() === day.toLowerCase() && 
                        timeInRange(time, s.start_time, s.end_time)
                    );

                    matches.forEach(s => {
                        td.innerHTML += `
                            <div class="p-2 border-editorial bg-[#f7f6f2] mb-1 space-y-0.5">
                                <div class="font-mono-tech text-[10px] font-bold text-[#3d7068] uppercase">${s.subject_name}</div>
                                <div class="font-mono-tech text-[9px] text-[#1c1c1c]/70">${s.blocks || ''}</div>
                                <div class="font-mono-tech text-[9px] text-[#1c1c1c]/50">${s.room_name}</div>
                            </div>`;
                    });
                    tr.appendChild(td);
                });
                tbody.appendChild(tr);
            });
        } catch (e) {
            console.error("Schedule grid initialization error:", e);
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        initGrid();

        // 1. Profile Header Button Event Binding
        const profileBtn = document.getElementById('profileHeaderBtn');
        const profileOverlay = document.getElementById('profile-overlay');

        if (profileBtn && profileOverlay) {
            profileBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                openProfileOverlay();
            });
        }

        // Close when clicking dark backdrop
        if (profileOverlay) {
            profileOverlay.addEventListener('click', (e) => {
                if (e.target.id === 'profile-overlay') {
                    closeProfileOverlay();
                }
            });
        }

        // Close on ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeProfileOverlay();
            }
        });

        // 2. Loading Overlay Progress Animation
        const ls = document.getElementById('loading-screen');
        const fill = document.getElementById('ls-fill');
        const pct = document.getElementById('ls-pct');
        const status = document.getElementById('ls-status');

        if (ls) {
            let progress = 0;
            const stages = [
                { p: 35, msg: 'Verifying Credentials...' },
                { p: 70, msg: 'Synchronizing Schedule Matrix...' },
                { p: 100, msg: 'System Ready' }
            ];

            let currentStage = 0;

            const interval = setInterval(() => {
                if (currentStage < stages.length) {
                    progress = stages[currentStage].p;
                    if (fill) fill.style.width = progress + '%';
                    if (pct) pct.innerText = progress + '%';
                    if (status) status.innerText = stages[currentStage].msg;
                    currentStage++;
                } else {
                    clearInterval(interval);
                    setTimeout(() => {
                        ls.style.transition = 'opacity 500ms ease-out, visibility 500ms';
                        ls.style.opacity = '0';
                        ls.style.visibility = 'hidden';
                        setTimeout(() => ls.remove(), 500);
                    }, 300);
                }
            }, 200);
        }
    });
    </script>
</body>
</html>