<?php
session_start();

// Fallback sample data matching Navi Track faculty specification
$teacher = [
    'prof_id'      => $_SESSION['prof_id'] ?? 'PSU-2026-001',
    'prof_name'    =>$_SESSION['username'] ?? 'Michael Peoro',
    'email'        => $_SESSION['email'] ?? 'michael.peoro@university.edu',
    'phone'        => $_SESSION['phone'] ?? '+63 917 555 0192',
    'position'     =>$_SESSION['position'] ?? 'Instructor I',
    'department'   => $_SESSION['department'] ?? 'Information Technology',
    'college'      => $_SESSION['college'] ?? 'College of Arts, Sciences and Technology',
    'specialization' => 'Web & Mobile Technologies, Database Systems',
    'office'       => 'CAST Building — 2nd Floor, Room 204',
    'consultation' => 'Mon / Wed — 1:00 PM to 3:00 PM',
    'status'       => 'Active',
    'role'         => 'Faculty',
    'avatar'       => $_SESSION['avatar'] ?? null // Set image path or leave null for initials fallback
];

$academic_year = "A.Y. 2026–2027";
$semester      = "1st Semester";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navi Track • Teacher Profile</title>
    <!-- Tailwind CSS & FontAwesome -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/editorial-theme.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Space+Mono:ital,wght@0,400;0,700;1,400&family=Playfair+Display:ital,wght@0,400;0,600;1,400&display=swap');
        
        body {
            font-family: 'Space Grotesk', sans-serif;
            background-color: #f7f6f2;
            color: #1c1c1c;
        }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .font-playfair { font-family: 'Playfair Display', serif; }
        .border-editorial { border-color: #e5e4de; }
        .tab-active {
            background-color: #1c1c1c;
            color: #ffffff !important;
            border-color: #1c1c1c !important;
        }
    </style>
</head>
<body class="relative min-h-screen bg-[#f7f6f2] text-[#1c1c1c] overflow-x-hidden antialiased">

    <!-- Background Grid Lines -->
    <div class="fixed inset-0 pointer-events-none z-0 flex justify-between max-w-7xl mx-auto px-6 opacity-40">
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
    </div>

    <!-- MAIN NAVBAR INCLUDE -->
    <?php 
    if (file_exists('../includes/navbar.php')) {
        include '../includes/navbar.php'; 
    } else { ?>
        <nav class="sticky top-0 z-40 bg-[#f7f6f2]/90 backdrop-blur-md border-b border-[#e5e4de]">
            <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <span class="w-3 h-3 bg-[#3d7068]"></span>
                    <span class="font-playfair text-2xl uppercase tracking-wider font-light">Navi Track</span>
                </div>
                <div class="font-mono-tech text-xs text-[#3d7068] font-bold">PSU BAYAMBANG</div>
            </div>
        </nav>
    <?php } ?>

    <!-- MAIN CONTENT WRAPPER -->
    <main class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">

        <!-- BREADCRUMB & PAGE HEADER -->
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#e5e4de] pb-6">
            <div>
                <nav class="flex items-center gap-2 font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c]/50 mb-1">
                    <a href="teacher.php" class="hover:text-[#3d7068] transition-colors">Dashboard</a>
                    <span>/</span>
                    <span class="text-[#1c1c1c] font-bold">My Profile</span>
                </nav>
                <h1 class="font-playfair text-3xl sm:text-4xl font-normal tracking-tight text-[#1c1c1c]">Faculty Profile</h1>
            </div>

            <div class="flex items-center gap-4">
                <!-- Academic Year Badge -->
                <div class="px-3 py-1.5 bg-white border border-[#e5e4de] font-mono-tech text-xs text-[#3d7068] font-bold tracking-wider uppercase">
                    <i class="far fa-calendar-alt mr-1.5"></i> <?= $academic_year ?>
                </div>

                <!-- Notification Bell Button -->
                <div class="relative">
                    <button id="notifBellBtn" onclick="toggleNotifications()" class="relative p-2.5 bg-white border border-[#e5e4de] hover:bg-[#eae8e1] transition-colors cursor-pointer" aria-label="Notifications">
                        <i class="far fa-bell text-base text-[#1c1c1c]"></i>
                        <span class="absolute top-1 right-1 w-2.5 h-2.5 bg-amber-500 rounded-full ring-2 ring-white"></span>
                    </button>

                    <!-- NOTIFICATIONS OVERLAY PANEL -->
                    <div id="notifPanel" class="hidden absolute right-0 mt-3 w-80 sm:w-96 bg-white border border-[#e5e4de] shadow-2xl z-50 p-4">
                        <div class="flex items-center justify-between border-b border-[#e5e4de] pb-3 mb-3">
                            <h3 class="font-mono-tech text-xs font-bold uppercase tracking-wider text-[#1c1c1c]">Notifications</h3>
                            <span class="px-2 py-0.5 bg-amber-100 text-amber-800 font-mono-tech text-[10px] font-bold">2 Unread</span>
                        </div>
                        <div class="space-y-3 max-h-64 overflow-y-auto pr-1">
                            <div class="p-3 bg-[#f7f6f2] border-l-2 border-[#3d7068] text-xs">
                                <p class="font-bold text-[#1c1c1c]">Schedule Update — CAST Lab 1</p>
                                <p class="text-[#1c1c1c]/70 text-[11px] mt-1">IT 212 lecture room moved to Room 106 for Oct 14 session.</p>
                                <span class="font-mono-tech text-[9px] text-[#3d7068] mt-2 block">10 mins ago</span>
                            </div>
                            <div class="p-3 bg-[#f7f6f2] border-l-2 border-amber-500 text-xs">
                                <p class="font-bold text-[#1c1c1c]">QR Verification Reminder</p>
                                <p class="text-[#1c1c1c]/70 text-[11px] mt-1">Please scan room QR code prior to starting class in CAST 204.</p>
                                <span class="font-mono-tech text-[9px] text-amber-700 mt-2 block">1 hour ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- PROFILE HEADER CARD -->
        <section class="bg-white border border-[#e5e4de] p-6 sm:p-8 shadow-sm">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                
                <div class="flex flex-col sm:flex-row items-start sm:items-center gap-6">
                    <!-- Avatar with Fallback Initials -->
                    <div class="relative group">
                        <?php if (!empty($teacher['avatar'])): ?>
                            <img src="<?= htmlspecialchars($teacher['avatar']) ?>" alt="Faculty Avatar" class="w-24 h-24 object-cover border-2 border-[#3d7068]">
                        <?php else: ?>
                            <div class="w-24 h-24 bg-[#3d7068] text-white flex items-center justify-center font-mono-tech text-3xl font-bold border-2 border-[#1c1c1c]">
                                <?= strtoupper(substr($teacher['prof_name'], 0, 2)) ?>
                            </div>
                        <?php endif; ?>
                        <span class="absolute -bottom-1 -right-1 bg-emerald-600 text-white p-1 rounded-none text-xs" title="Verified Faculty Account">
                            <i class="fas fa-check-circle"></i>
                        </span>
                    </div>

                    <!-- Teacher Meta Details -->
                    <div class="space-y-1.5">
                        <div class="flex flex-wrap items-center gap-2">
                            <h2 class="font-playfair text-2xl sm:text-3xl font-bold text-[#1c1c1c]" id="displayProfName">
                                <?= htmlspecialchars($teacher['prof_name']) ?>
                            </h2>
                            <span class="px-2.5 py-0.5 bg-emerald-50 border border-emerald-200 text-emerald-800 font-mono-tech text-[10px] font-bold uppercase tracking-wider">
                                <?= htmlspecialchars($teacher['status']) ?>
                            </span>
                            <span class="px-2.5 py-0.5 bg-[#3d7068]/10 border border-[#3d7068]/30 text-[#3d7068] font-mono-tech text-[10px] font-bold uppercase tracking-wider">
                                Verified
                            </span>
                        </div>

                        <p class="font-mono-tech text-xs text-[#3d7068] font-bold uppercase tracking-wider">
                            <?= htmlspecialchars($teacher['position']) ?> • <?= htmlspecialchars($teacher['department']) ?>
                        </p>
                        
                        <p class="text-xs text-[#1c1c1c]/70">
                            <?= htmlspecialchars($teacher['college']) ?>
                        </p>

                        <div class="pt-2 flex flex-wrap items-center gap-4 text-xs font-mono-tech text-[#1c1c1c]/80">
                            <span><i class="far fa-id-badge mr-1.5 text-[#3d7068]"></i> ID: <strong class="text-[#1c1c1c]"><?= htmlspecialchars($teacher['prof_id']) ?></strong></span>
                            <span><i class="far fa-envelope mr-1.5 text-[#3d7068]"></i> <span id="displayEmail"><?= htmlspecialchars($teacher['email']) ?></span></span>
                        </div>
                    </div>
                </div>

                <!-- Action Button -->
                <div class="flex lg:flex-col items-stretch justify-end gap-3 border-t lg:border-t-0 border-[#e5e4de] pt-4 lg:pt-0">
                    <button onclick="openEditModal()" class="px-5 py-3 bg-[#1c1c1c] hover:bg-[#3d7068] text-white font-mono-tech text-xs uppercase tracking-widest transition-colors flex items-center justify-center gap-2 cursor-pointer">
                        <i class="far fa-edit"></i> Edit Profile
                    </button>
                </div>
            </div>
        </section>

        <!-- PROFILE METRIC SUMMARY CARDS -->
        <section class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div class="bg-white border border-[#e5e4de] p-5 hover:border-[#3d7068] transition-colors">
                <div class="flex items-center justify-between text-[#3d7068] mb-2">
                    <i class="fas fa-book-open text-lg"></i>
                    <span class="font-mono-tech text-[10px] text-[#1c1c1c]/40 uppercase tracking-widest">Active</span>
                </div>
                <div class="font-playfair text-3xl font-bold text-[#1c1c1c]">3</div>
                <div class="font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c]/60 mt-1">Assigned Subjects</div>
            </div>

            <div class="bg-white border border-[#e5e4de] p-5 hover:border-[#3d7068] transition-colors">
                <div class="flex items-center justify-between text-[#3d7068] mb-2">
                    <i class="fas fa-chalkboard-teacher text-lg"></i>
                    <span class="font-mono-tech text-[10px] text-[#1c1c1c]/40 uppercase tracking-widest">Schedule</span>
                </div>
                <div class="font-playfair text-3xl font-bold text-[#1c1c1c]">3</div>
                <div class="font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c]/60 mt-1">Classes Today</div>
            </div>

            <div class="bg-white border border-[#e5e4de] p-5 hover:border-[#3d7068] transition-colors">
                <div class="flex items-center justify-between text-[#3d7068] mb-2">
                    <i class="fas fa-door-open text-lg"></i>
                    <span class="font-mono-tech text-[10px] text-[#1c1c1c]/40 uppercase tracking-widest">CAST Bldg</span>
                </div>
                <div class="font-playfair text-3xl font-bold text-[#1c1c1c]">2</div>
                <div class="font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c]/60 mt-1">Assigned Rooms</div>
            </div>

            <div class="bg-white border border-[#e5e4de] p-5 hover:border-[#3d7068] transition-colors">
                <div class="flex items-center justify-between text-amber-600 mb-2">
                    <i class="fas fa-bell text-lg"></i>
                    <span class="font-mono-tech text-[10px] text-amber-600 uppercase tracking-widest">Action</span>
                </div>
                <div class="font-playfair text-3xl font-bold text-[#1c1c1c]">2</div>
                <div class="font-mono-tech text-[11px] uppercase tracking-wider text-[#1c1c1c]/60 mt-1">Notifications</div>
            </div>
        </section>

        <!-- PROFILE TABS SECTION -->
        <section class="bg-white border border-[#e5e4de]">
            
            <!-- Tab Buttons Container -->
            <div class="flex flex-wrap border-b border-[#e5e4de] bg-[#f7f6f2]/50 font-mono-tech text-xs uppercase tracking-wider">
                <button onclick="switchTab('personal')" id="tab-btn-personal" class="profile-tab-btn px-6 py-4 border-r border-[#e5e4de] transition-colors tab-active">
                    <i class="far fa-user mr-2"></i> Personal Info
                </button>
                <button onclick="switchTab('professional')" id="tab-btn-professional" class="profile-tab-btn px-6 py-4 border-r border-[#e5e4de] text-[#1c1c1c]/60 hover:text-[#1c1c1c] transition-colors">
                    <i class="fas fa-briefcase mr-2"></i> Professional
                </button>
                <button onclick="switchTab('academic')" id="tab-btn-academic" class="profile-tab-btn px-6 py-4 border-r border-[#e5e4de] text-[#1c1c1c]/60 hover:text-[#1c1c1c] transition-colors">
                    <i class="fas fa-graduation-cap mr-2"></i> Academic Assignments
                </button>
                <button onclick="switchTab('campus')" id="tab-btn-campus" class="profile-tab-btn px-6 py-4 border-r border-[#e5e4de] text-[#1c1c1c]/60 hover:text-[#1c1c1c] transition-colors">
                    <i class="fas fa-building mr-2"></i> Campus & Rooms
                </button>
            </div>

            <!-- TAB 1: PERSONAL INFORMATION -->
            <div id="tab-content-personal" class="tab-pane p-6 sm:p-8">
                <div class="max-w-3xl space-y-6">
                    <div class="border-b border-[#e5e4de] pb-3 flex justify-between items-center">
                        <h3 class="font-playfair text-xl font-bold text-[#1c1c1c]">Personal Details</h3>
                        <span class="font-mono-tech text-[10px] uppercase text-[#3d7068] font-bold">Faculty Record</span>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm">
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Full Name</label>
                            <p class="font-medium text-[#1c1c1c] text-base"><?= htmlspecialchars($teacher['prof_name']) ?></p>
                        </div>

                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Faculty ID (System Controlled)</label>
                            <p class="font-mono-tech font-bold text-[#3d7068]"><?= htmlspecialchars($teacher['prof_id']) ?></p>
                        </div>

                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Institutional Email</label>
                            <p class="font-medium text-[#1c1c1c]"><?= htmlspecialchars($teacher['email']) ?></p>
                        </div>

                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Contact Number</label>
                            <p class="font-medium text-[#1c1c1c]" id="displayPhone"><?= htmlspecialchars($teacher['phone']) ?></p>
                        </div>

                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Account Role</label>
                            <p class="font-medium text-[#1c1c1c]"><?= htmlspecialchars($teacher['role']) ?></p>
                        </div>

                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Account Status</label>
                            <span class="inline-block px-2.5 py-0.5 bg-emerald-100 text-emerald-800 font-mono-tech text-[11px] font-bold">
                                <?= htmlspecialchars($teacher['status']) ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB 2: PROFESSIONAL INFORMATION -->
            <div id="tab-content-professional" class="tab-pane hidden p-6 sm:p-8">
                <div class="max-w-3xl space-y-6">
                    <div class="border-b border-[#e5e4de] pb-3">
                        <h3 class="font-playfair text-xl font-bold text-[#1c1c1c]">Faculty & Departmental Profile</h3>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm">
                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Academic Rank / Position</label>
                            <p class="font-medium text-[#1c1c1c]"><?= htmlspecialchars($teacher['position']) ?></p>
                        </div>

                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Department</label>
                            <p class="font-medium text-[#1c1c1c]"><?= htmlspecialchars($teacher['department']) ?></p>
                        </div>

                        <div class="sm:col-span-2">
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">College</label>
                            <p class="font-medium text-[#1c1c1c]"><?= htmlspecialchars($teacher['college']) ?></p>
                        </div>

                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Office Location</label>
                            <p class="font-medium text-[#3d7068]"><?= htmlspecialchars($teacher['office']) ?></p>
                        </div>

                        <div>
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Consultation Hours</label>
                            <p class="font-medium text-[#1c1c1c]"><?= htmlspecialchars($teacher['consultation']) ?></p>
                        </div>

                        <div class="sm:col-span-2">
                            <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/50 mb-1">Specialization & Expertise</label>
                            <p class="font-medium text-[#1c1c1c]"><?= htmlspecialchars($teacher['specialization']) ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB 3: ACADEMIC INFORMATION -->
            <div id="tab-content-academic" class="tab-pane hidden p-6 sm:p-8">
                <div class="space-y-6">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#e5e4de] pb-3">
                        <h3 class="font-playfair text-xl font-bold text-[#1c1c1c]">Current Teaching Load</h3>
                        <span class="font-mono-tech text-xs text-[#3d7068]"><?= $semester ?> • <?= $academic_year ?></span>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse font-sans text-sm">
                            <thead>
                                <tr class="border-b border-[#1c1c1c] font-mono-tech text-[10px] uppercase tracking-wider text-[#1c1c1c]/60 bg-[#f7f6f2]">
                                    <th class="py-3 px-4">Subject Code</th>
                                    <th class="py-3 px-4">Subject Description</th>
                                    <th class="py-3 px-4">Section</th>
                                    <th class="py-3 px-4">Type</th>
                                    <th class="py-3 px-4">Assigned Room</th>
                                    <th class="py-3 px-4">Schedule</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-[#e5e4de]">
                                <tr class="hover:bg-[#f7f6f2]/60">
                                    <td class="py-3.5 px-4 font-mono-tech font-bold text-[#3d7068]">IT 212</td>
                                    <td class="py-3.5 px-4 font-medium">Web Development & Systems</td>
                                    <td class="py-3.5 px-4 font-mono-tech text-xs">BSIT 2-1</td>
                                    <td class="py-3.5 px-4"><span class="px-2 py-0.5 bg-blue-100 text-blue-800 font-mono-tech text-[10px] font-bold">LEC / LAB</span></td>
                                    <td class="py-3.5 px-4">CAST Lab 1</td>
                                    <td class="py-3.5 px-4 text-xs font-mono-tech">Mon / Wed 8:00 AM - 11:00 AM</td>
                                </tr>
                                <tr class="hover:bg-[#f7f6f2]/60">
                                    <td class="py-3.5 px-4 font-mono-tech font-bold text-[#3d7068]">IT 311</td>
                                    <td class="py-3.5 px-4 font-medium">Database Management Systems</td>
                                    <td class="py-3.5 px-4 font-mono-tech text-xs">BSIT 3-2</td>
                                    <td class="py-3.5 px-4"><span class="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-mono-tech text-[10px] font-bold">LAB</span></td>
                                    <td class="py-3.5 px-4">CAST Room 106</td>
                                    <td class="py-3.5 px-4 text-xs font-mono-tech">Tue / Thu 1:00 PM - 4:00 PM</td>
                                </tr>
                                <tr class="hover:bg-[#f7f6f2]/60">
                                    <td class="py-3.5 px-4 font-mono-tech font-bold text-[#3d7068]">CAP 401</td>
                                    <td class="py-3.5 px-4 font-medium">Capstone Project 1</td>
                                    <td class="py-3.5 px-4 font-mono-tech text-xs">BSIT 4-1</td>
                                    <td class="py-3.5 px-4"><span class="px-2 py-0.5 bg-purple-100 text-purple-800 font-mono-tech text-[10px] font-bold">LEC</span></td>
                                    <td class="py-3.5 px-4">CAST Room 204</td>
                                    <td class="py-3.5 px-4 text-xs font-mono-tech">Friday 9:00 AM - 12:00 PM</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- TAB 4: CAMPUS INFORMATION -->
            <div id="tab-content-campus" class="tab-pane hidden p-6 sm:p-8">
                <div class="space-y-6">
                    <div class="border-b border-[#e5e4de] pb-3">
                        <h3 class="font-playfair text-xl font-bold text-[#1c1c1c]">Classroom & Laboratory Mapping</h3>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="border border-[#e5e4de] p-5 space-y-3 bg-[#f7f6f2]/40">
                            <div class="flex items-center justify-between">
                                <span class="font-mono-tech font-bold text-sm text-[#3d7068]">CAST LAB 1</span>
                                <span class="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-mono-tech text-[10px] font-bold">Available for Verification</span>
                            </div>
                            <p class="text-xs text-[#1c1c1c]/70">Building Core: CAST Building — 1st Floor</p>
                            <div class="pt-2 flex items-center justify-between text-xs font-mono-tech">
                                <span>QR Code: Registered</span>
                                <a href="teacher.php#room-locator" class="text-[#3d7068] underline hover:text-[#1c1c1c]">View on Map</a>
                            </div>
                        </div>

                        <div class="border border-[#e5e4de] p-5 space-y-3 bg-[#f7f6f2]/40">
                            <div class="flex items-center justify-between">
                                <span class="font-mono-tech font-bold text-sm text-[#3d7068]">CAST ROOM 106</span>
                                <span class="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-mono-tech text-[10px] font-bold">Active Lecture Room</span>
                            </div>
                            <p class="text-xs text-[#1c1c1c]/70">Building Core: CAST Building — 1st Floor</p>
                            <div class="pt-2 flex items-center justify-between text-xs font-mono-tech">
                                <span>QR Code: Registered</span>
                                <a href="teacher.php#room-locator" class="text-[#3d7068] underline hover:text-[#1c1c1c]">View on Map</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>

    </main>

    <!-- EDIT PROFILE MODAL -->
    <div id="editProfileModal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1c1c1c]/60 backdrop-blur-sm">
        <div class="bg-white border border-[#e5e4de] w-full max-w-lg p-6 sm:p-8 shadow-2xl relative space-y-6">
            <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                <h3 class="font-playfair text-2xl font-bold text-[#1c1c1c]">Edit Profile</h3>
                <button onclick="closeEditModal()" class="text-[#1c1c1c]/40 hover:text-[#1c1c1c] text-lg cursor-pointer">&times;</button>
            </div>

            <form id="editProfileForm" onsubmit="handleProfileSave(event)" class="space-y-4 text-sm">
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/60 mb-1">Full Name</label>
                    <input type="text" id="editProfName" value="<?= htmlspecialchars($teacher['prof_name']) ?>" required class="w-full px-3 py-2 border border-[#e5e4de] bg-[#f7f6f2] text-[#1c1c1c] focus:outline-none focus:border-[#3d7068]">
                </div>

                <div>
                    <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/60 mb-1">Contact Number</label>
                    <input type="text" id="editPhone" value="<?= htmlspecialchars($teacher['phone']) ?>" required class="w-full px-3 py-2 border border-[#e5e4de] bg-[#f7f6f2] text-[#1c1c1c] focus:outline-none focus:border-[#3d7068]">
                </div>

                <div>
                    <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/40 mb-1">Institutional Email (Read-Only)</label>
                    <input type="email" value="<?= htmlspecialchars($teacher['email']) ?>" disabled class="w-full px-3 py-2 border border-[#e5e4de] bg-gray-100 text-[#1c1c1c]/50 cursor-not-allowed">
                </div>

                <div>
                    <label class="block font-mono-tech text-[10px] uppercase text-[#1c1c1c]/40 mb-1">Faculty ID (Admin Controlled)</label>
                    <input type="text" value="<?= htmlspecialchars($teacher['prof_id']) ?>" disabled class="w-full px-3 py-2 border border-[#e5e4de] bg-gray-100 text-[#1c1c1c]/50 cursor-not-allowed">
                </div>

                <div class="pt-4 flex items-center justify-end gap-3 border-t border-[#e5e4de]">
                    <button type="button" onclick="closeEditModal()" class="px-4 py-2 border border-[#e5e4de] hover:bg-[#f7f6f2] font-mono-tech text-xs uppercase cursor-pointer">Cancel</button>
                    <button type="submit" class="px-5 py-2 bg-[#1c1c1c] hover:bg-[#3d7068] text-white font-mono-tech text-xs uppercase cursor-pointer transition-colors">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <!-- FOOTER INCLUDE -->
    <?php 
    if (file_exists('../includes/footer.php')) {
        include '../includes/footer.php'; 
    } else { ?>
        <footer class="mt-16 border-t border-[#e5e4de] bg-white py-6 text-center text-xs font-mono-tech text-[#1c1c1c]/60">
            <p>&copy; <?= date('Y'); ?> Navi Track — PSU Bayambang. All rights reserved.</p>
        </footer>
    <?php } ?>

    <!-- JAVASCRIPT HANDLERS -->
    <script>
        // Tab Switcher
        function switchTab(tabKey) {
            document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.add('hidden'));
            document.querySelectorAll('.profile-tab-btn').forEach(btn => {
                btn.classList.remove('tab-active');
                btn.classList.add('text-[#1c1c1c]/60');
            });

            const activeContent = document.getElementById(`tab-content-${tabKey}`);
            const activeBtn = document.getElementById(`tab-btn-${tabKey}`);

            if (activeContent) activeContent.classList.remove('hidden');
            if (activeBtn) {
                activeBtn.classList.add('tab-active');
                activeBtn.classList.remove('text-[#1c1c1c]/60');
            }
        }

        // Notification Overlay Toggle
        function toggleNotifications() {
            const panel = document.getElementById('notifPanel');
            if (panel) panel.classList.toggle('hidden');
        }

        // Edit Profile Modal
        function openEditModal() {
            const modal = document.getElementById('editProfileModal');
            if (modal) modal.classList.remove('hidden');
        }

        function closeEditModal() {
            const modal = document.getElementById('editProfileModal');
            if (modal) modal.classList.add('hidden');
        }

        // Handle Profile Save
        function handleProfileSave(e) {
            e.preventDefault();
            const newName = document.getElementById('editProfName').value;
            const newPhone = document.getElementById('editPhone').value;

            // Immediate DOM updates
            document.getElementById('displayProfName').textContent = newName;
            document.getElementById('displayPhone').textContent = newPhone;

            closeEditModal();
        }

        // Close dropdowns/modals on outside click
        document.addEventListener('click', (e) => {
            const notifPanel = document.getElementById('notifPanel');
            const notifBtn = document.getElementById('notifBellBtn');
            if (notifPanel && notifBtn && !notifPanel.contains(e.target) && !notifBtn.contains(e.target)) {
                notifPanel.classList.add('hidden');
            }
        });
    </script>
</body>
</html>