<?php
session_start();
include "../Sys_Database/db_connection.php";
global $conn;

header('Content-Type: application/json');
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        "success" => false,
        "message" => "User not logged in."
    ]);
    exit;
}

$room_id = $_POST['room_id'] ?? '';

if (empty($room_id)) {
    echo json_encode([
        "success" => false,
        "message" => "No room ID received."
    ]);
    exit;
}
$user_id = $_SESSION['user_id'];

$sqlTeacher = "SELECT prof_id
    FROM teachers
    WHERE user_id = ?
    ";

$stmt = mysqli_prepare($conn, $sqlTeacher);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$resultTeacher = mysqli_stmt_get_result($stmt);
$teacher = mysqli_fetch_assoc($resultTeacher);

if (!$teacher) {
    echo json_encode([
        "success" => false,
        "message" => "Teacher not found."
    ]);
    exit;
}

$prof_id = $teacher['prof_id'];

date_default_timezone_set('Asia/Manila');

$today = "MONDAY";
$currentTime = "08:00:00";

$sqlSchedule = "SELECT *FROM room_sched
    WHERE prof_id = ?
    AND room_id = ?
    AND day_of_week = ?
    AND ? BETWEEN start_time AND end_time
    LIMIT 1
    ";

$stmt = mysqli_prepare($conn, $sqlSchedule);

mysqli_stmt_bind_param(
    $stmt,
    "iiss",
    $prof_id,
    $room_id,
    $today,
    $currentTime
);

mysqli_stmt_execute($stmt);

$resultSchedule = mysqli_stmt_get_result($stmt);
$schedule = mysqli_fetch_assoc($resultSchedule);

if (!$schedule) {
    echo json_encode([
        "success" => false,
        "message" => "No active schedule found for this room."
    ]);
    exit;
}


$sched_id = $schedule['sched_id'];

$sqlCheckLog = "SELECT *
    FROM room_logs
    WHERE sched_id = ?
    AND prof_id = ?
    AND room_id = ?
    AND actual_time_out IS NULL
    ORDER BY log_id DESC
    LIMIT 1";

$stmt = mysqli_prepare($conn, $sqlCheckLog);
mysqli_stmt_bind_param(
    $stmt,
    "iii",
    $sched_id,
    $prof_id,
    $room_id
);

mysqli_stmt_execute($stmt);

$resultLog = mysqli_stmt_get_result($stmt);
$log = mysqli_fetch_assoc($resultLog);

if (!$log) {

    $sqlInsert = " INSERT INTO room_logs (
        sched_id,
        prof_id,
        room_id,
        actual_time_in
    )
    VALUES (?, ?, ?, NOW())
    ";

    $stmt = mysqli_prepare($conn, $sqlInsert);
    
    mysqli_stmt_bind_param(
        $stmt, 
        "iii", 
        $sched_id, 
        $prof_id, 
        $room_id
    );

    mysqli_stmt_execute($stmt);

    echo json_encode([
        "success" => true,
        "message" => "Time In recorded.",
        "action" => "TIME_IN"
    ]);

    exit;

} else {

    $log_id = $log['log_id'];

    $sqlUpdate = "
    UPDATE room_logs
    SET actual_time_out = NOW()
    WHERE log_id = ?
    ";

    $stmt = mysqli_prepare($conn, $sqlUpdate);
    mysqli_stmt_bind_param($stmt, "i", $log_id);
    mysqli_stmt_execute($stmt);

    echo json_encode([
        "success" => true,
        "message" => "Time Out recorded.",
        "action" => "TIME_OUT"
    ]);

    exit;
}
?>