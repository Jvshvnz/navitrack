<?php
require_once "../Sys_Database/db_connection.php";
global $conn;

$user_id = $_POST['user_id'];
$username = $_POST['username'];
$email = $_POST['email'];
$role_id = $_POST['role_id'];
$is_active = $_POST['is_active'];

$sql = "
UPDATE users
SET
    username = ?,
    email = ?,
    role_id = ?,
    is_active = ?
WHERE user_id = ?
";

$stmt = mysqli_prepare($conn, $sql);

mysqli_stmt_bind_param(
    $stmt,
    "ssiii",
    $username,
    $email,
    $role_id,
    $is_active,
    $user_id
);

$success = mysqli_stmt_execute($stmt);

echo json_encode([
    "success" => $success
]);