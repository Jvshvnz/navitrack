<?php
require_once __DIR__ . '/../Sys_Database/db_connection.php';
$room_name = trim((string)($_POST['room_name'] ?? ''));
$building_id = filter_input(INPUT_POST, 'building_id', FILTER_VALIDATE_INT);
if ($room_name === '' || $building_id === false || $building_id === null) { http_response_code(400); exit('Room name and building are required.'); }
$stmt = $conn->prepare('INSERT INTO room_list (room_name, building_id) VALUES (?, ?)');
$stmt->bind_param('si', $room_name, $building_id);
$stmt->execute();
header('Location: admin.php'); exit;
?>
