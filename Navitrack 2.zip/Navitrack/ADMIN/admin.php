<?php
// ADMIN/admin.php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../Sys_Database/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../LOGIN/login.php");
    exit();
}

$username = $_SESSION['username'] ?? 'Administrator';

// Fetch system stats safely for counters
$total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'] ?? 0;
$total_students = $conn->query("SELECT COUNT(*) as count FROM users WHERE role_id = 3")->fetch_assoc()['count'] ?? 0;
$total_faculty = $conn->query("SELECT COUNT(*) as count FROM users WHERE role_id = 2")->fetch_assoc()['count'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navi Track • System Administration</title>
    
    <!-- Editorial Typography Imports -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Space+Grotesk:wght@300..700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="adminstyle.css">
    
    <style>
        /* Editorial Design System Custom CSS */
        :root {
            --bg-organic: #f7f6f2;
            --fg-dark: #1c1c1c;
            --accent-green: #3d7068;
            --border-line: #e5e4de;
            --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
        }

        body {
            background-color: var(--bg-organic);
            color: var(--fg-dark);
            font-family: 'Space Grotesk', sans-serif;
            transition: all 700ms var(--ease-editorial);
        }

        .font-playfair { font-family: 'Playfair Display', Georgia, serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .font-grotesk { font-family: 'Space Grotesk', sans-serif; }

        /* 40px Grid Background with Radial Mask */
        .editorial-grid-bg {
            background-size: 40px 40px;
            background-image: 
                linear-gradient(to right, rgba(229, 228, 222, 0.6) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(229, 228, 222, 0.6) 1px, transparent 1px);
            mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
            -webkit-mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
        }

        /* 1px Border Enforcement & Radius Cap */
        .border-editorial {
            border: 1px solid var(--border-line);
            border-radius: 2px !important;
        }

        .btn-editorial {
            background-color: var(--accent-green);
            color: #ffffff;
            transition: letter-spacing 400ms var(--ease-editorial);
            letter-spacing: 0.25em;
        }
        .btn-editorial:hover {
            letter-spacing: 0.35em;
        }
    </style>
</head>
<body class="relative min-h-screen overflow-x-hidden antialiased">

    <!-- Fixed 4-Column Vertical Guide Lines -->
    <div class="fixed inset-0 pointer-events-none z-0 flex justify-between max-w-7xl mx-auto px-6">
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
    </div>

    <!-- Fixed Background Grid -->
    <div class="fixed inset-0 pointer-events-none z-0 editorial-grid-bg"></div>

    <!-- Header Navigation -->
    <header class="fixed top-0 left-0 right-0 z-50 bg-[#f7f6f2]/80 backdrop-blur-md border-b border-[#e5e4de]">
        <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            
            <div class="flex items-center gap-3">
                <span class="w-6 h-[1px] bg-[#1c1c1c]"></span>
                <span class="font-playfair text-xl tracking-tight uppercase font-light text-[#1c1c1c]">Navi Track</span>
                <span class="w-8 h-[1px] bg-[#1c1c1c]"></span>
            </div>

            <div class="flex items-center gap-6 font-mono-tech text-[10px] uppercase tracking-[0.3em]">
                <span class="hidden md:inline-block text-[#3d7068]">
                    [ ADMIN: <?php echo htmlspecialchars($username); ?> ]
                </span>
                <a href="../LOGIN/login.php" class="text-red-700 hover:opacity-70 transition-opacity" title="Sign Out">
                    [ Exit System ]
                </a>
            </div>
        </div>
    </header>

    <!-- Main Content Container -->
    <main class="relative z-10 max-w-7xl mx-auto px-6 pt-32 pb-24 space-y-12">

        <!-- Top Overview & Metrics Bar -->
        <section class="border-editorial p-10 bg-white grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div class="lg:col-span-7 space-y-3">
                <div class="inline-flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-[#3d7068]"></span>
                    <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">
                        System Administration Panel
                    </span>
                </div>
                <h1 class="font-playfair text-4xl uppercase font-light text-[#1c1c1c]">
                    User <span class="italic text-[#B4B4B4]">Database</span> & Roles
                </h1>
                <p class="font-grotesk text-xs text-[#1c1c1c]/70 max-w-md">
                    Manage system accounts, user access roles, and system security privileges across departments.
                </p>
            </div>

            <!-- Statistics Grid Cells -->
            <div class="lg:col-span-5 grid grid-cols-3 border-editorial bg-[#f7f6f2]">
                <div class="p-4 border-r border-[#e5e4de] text-center space-y-1">
                    <span class="font-playfair text-2xl font-light text-[#1c1c1c] block"><?php echo $total_users; ?></span>
                    <span class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] block">Users</span>
                </div>
                <div class="p-4 border-r border-[#e5e4de] text-center space-y-1">
                    <span class="font-playfair text-2xl font-light text-[#1c1c1c] block"><?php echo $total_students; ?></span>
                    <span class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] block">Students</span>
                </div>
                <div class="p-4 text-center space-y-1">
                    <span class="font-playfair text-2xl font-light text-[#1c1c1c] block"><?php echo $total_faculty; ?></span>
                    <span class="font-mono-tech text-[9px] uppercase tracking-wider text-[#3d7068] block">Faculty</span>
                </div>
            </div>
        </section>

        <!-- User Accounts Table -->
        <section class="border-editorial bg-white p-8 space-y-6">
            <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                <div class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">
                    [ Account Index Table ]
                </div>
                <div class="font-mono-tech text-[10px] text-[#1c1c1c]/50">
                    DATABASE SYNCED
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs font-grotesk">
                    <thead class="font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] border-b border-[#e5e4de] bg-[#f7f6f2]">
                        <tr>
                            <th class="p-4">ID</th>
                            <th class="p-4">Username</th>
                            <th class="p-4">Email</th>
                            <th class="p-4">Role</th>
                            <th class="p-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-[#e5e4de]">
                        <?php
                        $user_sql = "SELECT user_id, role_id, username, email FROM users ORDER BY user_id DESC";
                        $user_res = $conn->query($user_sql);
                        if ($user_res && $user_res->num_rows > 0):
                            while ($row = $user_res->fetch_assoc()):
                                $role_name = ($row['role_id'] == 1) ? 'ADMIN' : (($row['role_id'] == 2) ? 'FACULTY' : 'STUDENT');
                        ?>
                            <tr class="hover:bg-[#f7f6f2] transition-colors">
                                <td class="p-4 font-mono-tech text-[11px] text-[#1c1c1c]/60">#<?php echo htmlspecialchars($row['user_id']); ?></td>
                                <td class="p-4 font-semibold text-[#1c1c1c]"><?php echo htmlspecialchars($row['username']); ?></td>
                                <td class="p-4 text-[#1c1c1c]/70 font-mono-tech text-[11px]"><?php echo htmlspecialchars($row['email']); ?></td>
                                <td class="p-4">
                                    <span class="px-2.5 py-1 font-mono-tech text-[9px] uppercase border-editorial bg-[#f7f6f2] text-[#3d7068]">
                                        <?php echo $role_name; ?>
                                    </span>
                                </td>
                                <td class="p-4 text-right">
                                    <button class="px-3 py-1.5 border-editorial font-mono-tech text-[9px] uppercase tracking-wider hover:bg-[#3d7068] hover:text-white transition-colors">
                                        Edit
                                    </button>
                                </td>
                            </tr>
                        <?php 
                            endwhile;
                        else:
                        ?>
                            <tr>
                                <td colspan="5" class="p-8 text-center font-mono-tech text-xs text-[#1c1c1c]/50 uppercase">
                                    No records located in user table.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

    </main>

    <!-- Footer -->
    <footer class="border-t border-[#e5e4de] bg-[#f7f6f2] relative z-10 py-8">
        <div class="max-w-7xl mx-auto px-6 flex justify-between items-center font-mono-tech text-[10px] text-[#1c1c1c]/60 uppercase tracking-widest">
            <div>© 2026 Navi Track System</div>
            <div>Pangasinan State University</div>
        </div>
    </footer>

    <script src="../assets/js/adminmain.js"></script>
    <script src="../assets/js/edit_user.js"></script>
</body>
</html>