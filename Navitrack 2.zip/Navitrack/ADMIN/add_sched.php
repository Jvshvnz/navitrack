<?php
require_once __DIR__ . '/../Sys_Database/db_connection.php';
$room_id = filter_input(INPUT_POST, 'room_id', FILTER_VALIDATE_INT);
$sub_id = trim((string)($_POST['subject_id'] ?? ''));
$prof_id = filter_input(INPUT_POST, 'prof_id', FILTER_VALIDATE_INT);
$block_id = trim((string)($_POST['block_id'] ?? ''));
$day_of_week = strtoupper(trim((string)($_POST['day_of_week'] ?? '')));
$start_time = trim((string)($_POST['time_in'] ?? ''));
$end_time = trim((string)($_POST['time_out'] ?? ''));
if ($room_id === false || $room_id === null || $sub_id === '' || $prof_id === false || $prof_id === null || $block_id === '' || $day_of_week === '' || $start_time === '' || $end_time === '') { http_response_code(400); exit('All schedule fields are required.'); }
$stmt = $conn->prepare('INSERT INTO room_sched (room_id, sub_id, block_id, prof_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?, ?)');
$stmt->bind_param('ississs', $room_id, $sub_id, $block_id, $prof_id, $day_of_week, $start_time, $end_time);
$stmt->execute();
header('Location: admin.php'); exit;
?>
