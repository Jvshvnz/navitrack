<?php
require_once "../Sys_Database/db_connection.php";
global $conn;

$user_id = $_POST['user_id'];

// Get current status first
$get = mysqli_prepare($conn, "SELECT is_active FROM users WHERE user_id = ?");
mysqli_stmt_bind_param($get, "i", $user_id);
mysqli_stmt_execute($get);

$result = mysqli_stmt_get_result($get);
$row = mysqli_fetch_assoc($result);

$current = $row['is_active'];

// toggle it
$new_status = $current == 1 ? 0 : 1;

$sql = "UPDATE users SET is_active = ? WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $sql);

mysqli_stmt_bind_param($stmt, "ii", $new_status, $user_id);

$success = mysqli_stmt_execute($stmt);

echo json_encode([
    "success" => $success,
    "new_status" => $new_status
]);