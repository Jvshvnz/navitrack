<?php
session_start();

if (!isset($_SESSION['pending_user'])) {
    header("Location: signup.html");
    exit();
}

$pending = $_SESSION['pending_user'];
$demo_otp = $pending['otp'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navi Track • Verify Email</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="signup.css">
</head>
<body class="hero-bg min-h-screen flex items-center justify-center overflow-hidden relative text-white">

    <div class="absolute inset-0 pointer-events-none overflow-hidden">
        <div class="absolute top-[-15%] left-[-10%] w-[500px] h-[500px] bg-cyan-400 rounded-full mix-blend-screen filter blur-[120px] opacity-20 blob"></div>
        <div class="absolute bottom-[-20%] right-[-15%] w-[600px] h-[600px] bg-blue-500 rounded-full mix-blend-screen filter blur-[130px] opacity-20 blob"></div>
    </div>

    <div class="absolute inset-0 bg-[radial-gradient(rgba(255,255,255,0.07)_1px,transparent_1px)] [background-size:60px_60px] opacity-30"></div>

    <div class="max-w-[440px] w-full mx-auto px-6 relative z-10">
        <div class="glass-card rounded-3xl shadow-2xl p-8 glow-cyan text-center">
            
            <div class="w-16 h-16 rounded-2xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center mx-auto mb-6 text-cyan-400 text-2xl shadow-lg">
                <i class="fa-solid fa-shield-halved"></i>
            </div>

            <h1 class="heading-font text-3xl font-semibold tracking-tighter mb-2">Security Verification</h1>
            <p class="text-slate-400 text-sm mb-6">
                Enter the 6-digit OTP code sent to <br>
                <span class="text-cyan-300 font-medium"><?php echo htmlspecialchars($pending['email']); ?></span>
            </p>

            <form action="otp_process.php" method="POST" id="otpForm">
                <input type="hidden" name="full_otp" id="full_otp">

                <div class="flex justify-between gap-2 mb-8">
                    <input type="text" maxlength="1" class="otp-input w-12 h-14 rounded-xl text-center text-xl font-bold bg-white/10 border border-white/20 text-white focus:outline-none focus:border-cyan-400 transition-all" required autofocus>
                    <input type="text" maxlength="1" class="otp-input w-12 h-14 rounded-xl text-center text-xl font-bold bg-white/10 border border-white/20 text-white focus:outline-none focus:border-cyan-400 transition-all" required>
                    <input type="text" maxlength="1" class="otp-input w-12 h-14 rounded-xl text-center text-xl font-bold bg-white/10 border border-white/20 text-white focus:outline-none focus:border-cyan-400 transition-all" required>
                    <input type="text" maxlength="1" class="otp-input w-12 h-14 rounded-xl text-center text-xl font-bold bg-white/10 border border-white/20 text-white focus:outline-none focus:border-cyan-400 transition-all" required>
                    <input type="text" maxlength="1" class="otp-input w-12 h-14 rounded-xl text-center text-xl font-bold bg-white/10 border border-white/20 text-white focus:outline-none focus:border-cyan-400 transition-all" required>
                    <input type="text" maxlength="1" class="otp-input w-12 h-14 rounded-xl text-center text-xl font-bold bg-white/10 border border-white/20 text-white focus:outline-none focus:border-cyan-400 transition-all" required>
                </div>

                <button type="submit" name="verify_otp_btn"
                        class="w-full py-4 bg-gradient-to-r from-[#3B82F6] to-[#22D3EE] hover:brightness-110 active:scale-[0.985] transition-all font-semibold text-base rounded-2xl shadow-xl shadow-cyan-500/30 flex items-center justify-center gap-x-2">
                    <span>Verify & Complete Registration</span>
                    <i class="fa-solid fa-check"></i>
                </button>
            </form>

            <div class="mt-6 text-xs text-slate-500">
                Didn't receive a code? <a href="signup.html" class="text-cyan-400 hover:underline">Start Over</a>
            </div>
        </div>
    </div>

    <script>
        const inputs = document.querySelectorAll('.otp-input');
        const hiddenInput = document.getElementById('full_otp');

        inputs.forEach((input, index) => {
            input.addEventListener('keyup', (e) => {
                if (e.key >= 0 && e.key <= 9) {
                    if (index < inputs.length - 1) inputs[index + 1].focus();
                } else if (e.key === 'Backspace') {
                    if (index > 0) inputs[index - 1].focus();
                }
                combineOtp();
            });
        });

        function combineOtp() {
            let code = "";
            inputs.forEach(input => code += input.value);
            hiddenInput.value = code;
        }

        window.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
                alert("🔑 [DEMO OTP CODE]: <?php echo $demo_otp; ?>\n\n(Use this code to test verification!)");
            }, 300);
        });
    </script>
</body>
</html>