<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../Sys_Database/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_btn'])) {

    $role_id  = intval($_POST['role_id']);
    $password = $_POST['password'];

    if ($role_id === 3) { 
        $full_name = trim($_POST['student_fullname']);
        $username  = trim($_POST['student_username']);
        $school_id = trim($_POST['student_number']);
        $year      = trim($_POST['student_year']);
        $section   = trim($_POST['student_section']);
        $course    = trim($_POST['student_course']);
        $email     = trim($_POST['student_email']);
    } else { 
        $full_name  = trim($_POST['teacher_name']);
        $username   = trim($_POST['teacher_username']);
        $school_id  = trim($_POST['teacher_emp_no']);
        $department = trim($_POST['teacher_dept']);
        $email      = trim($_POST['teacher_email']);
    }

    $check_sql = "SELECT user_id FROM users WHERE username = ? OR email = ?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Username or Email is already registered!'); window.location.href='signup.html';</script>";
        exit();
    }
    $stmt->close();

    $generated_otp = rand(100000, 999999);

    $_SESSION['pending_user'] = [
        'role_id'   => $role_id,
        'full_name' => $full_name,
        'username'  => $username,
        'school_id' => $school_id,
        'email'     => $email,
        'password'  => password_hash($password, PASSWORD_DEFAULT),
        'otp'       => $generated_otp,
        'expire'    => time() + (5 * 60)
    ];

    if (file_exists(__DIR__ . '/otp_verify.php')) {
        header("Location: otp_verify.php");
    } else {
        header("Location: login.php");
    }
    exit();

} else {
    header("Location: signup.html");
    exit();
}
?>