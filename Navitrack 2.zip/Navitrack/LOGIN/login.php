<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once __DIR__ . '/../Sys_Database/db_connection.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_input = trim($_POST['username'] ?? $_POST['email'] ?? '');
    $password   = $_POST['password'] ?? '';

    if (!empty($user_input) && !empty($password)) {
        $stmt = $conn->prepare("SELECT user_id, username, password, role_id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $user_input, $user_input);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $row = $result->fetch_assoc()) {
            $db_pass = $row['password'];

            // VERIFY PASSWORD
            if (password_verify($password, $db_pass) || $password === $db_pass) {
                
                // SET SESSION DATA
                $_SESSION['user_id']  = $row['user_id'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['role_id']  = $row['role_id'];

                // ROLE-BASED ROUTING LOGIC MATCHED TO DATABASE
                switch ((int)$row['role_id']) {
                    case 1:
                        // Chairperson
                        header("Location: ../CHAIRPERSON/chair.php");
                        exit();

                    case 2:
                        // Teachers
                        header("Location: ../User/teacher.php");
                        exit();

                    case 3:
                        // Students
                        header("Location: ../Stud/student.php");
                        exit();

                    case 4:
                        // SuperAdmin
                        header("Location: ../SUPAD/superAdmin.php");
                        exit();

                    default:
                        // Fallback for unrecognized roles
                        header("Location: ../LOGIN/login.php?error=invalid_role");
                        exit();
                }

            } else {
                $error = "Invalid password. Please try again.";
            }
        } else {
            $error = "Account not found. Please check your credentials.";
        }
        $stmt->close();
    } else {
        $error = "Please fill in both username/email and password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navi Track • System Authentication</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Space+Grotesk:wght@300..700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="login.css">
    
    <style>
        :root {
            --bg-organic: #f7f6f2;
            --fg-dark: #1c1c1c;
            --accent-green: #3d7068;
            --border-line: #e5e4de;
            --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
        }

        body {
            background-color: var(--bg-organic);
            color: var(--fg-dark);
            font-family: 'Space Grotesk', sans-serif;
        }

        .font-playfair { font-family: 'Playfair Display', Georgia, serif; }
        .font-mono-tech { font-family: 'Space Mono', monospace; }
        .font-grotesk { font-family: 'Space Grotesk', sans-serif; }

        .editorial-grid-bg {
            background-size: 40px 40px;
            background-image: 
                linear-gradient(to right, rgba(229, 228, 222, 0.6) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(229, 228, 222, 0.6) 1px, transparent 1px);
            mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
            -webkit-mask-image: radial-gradient(circle at center, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0) 80%);
        }

        .border-editorial {
            border: 1px solid var(--border-line);
            border-radius: 2px !important;
        }

        .btn-editorial {
            background-color: var(--accent-green);
            color: #ffffff;
            transition: letter-spacing 400ms var(--ease-editorial);
            letter-spacing: 0.25em;
        }
        .btn-editorial:hover {
            letter-spacing: 0.4em;
        }
    </style>
</head>
<body class="relative min-h-screen flex items-center justify-center overflow-x-hidden antialiased py-12">

    <!-- TOP RIGHT RETURN TO HOMESCREEN LINK -->
<a href="../index.php" class="fixed top-6 right-8 z-50 inline-flex items-center gap-2 px-4 py-2 border-editorial bg-white/80 backdrop-blur-md font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] hover:text-[#3d7068] hover:border-[#3d7068] transition-all shadow-sm group">
    <i class="fa-solid fa-arrow-left text-xs transition-transform group-hover:-translate-x-1 text-[#3d7068]"></i>
    <span>Return Home</span>
</a>
    <div class="fixed inset-0 pointer-events-none z-0 flex justify-between max-w-7xl mx-auto px-6">
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
        <div class="w-px h-full bg-[#e5e4de]"></div>
    </div>

    <div class="fixed inset-0 pointer-events-none z-0 editorial-grid-bg"></div>

    <div class="max-w-[460px] w-full mx-auto px-6 relative z-10">
        
        <div class="flex justify-center mb-6">
            <div class="inline-flex items-center gap-2 px-4 py-1.5 border-editorial bg-[#f7f6f2]">
                <span class="w-2 h-2 rounded-full bg-[#3d7068] animate-pulse"></span>
                <span class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068]">
                    Authentication Portal
                </span>
            </div>
        </div>

        <div class="border-editorial bg-white p-8 md:p-10 space-y-8">
            
            <!-- LOGIN HEADER SECTION -->
            <div class="text-center space-y-3">
                <p class="font-mono-tech text-[10px] uppercase tracking-[0.25em] text-[#3d7068] flex items-center justify-center gap-2">
                    <span>—</span> WELCOME BACK TO <span>—</span>
                </p>

                <div class="flex items-center justify-center gap-3">
                    <div style="height: 40px; width: 40px; flex-shrink: 0;" class="overflow-hidden flex items-center justify-center">
                        <img src="../assets/images/NaviTrack_Logo.png" 
                             alt="NaviTrack Logo" 
                             style="max-height: 100%; max-width: 100%; object-fit: contain;">
                    </div>
                    <h1 class="font-serif font-black text-2xl sm:text-3xl tracking-[0.15em] text-[#1c1c1c] uppercase leading-none whitespace-nowrap" 
                        style="font-family: 'Cinzel', 'Playfair Display', Georgia, serif !important;">
                        NAVI TRACK
                    </h1>
                </div>

                <p class="font-serif text-sm text-[#1c1c1c]/70 tracking-wide">
                    Enter credentials to login your account
                </p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="p-4 border-editorial bg-red-50 text-red-800 text-xs font-mono-tech flex items-center gap-3">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <form action="login.php" method="POST" class="space-y-6">
                <div>
                    <label class="block font-mono-tech text-[10px] uppercase tracking-[0.2em] text-[#1c1c1c] mb-2">
                        Username or Email
                    </label>
                    <input type="text" name="username" required placeholder="IDENTIFIER"
                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                           class="w-full pb-3 bg-transparent border-b border-[#e5e4de] font-mono-tech text-xs text-[#1c1c1c] placeholder-[#1c1c1c]/30 focus:outline-none focus:border-[#3d7068] transition-colors">
                </div>

                <div class="space-y-1.5">
                    <label for="loginPassword" class="block font-mono-tech text-[10px] uppercase tracking-wider text-[#1c1c1c]/60">Password</label>
                    <div class="relative flex items-center">
                        <input type="password" id="loginPassword" name="password" placeholder="••••••••" required class="w-full px-3.5 py-2.5 pr-10 bg-white border border-[#e5e4de] text-sm text-[#1c1c1c]">
                        <button type="button" data-toggle-password="loginPassword" class="absolute right-3 text-[#1c1c1c]/40 hover:text-[#3d7068] focus:outline-none cursor-pointer">
                            <i class="fas fa-eye text-sm"></i>
                        </button>
                    </div>
                </div>

                <div class="flex items-center justify-between text-xs font-mono-tech pt-1">
                    <label class="flex items-center gap-2 cursor-pointer select-none text-[#1c1c1c]/70 hover:text-[#1c1c1c]">
                        <input type="checkbox" name="remember" class="w-3.5 h-3.5 border-[#e5e4de] accent-[#3d7068]">
                        <span>Remember me</span>
                    </label>
                    <a href="#forgot-password" onclick="alert('Please contact the CAST IT department or Administrator to reset your password.');" class="text-[#3d7068] hover:underline">
                        Forgot password?
                    </a>
                </div>

                <button type="submit" name="login_btn"
                        class="w-full py-4 btn-editorial font-mono-tech text-[10px] uppercase border-editorial">
                    Sign In
                </button>
            </form>

            <div class="pt-6 border-t border-[#e5e4de] text-center font-mono-tech text-[10px] text-[#1c1c1c]/60 uppercase tracking-wider">
                Unregistered User? 
                <a href="signup.html" class="text-[#3d7068] hover:underline font-bold ml-1">Create Account</a>
            </div>
        </div>
    </div>

    <script src="../assets/js/login.js"></script>
</body>
</html>