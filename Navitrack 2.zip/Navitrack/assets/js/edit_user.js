document.addEventListener("DOMContentLoaded", () => {

    const modal = document.getElementById("modal-edit-user");

    // EDIT BUTTONS
    document.querySelectorAll(".edit-user-btn").forEach(button => {

        button.addEventListener("click", () => {

            document.getElementById("edit-user-id").value =
                button.dataset.id;

            document.getElementById("edit-user-name").value =
                button.dataset.name;

            document.getElementById("edit-user-role").value =
                button.dataset.role;

            document.getElementById("edit-user-email").value =
                button.dataset.email;

            document.getElementById("edit-user-status").value =
                button.dataset.status;

            const toggleBtn = document.getElementById("toggle-user-btn");

            if (button.dataset.status == "1") {
                toggleBtn.textContent = "Deactivate User";
            } else {
                toggleBtn.textContent = "Reactivate User";
            }

            modal.classList.add("open");

        });

    });

    // CANCEL BUTTON
    const cancelBtn = document.querySelector(".modal-btn-cancel");

    if (cancelBtn) {
        cancelBtn.addEventListener("click", () => {

            console.log("CANCEL CLICKED");

            modal.classList.remove("open");
        });
    }

    // CLOSE (X) BUTTON
    const closeBtn = document.querySelector(".modal-close-btn");

    if (closeBtn) {
        closeBtn.addEventListener("click", () => {

            console.log("X CLICKED");

            modal.classList.remove("open");
        });
    }

    // SAVE BUTTON
    const saveBtn = document.getElementById("save-user-btn");

    if (saveBtn) {
        saveBtn.addEventListener("click", async () => {

            const formData = new FormData();

            formData.append(
                "user_id",
                document.getElementById("edit-user-id").value
            );

            formData.append(
                "username",
                document.getElementById("edit-user-name").value
            );

            formData.append(
                "email",
                document.getElementById("edit-user-email").value
            );

            formData.append(
                "role_id",
                document.getElementById("edit-user-role").value
            );

            formData.append(
                "is_active",
                document.getElementById("edit-user-status").value
            );

            const response = await fetch("update_user.php", {
                method: "POST",
                body: formData
            });

            const result = await response.json();;
            console.log(result);
            if(result.success){

                alert("User updated successfully");

                location.reload();

            }else{

                alert("Update failed");

            }

        });
    }

    const toggleBtn = document.getElementById("toggle-user-btn");

    toggleBtn.addEventListener("click", async () => {

    const userId = document.getElementById("edit-user-id").value;

    const confirmAction = confirm("Are you sure you want to toggle this user's status?");

    if (!confirmAction) return;

    const formData = new FormData();
    formData.append("user_id", userId);

    const response = await fetch("toggle_user.php", {
        method: "POST",
        body: formData
    });

    const result = await response.json();

    if(result.success){

        alert(
            result.new_status == 1
            ? "User reactivated"
            : "User deactivated"
        );

        location.reload();

    } else {

        alert("Action failed");

    }
    });

});