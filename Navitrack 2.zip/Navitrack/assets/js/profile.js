(function () {
    'use strict';

    console.log(window.currentUser);
    let FACULTY_PROFILE = {};
    const overlay  = document.getElementById('profile-overlay');
    const panel    = document.getElementById('profile-panel');

    function openProfileOverlay() {
        if (!overlay) return;
        renderProfile();
        overlay.classList.add('open');
        document.body.style.overflow = 'hidden';
       document.body.classList.add('profile-open');

        if (panel) {
            const firstFocusable = panel.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
            if (firstFocusable) firstFocusable.focus();
        }
    }

    function closeProfileOverlay() {
        if (!overlay) return;
        overlay.classList.remove('open');
        document.body.style.overflow = '';
        document.body.classList.remove('profile-open');
    }
    function handleOverlayClick(event) {
        if (event.target === overlay) {
            closeProfileOverlay();
        }
    }

    /* Close on Escape key */
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && overlay && overlay.classList.contains('open')) {
            closeProfileOverlay();
        }
    });

    async function loadProfile() {

    try {

        const response = await fetch("get_profile.php");

        const data = await response.json();

        console.log("Profile Data:", data);

        if (!data) return;
        const name = data.prof_name || "Unknown User";

        FACULTY_PROFILE = {

        initials: name
            .split(" ")
            .map(w => w[0])
            .join("")
            .substring(0, 2)
            .toUpperCase(),

        fullName: name,

        email: data.email || "No email found",

        employeeId: window.currentUser?.profId || "-",

        facultyId: window.currentUser?.profId || "-",

        department: "BSIT",

        college: "College of Computer and Arts and Sciences Technology",

        position: "Teacher",

        role: "Faculty",

        campus: "Pangasinan State University",

        academicYear: "2025-2026",

        status: "active",

        currentClass: data.currentClass || {
            sub_id: "-",
            room_id: "-",
            day_of_week: "-",
            start_time: "-",
            end_time: "-"
        }
    };

    renderProfile();

    } catch (err) {

        console.error("Profile Load Error:", err);

    }
    }
    
    function renderProfile() {
        const p = FACULTY_PROFILE;

        const navAvatar = document.querySelector('.profile-nav-avatar');
        const navName   = document.querySelector('.profile-nav-name');
        const navRole   = document.querySelector('.profile-nav-role');
        if (navAvatar) navAvatar.textContent = p.initials;
        if (navName)   navName.textContent   = p.fullName;
        if (navRole)   navRole.textContent   = p.position;

        const avatar = document.querySelector('.profile-avatar');
        if (avatar) avatar.textContent = p.initials;

        setText('.profile-full-name',       p.fullName);
        setText('.profile-position-title',  `${p.role}\u00a0·\u00a0${p.position}`);
        setText('.profile-department',       `${p.department}\n${p.college}`);
        setText('.profile-id-value',         p.facultyId);

        const statusDot = document.querySelector('.profile-avatar-status');
        if (statusDot) {
            statusDot.style.background = p.status === 'active' ? '#22c55e' : '#6b7280';
            statusDot.title = p.status === 'active' ? 'Online' : 'Offline';
        }

        const cards = document.querySelectorAll('.profile-detail-card');
        const cardData = [
            { icon: 'fa-envelope',      label: 'Email Address',   value: p.email,        mono: false },
            { icon: 'fa-phone-alt',     label: 'Contact Number',  value: p.contact,      mono: false },
            { icon: 'fa-id-badge',      label: 'Employee ID',     value: p.employeeId,   mono: true  },
            { icon: 'fa-building',      label: 'Department',      value: 'BSIT',   mono: false },
            { icon: 'fa-award',         label: 'Position / Rank', value: p.position,     mono: false },
            { icon: 'fa-briefcase',     label: 'Role',            value: p.role,         mono: false },
            { icon: 'fa-university',    label: 'Campus',          value: p.campus,       mono: false },
            { icon: 'fa-calendar-alt',  label: 'Academic Year',   value: p.academicYear, mono: false },
        ];

        cards.forEach(function (card, i) {
            if (!cardData[i]) return;
            const d = cardData[i];
            const iconEl  = card.querySelector('.pdc-icon-wrap i');
            const labelEl = card.querySelector('.pdc-label');
            const valueEl = card.querySelector('.pdc-value');
            if (iconEl)  { iconEl.className = `fas ${d.icon}`; }
            if (labelEl) labelEl.textContent = d.label;
            if (valueEl) {
                valueEl.textContent = d.value;
                valueEl.className = d.mono ? 'pdc-value mono' : 'pdc-value';
            }
        });

        const c = p.currentClass ?? {
            sub_id: "-",
            room_id: "-",
            day_of_week: "-",
            start_time: "-",
            end_time: "-"
        };

        const pssValue = document.querySelector('.pss-value');

        if (pssValue) {
            pssValue.innerHTML =
            `${c.sub_id ?? "-"} — ${c.room_id ?? "-"} · ${c.day_of_week ?? "-"} ${c.start_time ?? ""}-${c.end_time ?? ""}`;
        }
    }

    function setText(selector, text) {
        const el = document.querySelector(selector);
        if (el) el.textContent = text;
    }


    function handleLogout() {
        if (!confirm('Are you sure you want to log out?')) return;
        /* Example: window.location.href = '/logout.php'; */
        alert('Logged out successfully.\n(Connect this to your logout.php endpoint.)');
        closeProfileOverlay();
    }

    function handleEditProfile() {
        alert('Edit Profile panel coming soon.\n(Connect this to your admin/faculty edit form.)');
    }

    function attachListeners() {
        /* Logout button */
        const logoutBtn = document.querySelector('.profile-btn-logout');
        if (logoutBtn) logoutBtn.addEventListener('click', handleLogout);

        const editBtn = document.querySelector('.profile-btn-edit');
        if (editBtn) editBtn.addEventListener('click', handleEditProfile);
    }

    window.openProfileOverlay  = openProfileOverlay;
    window.closeProfileOverlay = closeProfileOverlay;
    window.handleOverlayClick  = handleOverlayClick;
    if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initProfile);
    } else {
    initProfile();
    }

    function initProfile() {
    loadProfile();     
    attachListeners();
    }

})();