const loadingSteps = [
    { pct: 18,  label: 'Initializing Portal' },
    { pct: 38,  label: 'Loading Modules' },
    { pct: 58,  label: 'Fetching Data' },
    { pct: 78,  label: 'Preparing Views' },
    { pct: 92,  label: 'Almost Ready' },
    { pct: 100, label: 'Portal Ready' },
];
let stepIndex = 0;

function runLoadingStep() {
    if (stepIndex >= loadingSteps.length) return;
    const step = loadingSteps[stepIndex];
    const fill   = document.getElementById('ls-fill');
    const pct    = document.getElementById('ls-pct');
    const status = document.getElementById('ls-status');

    if (fill)   fill.style.width  = step.pct + '%';
    if (pct)    pct.textContent   = step.pct + '%';
    if (status) status.textContent = step.label;

    stepIndex++;
    if (stepIndex < loadingSteps.length) {
        setTimeout(runLoadingStep, stepIndex === loadingSteps.length - 1 ? 280 : Math.random() * 250 + 160);
    } else {
        setTimeout(finishLoading, 350);
    }
}

function finishLoading() {
    const screen = document.getElementById('loading-screen');
    if (screen) {
        document.body.classList.remove('overflow-hidden');
        screen.style.opacity = '0';
        screen.style.transition = 'opacity 0.5s ease';
        setTimeout(() => {
            screen.remove();
            const panel = document.getElementById('admin-panel');
            if (panel) panel.classList.remove('hidden');
            initDashboard();
        }, 500);
    }
}

window.onload = () => setTimeout(runLoadingStep, 300);

// ─── Management Dropdown ──────────────────────────────────────────────────────
let managementOpen = true;

function openManagementDropdown() {
    managementOpen = true;
    const dropdown = document.getElementById('management-dropdown');
    const chevron  = document.getElementById('management-chevron');
    const btn      = document.getElementById('nav-management-btn');

    if (dropdown) dropdown.classList.remove('hidden');
    if (chevron)  chevron.style.transform = 'rotate(180deg)';
    if (btn)      btn.classList.add('bg-white');
}

function toggleManagementDropdown() {
    managementOpen = !managementOpen;
    const dropdown = document.getElementById('management-dropdown');
    const chevron  = document.getElementById('management-chevron');
    const btn      = document.getElementById('nav-management-btn');
    if (managementOpen) {
        if (dropdown) dropdown.classList.remove('hidden');
        if (chevron)  chevron.style.transform = 'rotate(180deg)';
        if (btn)      btn.classList.add('bg-white');
        showPage('mgmt-schedule');
    } else {
        if (dropdown) dropdown.classList.add('hidden');
        if (chevron)  chevron.style.transform = 'rotate(0deg)';
        if (btn)      btn.classList.remove('bg-white');
    }
}

// ─── Page Navigation ──────────────────────────────────────────────────────────
const managementSubPages = ['mgmt-schedule', 'mgmt-teachers', 'mgmt-students'];

function showPage(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
    const targetPage = document.getElementById('page-' + page);
    if (targetPage) targetPage.classList.remove('hidden');

    document.querySelectorAll('.admin-nav-sub').forEach(i => {
        i.classList.remove('text-[#3d7068]', 'font-bold');
        i.classList.add('text-[#1c1c1c]/70');
    });

    if (managementSubPages.includes(page)) {
        const sub = document.getElementById('sub-' + page);
        if (sub) {
            sub.classList.add('text-[#3d7068]', 'font-bold');
            sub.classList.remove('text-[#1c1c1c]/70');
        }
        openManagementDropdown();

        if (page === 'mgmt-schedule')  initSchedulePage();
        else if (page === 'mgmt-teachers') renderTeachersTable();
        else if (page === 'mgmt-students') initStudentPage();
    }
}

// ─── Modal Helpers ────────────────────────────────────────────────────────────
function openScheduleModal() { 
    const m = document.getElementById('modal-schedule');    
    if (m) m.classList.add('active'); 
}

function openAddTeacherModal()  { const m = document.getElementById('modal-add-teacher'); if (m) m.classList.add('active'); }
function openAddStudentModal()  { const m = document.getElementById('modal-add-student'); if (m) m.classList.add('active'); }
function closeModal(id)         { const m = document.getElementById(id); if (m) m.classList.remove('active'); }
function closeOnOverlay(e, id)  { if (e.target === document.getElementById(id)) closeModal(id); }

// ─── Constants ────────────────────────────────────────────────────────────────
const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

const TIMES = [
    '7:00','7:30','8:00','8:30','9:00','9:30',
    '10:00','10:30','11:00','11:30',
    '12:00','12:30',
    '13:00','13:30','14:00','14:30',
    '15:00','15:30','16:00','16:30',
    '17:00','17:30'
];

const LUNCH = new Set(['12:00','12:30']);

// ─── Stores ───────────────────────────────────────────────────────────────────
let rawScheduleDB        = [];
let rawRoomScheduleDB    = [];
let rawTeachersDB        = [];
let rawStudentSchedDB    = [];

function normalizeTime(t) {
    if (!t) return '';
    const [h, m] = t.split(':').map(Number);
    return `${h}:${String(m).padStart(2, '0')}`;
}

function titleCase(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

function normalizeScheduleRows(rows) {
    const map = new Map();
    rows.forEach(row => {
        const key = `${row.prof_name}||${row.subject_name}||${row.blocks}||${row.room_name}||${row.start_time}||${row.end_time}`;
        const day = titleCase(row.day_of_week);
        if (map.has(key)) {
            map.get(key).days.push(day);
        } else {
            map.set(key, {
                id:       row.teacher_sched_id,
                faculty:  row.prof_name,
                subject:  row.subject_name,
                section:  row.blocks,
                room:     row.room_name,
                days:     [day],
                timeIn:   normalizeTime(row.start_time),
                timeOut:  normalizeTime(row.end_time),
                type:     inferType(row.subject_name, row.room_name),
                dept:     inferDept(row.blocks),
                prof_id:  row.prof_id,
            });
        }
    });
    return [...map.values()];
}

function normalizeTeacherRows(rows) {
    return rows.map(r => ({
        id:     r.teacher_id,
        name:   r.teacher_name,
        role:   r.role,
        email:  r.email,
        status: r.status,
    }));
}

function normalizeStudentRows(rows) {
    const map = new Map();
    rows.forEach(row => {
        const block = row.block_name;
        const day   = titleCase(row.day_of_week);
        if (!map.has(block)) {
            map.set(block, {
                id:      row.student_sched_id,
                Block:   block,
                program: row.program,
                courses: [],
            });
        }
        const entry = map.get(block);
        const courseKey = `${row.subject_name}||${row.instructor_name}||${row.room_name}||${row.start_time}||${row.end_time}`;
        const existing  = entry.courses.find(c => c._key === courseKey);
        if (existing) {
            existing.days.push(day);
        } else {
            entry.courses.push({
                _key:       courseKey,
                subject:    row.subject_name,
                instructor: row.instructor_name,
                room:       row.room_name,
                days:       [day],
                timeIn:     normalizeTime(row.start_time),
                timeOut:    normalizeTime(row.end_time),
            });
        }
    });
    return [...map.values()];
}

function inferType(subjectName, roomName) {
    const r = (roomName || '').toLowerCase();
    const s = (subjectName || '').toLowerCase();
    if (r.includes('lab') || s.includes('laboratory')) return 'lab';
    if (s.includes('consult'))                          return 'consult';
    if (s.includes('gee') || s.includes('general'))    return 'gee';
    return 'lec';
}

function inferDept(blocks) {
    if (!blocks) return '—';
    const b = blocks.toUpperCase();
    if (b.includes('BSIT') || b.includes('WMT') || b.includes('DA')) return 'IT Department';
    if (b.includes('BSED'))  return 'Education Department';
    if (b.includes('BSBA'))  return 'Business Department';
    return blocks;
}

// ─── State ────────────────────────────────────────────────────────────────────
let facultyGridsState = []; 
let studentGridsState = []; 

// ─── Boot Data ────────────────────────────────────────────────────────────────
Promise.all([
    fetch('get_schedule.php').then(r => r.json()),
    fetch('get_room_schedules.php').then(r => r.json()),
    fetch('get_teachers.php').then(r => r.json()),
    fetch('get_student_schedules.php').then(r => r.json()),
]).then(([schedRows, roomSchedRows, teacherRows, studentRows]) => {

    rawScheduleDB     = normalizeScheduleRows(schedRows);
    rawRoomScheduleDB = normalizeScheduleRows(roomSchedRows);
    rawTeachersDB     = normalizeTeacherRows(teacherRows);
    rawStudentSchedDB = normalizeStudentRows(studentRows);

    const facultyList1 = [...new Set(rawScheduleDB.map(s => s.faculty))];
    const facultyList2 = [...new Set(rawRoomScheduleDB.map(s => s.faculty))];
    
    if (facultyList1.length > 0) {
        facultyGridsState.push({ faculty: facultyList1[0], view: 'grid', source: 'teacher' });
    }
    facultyList2.forEach((fac) => {
        if (fac !== facultyGridsState[0]?.faculty) {
            facultyGridsState.push({ faculty: fac, view: 'grid', source: 'room' });
        }
    });

    const blockList = [...new Set(rawStudentSchedDB.map(s => s.Block))];
    blockList.forEach(block => {
        studentGridsState.push({ block: block, view: 'grid' });
    });

    initSchedulePage();
    renderTeachersTable();
    initStudentPage();

}).catch(err => {
    console.error('Failed to fetch data:', err);
});

function initDashboard() {
    showPage('mgmt-schedule');
}

function getFacultyList(source) {
    const db = source === 'teacher' ? rawScheduleDB : rawRoomScheduleDB;
    return [...new Set(db.map(s => s.faculty))];
}

function getBlockList() {
    return [...new Set(rawStudentSchedDB.map(s => s.Block))];
}

// ─── Editorial Schedule Page ──────────────────────────────────────────────────
window.initSchedulePage = function () {
    const container = document.getElementById('dynamic-schedule-container');
    if (!container) return;
    container.innerHTML = '';

    facultyGridsState.forEach((grid, idx) => {
        const suffix = idx === 0 ? '' : `-${idx + 1}`;
        const gridHtml = `
            <div class="bg-white border border-[#e5e4de] p-6 mb-8 shadow-sm space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <div class="flex items-center gap-2">
                        <span class="w-2 h-2 bg-[#3d7068]"></span>
                        <h2 class="font-playfair text-xl text-[#1c1c1c]">Faculty Schedule</h2>
                    </div>
                    <button onclick="exportSchedulePDF('${suffix}')" class="px-4 py-2 border border-[#e5e4de] text-[10px] uppercase tracking-wider font-bold text-[#1c1c1c] hover:bg-[#f7f6f2] transition-colors">↓ Export PDF</button>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 bg-[#f7f6f2] border border-[#e5e4de] p-4 text-xs font-mono-tech">
                    <div>
                        <span class="block text-[9px] uppercase tracking-widest text-[#3d7068] font-bold">Faculty Member</span>
                        <span id="sched-faculty-name${suffix}" class="font-bold text-[#1c1c1c]">—</span>
                    </div>
                    <div>
                        <span class="block text-[9px] uppercase tracking-widest text-[#3d7068] font-bold">Total Workload</span>
                        <span id="sched-hours${suffix}" class="font-bold text-[#1c1c1c]">—</span>
                    </div>
                    <div>
                        <span class="block text-[9px] uppercase tracking-widest text-[#3d7068] font-bold">Academic Term</span>
                        <span class="font-bold text-[#1c1c1c]">2ND SEMESTER</span>
                    </div>
                    <div class="flex justify-end items-center">
                        <select id="sched-faculty-select${suffix}" onchange="loadFacultyScheduleDynamic('${suffix}', this.value, ${idx})" class="w-full bg-white border border-[#e5e4de] text-[#1c1c1c] text-xs px-3 py-2 focus:outline-none focus:border-[#3d7068] cursor-pointer"></select>
                    </div>
                </div>

                <div class="flex gap-2 text-[10px] uppercase tracking-wider font-bold">
                    <button onclick="switchSchedViewDynamic('${suffix}', 'grid', ${idx})" id="tab-grid${suffix}" class="px-4 py-2 border border-[#e5e4de] bg-[#3d7068] text-white">Weekly Grid</button>
                    <button onclick="switchSchedViewDynamic('${suffix}', 'list', ${idx})" id="tab-list${suffix}" class="px-4 py-2 border border-[#e5e4de] bg-white text-[#1c1c1c]/70 hover:bg-[#f7f6f2]">List View</button>
                    <button onclick="switchSchedViewDynamic('${suffix}', 'conflicts', ${idx})" id="tab-conflicts${suffix}" class="px-4 py-2 border border-[#e5e4de] bg-white text-[#1c1c1c]/70 hover:bg-[#f7f6f2]">Conflicts</button>
                </div>

                <div id="sched-view-grid${suffix}">
                    <div class="overflow-x-auto border border-[#e5e4de]">
                        <table class="w-full border-collapse" style="min-width:860px;">
                            <thead>
                                <tr id="sched-thead-row${suffix}" class="border-b border-[#e5e4de] bg-[#f7f6f2]">
                                    <th class="p-3 text-left text-[10px] uppercase tracking-widest text-[#3d7068] font-bold w-20 border-r border-[#e5e4de]">Time</th>
                                </tr>
                            </thead>
                            <tbody id="sched-grid-body${suffix}"></tbody>
                        </table>
                    </div>
                </div>

                <div id="sched-view-list${suffix}" class="hidden">
                    <div class="border border-[#e5e4de] overflow-x-auto">
                        <table class="w-full text-left border-collapse text-xs">
                            <thead>
                                <tr class="border-b border-[#e5e4de] bg-[#f7f6f2] text-[10px] uppercase text-[#3d7068] font-bold">
                                    <th class="p-3 border-r border-[#e5e4de]">ID</th>
                                    <th class="p-3 border-r border-[#e5e4de]">Subject</th>
                                    <th class="p-3 border-r border-[#e5e4de]">Section</th>
                                    <th class="p-3 border-r border-[#e5e4de]">Room</th>
                                    <th class="p-3 border-r border-[#e5e4de]">Days</th>
                                    <th class="p-3 border-r border-[#e5e4de]">In</th>
                                    <th class="p-3 border-r border-[#e5e4de]">Out</th>
                                    <th class="p-3">Type</th>
                                </tr>
                            </thead>
                            <tbody id="sched-list-body${suffix}" class="divide-y divide-[#e5e4de]"></tbody>
                        </table>
                    </div>
                </div>

                <div id="sched-view-conflicts${suffix}" class="hidden">
                    <div id="sched-conflicts-body${suffix}" class="space-y-3"></div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', gridHtml);
        populateFacultyDropdownDynamic(suffix, grid.source, grid.faculty);
        updateGridViewDynamic(suffix, grid);
    });
};

function populateFacultyDropdownDynamic(suffix, source, value) {
    const sel = document.getElementById('sched-faculty-select' + suffix);
    if (!sel) return;
    sel.innerHTML = getFacultyList(source).map(f => `<option value="${f}">${f}</option>`).join('');
    sel.value = value;
}

window.loadFacultyScheduleDynamic = function (suffix, faculty, idx) {
    facultyGridsState[idx].faculty = faculty;
    updateGridViewDynamic(suffix, facultyGridsState[idx]);
};

function updateGridViewDynamic(suffix, gridState) {
    const db = gridState.source === 'teacher' ? rawScheduleDB : rawRoomScheduleDB;
    const entries = db.filter(s => s.faculty === gridState.faculty);
    const hrs = calcTotalHours(entries);

    const fn = document.getElementById('sched-faculty-name' + suffix);
    const fh = document.getElementById('sched-hours' + suffix);
    if (fn) fn.textContent = gridState.faculty;
    if (fh) fh.textContent = hrs + ' hrs/week';

    renderCurrentViewDynamic(suffix, gridState);
}

function calcTotalHours(entries) {
    let mins = 0;
    entries.forEach(e => {
        const [iH, iM] = e.timeIn.split(':').map(Number);
        const [oH, oM] = e.timeOut.split(':').map(Number);
        mins += ((oH * 60 + oM) - (iH * 60 + iM)) * e.days.length;
    });
    return Math.round(mins / 60);
}

window.switchSchedViewDynamic = function (suffix, view, idx) {
    facultyGridsState[idx].view = view;
    updateSchedTabUIDynamic(suffix, view);
    renderCurrentViewDynamic(suffix, facultyGridsState[idx]);
};

function updateSchedTabUIDynamic(suffix, view) {
    ['grid','list','conflicts'].forEach(v => {
        const viewEl = document.getElementById('sched-view-' + v + suffix);
        const tabEl  = document.getElementById('tab-' + v + suffix);
        if (viewEl) viewEl.classList.add('hidden');
        if (tabEl)  { 
            tabEl.className = 'px-4 py-2 border border-[#e5e4de] bg-white text-[#1c1c1c]/70 hover:bg-[#f7f6f2]';
        }
    });
    const activeView = document.getElementById('sched-view-' + view + suffix);
    const activeTab  = document.getElementById('tab-' + view + suffix);
    if (activeView) activeView.classList.remove('hidden');
    if (activeTab)  { 
        activeTab.className = 'px-4 py-2 border border-[#e5e4de] bg-[#3d7068] text-white';
    }
}

function renderCurrentViewDynamic(suffix, gridState) {
    if (gridState.view === 'grid')      renderGridDynamic(suffix, gridState);
    else if (gridState.view === 'list') renderListDynamic(suffix, gridState);
    else                                renderConflictsDynamic(suffix, gridState);
}

function renderGridDynamic(suffix, gridState) {
    const db = gridState.source === 'teacher' ? rawScheduleDB : rawRoomScheduleDB;
    const entries = db.filter(s => s.faculty === gridState.faculty);
    const theadRow  = document.getElementById('sched-thead-row' + suffix);
    if (!theadRow) return;

    while (theadRow.children.length > 1) theadRow.removeChild(theadRow.lastChild);
    DAYS.forEach(day => {
        const th = document.createElement('th');
        th.className = 'p-3 text-left text-[10px] uppercase tracking-widest text-[#3d7068] font-bold border-r border-[#e5e4de]';
        th.textContent = day;
        theadRow.appendChild(th);
    });

    const tbody = document.getElementById('sched-grid-body' + suffix);
    if (!tbody) return;
    tbody.innerHTML = '';

    TIMES.forEach(time => {
        const isLunch = LUNCH.has(time);
        const tr = document.createElement('tr');
        tr.className = 'border-b border-[#e5e4de]' + (isLunch ? ' bg-amber-500/10' : '');

        const tdTime = document.createElement('td');
        tdTime.className = 'p-2 text-[10px] text-[#1c1c1c]/60 font-bold whitespace-nowrap align-top border-r border-[#e5e4de] bg-[#f7f6f2]';
        tdTime.textContent = time;
        tr.appendChild(tdTime);

        DAYS.forEach((day, idx) => {
            if (isLunch) {
                if (idx === 0) {
                    const td = document.createElement('td');
                    td.colSpan = 6;
                    td.className = 'align-middle border-r border-[#e5e4de]';
                    td.innerHTML = `<div class="text-center text-[9px] font-bold tracking-[0.2em] uppercase text-amber-700 py-1">— Lunch Break —</div>`;
                    tr.appendChild(td);
                }
                return;
            }

            const td = document.createElement('td');
            td.className = 'border-r border-[#e5e4de] align-top p-1 bg-white';
            td.style.minWidth = '110px';

            const matching = entries.filter(e => e.days.includes(day) && timeInRange(time, e.timeIn, e.timeOut));
            if (matching.length) {
                matching.forEach(e => {
                    const tag = document.createElement('div');
                    tag.className = `p-2 mb-1 border border-[#e5e4de] border-l-4 bg-[#f7f6f2] ${typeBorder(e.type)}`;
                    tag.innerHTML = `
                        <div class="text-[10px] font-bold text-[#1c1c1c]">${e.subject}</div>
                        <div class="text-[9px] text-[#3d7068] font-bold mt-0.5">${e.section}</div>
                        <div class="text-[9px] text-[#1c1c1c]/60">${e.room}</div>`;
                    td.appendChild(tag);
                });
            } else {
                td.innerHTML = `<div class="h-8 hover:bg-[#f7f6f2] transition-colors"></div>`;
            }
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
}

function renderListDynamic(suffix, gridState) {
    const db = gridState.source === 'teacher' ? rawScheduleDB : rawRoomScheduleDB;
    const entries = db.filter(s => s.faculty === gridState.faculty);
    const tbody   = document.getElementById('sched-list-body' + suffix);
    if (!tbody) return;
    tbody.innerHTML = '';

    entries.forEach(entry => {
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-[#f7f6f2] transition-colors';
        tr.innerHTML = `
            <td class="p-3 border-r border-[#e5e4de] font-mono text-[11px]">${entry.id}</td>
            <td class="p-3 border-r border-[#e5e4de] font-bold text-[#1c1c1c]">${entry.subject}</td>
            <td class="p-3 border-r border-[#e5e4de]">${entry.section}</td>
            <td class="p-3 border-r border-[#e5e4de]">${entry.room}</td>
            <td class="p-3 border-r border-[#e5e4de] text-[10px]">${entry.days.join(', ')}</td>
            <td class="p-3 border-r border-[#e5e4de]">${entry.timeIn}</td>
            <td class="p-3 border-r border-[#e5e4de]">${entry.timeOut}</td>
            <td class="p-3">${typeBadge(entry.type)}</td>`;
        tbody.appendChild(tr);
    });
}

function renderConflictsDynamic(suffix, gridState) {
    const db = gridState.source === 'teacher' ? rawScheduleDB : rawRoomScheduleDB;
    const entries = db.filter(s => s.faculty === gridState.faculty);
    const body    = document.getElementById('sched-conflicts-body' + suffix);
    if (!body) return;
    body.innerHTML = '';

    const conflicts = [];
    for (let i = 0; i < entries.length; i++) {
        for (let j = i + 1; j < entries.length; j++) {
            const e1 = entries[i], e2 = entries[j];
            if (e1.days.some(d => e2.days.includes(d)) && timesOverlap(e1.timeIn, e1.timeOut, e2.timeIn, e2.timeOut)) {
                conflicts.push({ e1, e2 });
            }
        }
    }

    if (conflicts.length === 0) {
        body.innerHTML = '<div class="text-center py-8 text-[#1c1c1c]/60 text-xs">No scheduling conflicts detected.</div>';
        return;
    }

    conflicts.forEach(c => {
        const div = document.createElement('div');
        div.className = 'p-4 bg-red-50 border border-red-200 text-red-800 text-xs space-y-1';
        div.innerHTML = `
            <div class="font-bold uppercase tracking-wider text-[10px] text-red-600">⚠ Schedule Overlap Warning</div>
            <div><strong>${c.e1.subject}</strong> (${c.e1.timeIn}–${c.e1.timeOut})</div>
            <div><strong>${c.e2.subject}</strong> (${c.e2.timeIn}–${c.e2.timeOut})</div>
            <div class="text-[10px] opacity-80">Conflict Days: ${c.e1.days.filter(d => c.e2.days.includes(d)).join(', ')}</div>`;
        body.appendChild(div);
    });
}

// ─── Teachers Directory ───────────────────────────────────────────────────────
function renderTeachersTable() {
    const tbody = document.getElementById('teachers-body');
    if (!tbody) return;
    tbody.innerHTML = '';

    rawTeachersDB.forEach(t => {
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-[#f7f6f2] transition-colors';
        const statusColor = t.status === 'Active'
            ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
            : 'bg-red-100 text-red-800 border-red-300';
        tr.innerHTML = `
            <td class="p-4 font-mono text-[11px] text-[#1c1c1c]/60">${t.id}</td>
            <td class="p-4 font-bold text-[#1c1c1c]">${t.name}</td>
            <td class="p-4 text-[#1c1c1c]/80">${t.role}</td>
            <td class="p-4 text-[#1c1c1c]/80">${t.email}</td>
            <td class="p-4"><span class="px-2.5 py-1 border text-[9px] uppercase tracking-wider font-bold ${statusColor}">${t.status}</span></td>
            <td class="p-4"><button class="px-3 py-1 border border-[#e5e4de] bg-white hover:bg-[#f7f6f2] text-[10px] uppercase font-bold text-[#1c1c1c]">Edit</button></td>`;
        tbody.appendChild(tr);
    });
}

// ─── Students Page ────────────────────────────────────────────────────────────
window.initStudentPage = function () {
    const container = document.getElementById('dynamic-student-container');
    if (!container) return;
    container.innerHTML = '';

    studentGridsState.forEach((grid, idx) => {
        const suffix = idx === 0 ? '' : `-${idx + 1}`;
        const gridHtml = `
            <div class="bg-white border border-[#e5e4de] p-6 mb-8 shadow-sm space-y-6">
                <div class="flex items-center justify-between border-b border-[#e5e4de] pb-4">
                    <div class="flex items-center gap-2">
                        <span class="w-2 h-2 bg-[#3d7068]"></span>
                        <h2 class="font-playfair text-xl text-[#1c1c1c]">Student Schedule (${grid.block})</h2>
                    </div>
                    <button onclick="exportStudentSchedulePDFDynamic('${suffix}')" class="px-4 py-2 border border-[#e5e4de] text-[10px] uppercase tracking-wider font-bold text-[#1c1c1c] hover:bg-[#f7f6f2] transition-colors">↓ Export PDF</button>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 bg-[#f7f6f2] border border-[#e5e4de] p-4 text-xs font-mono-tech">
                    <div>
                        <span class="block text-[9px] uppercase tracking-widest text-[#3d7068] font-bold">Class Block</span>
                        <span id="student-name-display${suffix}" class="font-bold text-[#1c1c1c]">—</span>
                    </div>
                    <div>
                        <span class="block text-[9px] uppercase tracking-widest text-[#3d7068] font-bold">Degree Program</span>
                        <span id="student-program-display${suffix}" class="font-bold text-[#1c1c1c]">—</span>
                    </div>
                    <div>
                        <span class="block text-[9px] uppercase tracking-widest text-[#3d7068] font-bold">Total Contact Hours</span>
                        <span id="student-hours${suffix}" class="font-bold text-[#1c1c1c]">—</span>
                    </div>
                    <div class="flex justify-end items-center">
                        <select id="student-select${suffix}" onchange="loadStudentScheduleDynamic('${suffix}', this.value, ${idx})" class="w-full bg-white border border-[#e5e4de] text-[#1c1c1c] text-xs px-3 py-2 focus:outline-none focus:border-[#3d7068] cursor-pointer"></select>
                    </div>
                </div>

                <div class="flex gap-2 text-[10px] uppercase tracking-wider font-bold">
                    <button onclick="switchStudentViewDynamic('${suffix}', 'grid', ${idx})" id="student-tab-grid${suffix}" class="px-4 py-2 border border-[#e5e4de] bg-[#3d7068] text-white">Weekly Grid</button>
                    <button onclick="switchStudentViewDynamic('${suffix}', 'list', ${idx})" id="student-tab-list${suffix}" class="px-4 py-2 border border-[#e5e4de] bg-white text-[#1c1c1c]/70 hover:bg-[#f7f6f2]">List View</button>
                </div>

                <div id="student-view-grid${suffix}">
                    <div class="overflow-x-auto border border-[#e5e4de]">
                        <table class="w-full border-collapse" style="min-width:860px;">
                            <thead>
                                <tr id="student-thead-row${suffix}" class="border-b border-[#e5e4de] bg-[#f7f6f2]">
                                    <th class="p-3 text-left text-[10px] uppercase tracking-widest text-[#3d7068] font-bold w-20 border-r border-[#e5e4de]">Time</th>
                                </tr>
                            </thead>
                            <tbody id="student-grid-body${suffix}"></tbody>
                        </table>
                    </div>
                </div>

                <div id="student-view-list${suffix}" class="hidden">
                    <div class="border border-[#e5e4de] overflow-x-auto">
                        <table class="w-full text-left border-collapse text-xs">
                            <thead>
                                <tr class="border-b border-[#e5e4de] bg-[#f7f6f2] text-[10px] uppercase text-[#3d7068] font-bold">
                                    <th class="p-3 border-r border-[#e5e4de]">ID</th>
                                    <th class="p-3 border-r border-[#e5e4de]">Subject</th>
                                    <th class="p-3 border-r border-[#e5e4de]">Instructor</th>
                                    <th class="p-3 border-r border-[#e5e4de]">Room</th>
                                    <th class="p-3 border-r border-[#e5e4de]">Days</th>
                                    <th class="p-3 border-r border-[#e5e4de]">In</th>
                                    <th class="p-3 border-r border-[#e5e4de]">Out</th>
                                    <th class="p-3">Type</th>
                                </tr>
                            </thead>
                            <tbody id="student-list-body${suffix}" class="divide-y divide-[#e5e4de]"></tbody>
                        </table>
                    </div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', gridHtml);
        populateBlockDropdownDynamic(suffix, grid.block);
        updateStudentGridViewDynamic(suffix, grid);
    });
};

function populateBlockDropdownDynamic(suffix, value) {
    const sel = document.getElementById('student-select' + suffix);
    if (!sel) return;
    sel.innerHTML = getBlockList().map(b => `<option value="${b}">${b}</option>`).join('');
    sel.value = value;
}

window.loadStudentScheduleDynamic = function (suffix, block, idx) {
    studentGridsState[idx].block = block;
    updateStudentGridViewDynamic(suffix, studentGridsState[idx]);
};

function updateStudentGridViewDynamic(suffix, gridState) {
    const entry = rawStudentSchedDB.find(s => s.Block === gridState.block);
    if (!entry) return;

    const fn = document.getElementById('student-name-display' + suffix);
    const fp = document.getElementById('student-program-display' + suffix);
    const fh = document.getElementById('student-hours' + suffix);
    if (fn) fn.textContent = gridState.block;
    if (fp) fp.textContent = entry.program || '—';
    if (fh) fh.textContent = calcStudentHours(entry.courses) + ' hrs/week';

    renderStudentCurrentViewDynamic(suffix, gridState);
}

function calcStudentHours(courses) {
    let mins = 0;
    courses.forEach(c => {
        const [iH, iM] = c.timeIn.split(':').map(Number);
        const [oH, oM] = c.timeOut.split(':').map(Number);
        mins += ((oH * 60 + oM) - (iH * 60 + iM)) * c.days.length;
    });
    return Math.round(mins / 60);
}

window.switchStudentViewDynamic = function (suffix, view, idx) {
    studentGridsState[idx].view = view;
    updateStudentTabUIDynamic(suffix, view);
    renderStudentCurrentViewDynamic(suffix, studentGridsState[idx]);
};

function updateStudentTabUIDynamic(suffix, view) {
    ['grid','list'].forEach(v => {
        const viewEl = document.getElementById('student-view-' + v + suffix);
        const tabEl  = document.getElementById('student-tab-' + v + suffix);
        if (viewEl) viewEl.classList.add('hidden');
        if (tabEl)  { 
            tabEl.className = 'px-4 py-2 border border-[#e5e4de] bg-white text-[#1c1c1c]/70 hover:bg-[#f7f6f2]';
        }
    });
    const activeView = document.getElementById('student-view-' + view + suffix);
    const activeTab  = document.getElementById('student-tab-' + view + suffix);
    if (activeView) activeView.classList.remove('hidden');
    if (activeTab)  { 
        activeTab.className = 'px-4 py-2 border border-[#e5e4de] bg-[#3d7068] text-white';
    }
}

function renderStudentCurrentViewDynamic(suffix, gridState) {
    if (gridState.view === 'grid') renderStudentGridDynamic(suffix, gridState);
    else                           renderStudentListDynamic(suffix, gridState);
}

function renderStudentGridDynamic(suffix, gridState) {
    const entry = rawStudentSchedDB.find(s => s.Block === gridState.block);
    if (!entry) return;
    const theadRow = document.getElementById('student-thead-row' + suffix);
    if (!theadRow) return;
    while (theadRow.children.length > 1) theadRow.removeChild(theadRow.lastChild);
    DAYS.forEach(day => {
        const th = document.createElement('th');
        th.className = 'p-3 text-left text-[10px] uppercase tracking-widest text-[#3d7068] font-bold border-r border-[#e5e4de]';
        th.textContent = day;
        theadRow.appendChild(th);
    });
    const tbody = document.getElementById('student-grid-body' + suffix);
    if (!tbody) return;
    tbody.innerHTML = '';
    TIMES.forEach(time => {
        const isLunch = LUNCH.has(time);
        const tr = document.createElement('tr');
        tr.className = 'border-b border-[#e5e4de]' + (isLunch ? ' bg-amber-500/10' : '');
        const tdTime = document.createElement('td');
        tdTime.className = 'p-2 text-[10px] text-[#1c1c1c]/60 font-bold whitespace-nowrap align-top border-r border-[#e5e4de] bg-[#f7f6f2]';
        tdTime.textContent = time;
        tr.appendChild(tdTime);
        DAYS.forEach((day, idx) => {
            if (isLunch) {
                if (idx === 0) {
                    const td = document.createElement('td');
                    td.colSpan = 6;
                    td.className = 'align-middle border-r border-[#e5e4de]';
                    td.innerHTML = `<div class="text-center text-[9px] font-bold tracking-[0.2em] uppercase text-amber-700 py-1">— Lunch Break —</div>`;
                    tr.appendChild(td);
                }
                return;
            }
            const td = document.createElement('td');
            td.className = 'border-r border-[#e5e4de] align-top p-1 bg-white';
            td.style.minWidth = '110px';
            const matching = entry.courses.filter(c => c.days.includes(day) && timeInRange(time, c.timeIn, c.timeOut));
            if (matching.length) {
                matching.forEach(course => {
                    const tag = document.createElement('div');
                    tag.className = 'p-2 mb-1 border border-[#e5e4de] border-l-4 border-l-[#3d7068] bg-[#f7f6f2]';
                    tag.innerHTML = `
                        <div class="text-[10px] font-bold text-[#1c1c1c]">${course.subject}</div>
                        <div class="text-[9px] text-[#3d7068] font-bold mt-0.5">${course.instructor}</div>
                        <div class="text-[9px] text-[#1c1c1c]/60">${course.room}</div>`;
                    td.appendChild(tag);
                });
            } else {
                td.innerHTML = `<div class="h-8 hover:bg-[#f7f6f2] transition-colors"></div>`;
            }
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
}

function renderStudentListDynamic(suffix, gridState) {
    const entry = rawStudentSchedDB.find(s => s.Block === gridState.block);
    if (!entry) return;
    const tbody = document.getElementById('student-list-body' + suffix);
    if (!tbody) return;
    tbody.innerHTML = '';
    entry.courses.forEach((course, i) => {
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-[#f7f6f2] transition-colors';
        tr.innerHTML = `
            <td class="p-3 border-r border-[#e5e4de] font-mono text-[11px]">SC-${String(i + 1).padStart(3, '0')}</td>
            <td class="p-3 border-r border-[#e5e4de] font-bold text-[#1c1c1c]">${course.subject}</td>
            <td class="p-3 border-r border-[#e5e4de]">${course.instructor}</td>
            <td class="p-3 border-r border-[#e5e4de]">${course.room}</td>
            <td class="p-3 border-r border-[#e5e4de] text-[10px]">${course.days.join(', ')}</td>
            <td class="p-3 border-r border-[#e5e4de]">${course.timeIn}</td>
            <td class="p-3 border-r border-[#e5e4de]">${course.timeOut}</td>
            <td class="p-3"><span class="px-2 py-0.5 border text-[9px] font-bold uppercase bg-teal-50 text-[#3d7068] border-teal-200">LEC</span></td>`;
        tbody.appendChild(tr);
    });
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function timeInRange(slotTime, timeIn, timeOut) {
    const m = t => { const p = t.split(':').map(Number); return p[0] * 60 + (p[1] || 0); };
    return m(slotTime) >= m(timeIn) && m(slotTime) < m(timeOut);
}

function timesOverlap(s1, e1, s2, e2) {
    const m = t => { const p = t.split(':').map(Number); return p[0] * 60 + (p[1] || 0); };
    return m(s1) < m(e2) && m(s2) < m(e1);
}

function typeBorder(type) {
    return {
        lec:     'border-l-blue-600',
        lab:     'border-l-emerald-600',
        gee:     'border-l-amber-600',
        consult: 'border-l-purple-600',
    }[type] || 'border-l-[#3d7068]';
}

function typeBadge(type) {
    return {
        lec:     '<span class="px-2 py-0.5 border text-[9px] font-bold bg-blue-50 text-blue-800 border-blue-200">LEC</span>',
        lab:     '<span class="px-2 py-0.5 border text-[9px] font-bold bg-emerald-50 text-emerald-800 border-emerald-200">LAB</span>',
        gee:     '<span class="px-2 py-0.5 border text-[9px] font-bold bg-amber-50 text-amber-800 border-amber-200">GEE</span>',
        consult: '<span class="px-2 py-0.5 border text-[9px] font-bold bg-purple-50 text-purple-800 border-purple-200">CONSULT</span>',
    }[type] || '<span class="px-2 py-0.5 border text-[9px] font-bold bg-gray-50 text-gray-600 border-gray-200">—</span>';
}

window.exportSchedulePDF = function (suffix) { alert('Exporting schedule to PDF...'); };
window.exportStudentSchedulePDFDynamic = function (suffix) { alert('Exporting student schedule to PDF...'); };

const _origShowPage = showPage;
window.showPage = function (page) {
    _origShowPage(page);
    if (page === 'mgmt-students') initStudentPage();
};