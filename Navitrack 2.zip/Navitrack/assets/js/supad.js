document.addEventListener('DOMContentLoaded', function () {
    // Initial loads
    loadSubjects();
    loadRooms();
    loadDepartments();
});

/**
 * Safe loading step to prevent Null Reference Errors
 */
function runLoadingStep() {
    const loadingElem = document.getElementById('loadingSpinner') || document.querySelector('.loading-spinner');
    if (loadingElem) {
        loadingElem.style.display = 'none';
    }
}

/**
 * Fetch and render Curriculum Subjects
 */
function loadSubjects() {
    const targetUrl = window.location.pathname.includes('/SUPAD/') 
        ? 'add_sub.php?action=fetch' 
        : '../SUPAD/add_sub.php?action=fetch';

    fetch(targetUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            runLoadingStep();

            const tableBody = document.querySelector('#subjectTable tbody') || 
                              document.querySelector('table tbody') || 
                              document.getElementById('subject-list');

            if (!tableBody) {
                console.warn('Subject table body element not found in DOM.');
                return;
            }

            tableBody.innerHTML = '';

            const subjects = Array.isArray(data) ? data : (data.data || []);

            if (subjects.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="4" style="text-align: center; padding: 20px; color: #666;">
                            No curriculum subjects found.
                        </td>
                    </tr>`;
                return;
            }

            subjects.forEach((item) => {
                const id = item.subject_id || item.sub_id || item.id || 'N/A';
                const code = item.subject_code || item.sub_code || item.code || 'N/A';
                const title = item.subject_title || item.sub_title || item.subject_description || item.title || 'N/A';

                const row = `
                    <tr>
                        <td>#${id}</td>
                        <td><strong>${code}</strong></td>
                        <td>${title}</td>
                        <td>
                            <button class="edit-btn" onclick="editSubject(${id})" style="padding: 4px 12px; cursor: pointer;">EDIT</button>
                        </td>
                    </tr>
                `;
                tableBody.insertAdjacentHTML('beforeend', row);
            });
        })
        .catch(err => {
            runLoadingStep();
            console.error('Error fetching subjects:', err);
        });
}

/**
 * Fetch and render Rooms
 */
function loadRooms() {
    const targetUrl = window.location.pathname.includes('/SUPAD/') 
        ? 'add_room.php?action=fetch' 
        : '../SUPAD/add_room.php?action=fetch';

    fetch(targetUrl)
        .then(res => res.json())
        .then(data => {
            const tableBody = document.querySelector('#roomTable tbody') || document.getElementById('room-list');
            if (!tableBody) return;

            tableBody.innerHTML = '';
            const rooms = Array.isArray(data) ? data : (data.data || []);

            if (rooms.length === 0) {
                tableBody.innerHTML = `<tr><td colspan="4" style="text-align: center;">No rooms found.</td></tr>`;
                return;
            }

            rooms.forEach((room, idx) => {
                const id = room.room_id || room.id || (idx + 1);
                const name = room.room_name || room.room_no || 'N/A';
                const building = room.building_name || 'Unassigned';
                const capacity = room.capacity || 0;

                const row = `
                    <tr>
                        <td>#${id}</td>
                        <td><strong>${name}</strong></td>
                        <td>${building}</td>
                        <td>${capacity}</td>
                    </tr>
                `;
                tableBody.insertAdjacentHTML('beforeend', row);
            });
        })
        .catch(err => console.error('Error loading rooms:', err));
}

/**
 * Fetch and render Departments
 */
function loadDepartments() {
    const targetUrl = window.location.pathname.includes('/SUPAD/') 
        ? 'add_department.php?action=fetch' 
        : '../SUPAD/add_department.php?action=fetch';

    fetch(targetUrl)
        .then(res => res.json())
        .then(data => {
            const tableBody = document.querySelector('#departmentTable tbody') || document.getElementById('department-list');
            if (!tableBody) return;

            tableBody.innerHTML = '';
            const departments = Array.isArray(data) ? data : (data.data || []);

            if (departments.length === 0) {
                tableBody.innerHTML = `<tr><td colspan="3" style="text-align: center;">No departments found.</td></tr>`;
                return;
            }

            departments.forEach((dept, idx) => {
                const id = dept.department_id || dept.id || (idx + 1);
                const code = dept.dept_code || dept.department_code || 'N/A';
                const name = dept.dept_name || dept.department_name || 'N/A';

                const row = `
                    <tr>
                        <td>#${id}</td>
                        <td><strong>${code}</strong></td>
                        <td>${name}</td>
                    </tr>
                `;
                tableBody.insertAdjacentHTML('beforeend', row);
            });
        })
        .catch(err => console.error('Error loading departments:', err));
}

function editSubject(id) {
    console.log('Editing subject ID:', id);
}